
const app1=Vue.createApp({
  delimiters: ['[[', ']]'],
  data(){
    return{
      message:'Vue3',
      userData:[]
    }
  }
,
methods:{

},
created(){
  this.userData = tutordata;
  console.log('userdata')
  console.log(this.userData);
  
 
}
});


const routes=[
{path:'/',name:'dashboard',component:dashboard},
{path:'/your-work',name:'work',component:work},
// {path:'/history',name:'dashboard',component:history},
{path:'/profile',name:'profile',component:profile},
{path:'/payment',name:'payment',component:payment},
{path:'/instruction',name:'instruction',component:instruction},
{path:'/test',name:'test',component:test},

]

const router=VueRouter.createRouter({
  mode:'history',
  history:VueRouter.createWebHashHistory(),
  routes,
  linkExactActiveClass:'active'
})




app1.component('assignment-info-model',asignement_info_modal)
app1.component('recent-notifications',recent_notifications)
app1.component('table-data',table_data)
app1.component('dashboard',dashboard)


app1.component('payment',payment)
app1.component('profile',profile)
app1.component('history',history)

app1.component('chat-component',chat_component)
app1.component('test',test)
app1.use(router)

const vm=app1.mount('#vueapprender')