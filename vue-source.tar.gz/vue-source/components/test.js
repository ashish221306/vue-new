const test={
    
    template:`
    
    {% extends 'tutor/base.html' %}
{% load static %}

{% block title %}Profile | TutorBin Tutor{% endblock %}
{% block heading %} Test {% endblock %}
{% block body %}
<div class="file-viewer-modal">
    <embed src="">
</div>
<p style="display: none;" id="qslidenumber"></p>
<div class="main-container mt-3em " id="main">
    <div id="timer-container" class="d-flex">
        <p class="font-weight-600"><i class="fas fa-stopwatch mr-1"></i>Deadline: {{ deadlinee }}</p>
        <p id="timer" class="font-weight-600 ml-auto text-success"></p>
        <p id="feedback"></p>
    </div>
    <div class="bg-white p-3 rounded shadow-sm">
        <table class="w-100 table table-borderless fs-small testTable">
            <thead class="border-bottom">
            <tr>
                <th>Question</th>
                <th>Solution pdf/img <span class="text-danger">*</span></th>
                <th>Answer Value <span class="text-danger">*</span></th>
                <th>Submit Answer</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            {%for q in qs%}
            <tr>
                <form action="{% url 'tutor:answertest' q.id %}" method="post" class="ansForms" data-id="upload{{forloop.counter}}">
                    {% csrf_token %}
                    <td data-label="Question" class="vertical-middle" onclick="openViewer({{ta.id}},{{q.question.id}})">
                    <span class="img-file cursor-pointer pre-line" data-id="">Q{{forloop.counter}} - {{q.question.subject.subject}}
                          (click to view)</span>
                    </td>
                    <td data-label="Solution pdf/img " class="vertical-middle position-relative">
                    <!--<span data-feedback="upload{{forloop.counter}}" class="test-feedback  mr-1 {%if q.tanswer%}d-inline-block{%endif%}"> </span>-->
                        <input type="file" class="d-none file-upload" name="ans" onchange="onFileChange(event)" id="upload{{forloop.counter}}" accept="application/pdf,image/*"  name="answer" />
                       <span onclick="openFilePicker({{forloop.counter}},event)" class="fs-small"><i class="fas fa-upload text-center mr-2"></i><span class="{%if q.tanswer%}test-feedback{%endif%}" data-id="title">{%if q.tanswer%}File
                          Submitted.{%else%}Upload{%endif%}</span></span>

                    </td>
                    <td data-label="Answer Value" class="vertical-middle">
                        <input class="answer upload-answer" type="text" name="ansvalue" value="{{q.tanswervalue|default_if_none:''}}" required>
                    </td>


                    <td data-label="Submit Answer" class="vertical-middle">
                        <button class="btn text-info fs-small p-0 {%if not q.tanswer%} submit-btn {%endif%}"><i class="fas fa-check-circle mr-1 text-info"></i>Submit</button>
                    </td>
                    <td data-label="Status" class="vertical-middle">
                        {%if q.tanswer%}
                        <div class="status">
                            <i class="fas fa-check-circle text-success fs-small"> Submitted</i>
                        </div>
                        {%else%}
                        <div class="status">
                            <i class="fas fa-hourglass-half text-secondary fs-small"> Pending</i>
                        </div>
                        {%endif%}
                    </td>
                </form>
            </tr>
            {%endfor%}
            </tbody>
        </table>
        <div class="d-flex justify-content-center w-100 my-2">
           <button class="btn btn-dark text-capitalize fs-small" id="allsubmit">
                Submit all answers
           </button>
            <button class="btn btn-outline-success  fs-small text-uppercase" id="submit_all_btn" onclick="submitAll()" style="display: none">
                Submit Test
            </button>
        </div>
        {%if ta.comment%}
        <div class="d-flex w-100">
            <p><i>Note: </i>{{ta.comment}}</p>
        </div>
        {%endif%}
    </div>
    <div class="row mt-3 mt-lg-4">
        <div class="col-sm-12">
            <h4 class="text-shade1"> <i class="fas fa-chalkboard-teacher mr-1"></i> Instructions</h4>
            <div>
                <ul class="instructions">
                    <li>To upload solution, click on choose file and select the solution image/pdf, put an answer value(if
                        no specific answer, put NA) and then click Submit Answer button. Repeat it for every question.</li>
                    <li>Write solutions on a plain white paper, take picture and upload.</li>
                    <li>Upload <b>only 1 solution file per question</b>. If there are multiple photos, combine them in a
                        pdf/word file.</li>
                    <li>Submit all answers before deadline.</li>
                    <li>Test will be auto-submitted when the deadline ends.</li>
                    <li>Once you submit test or the deadline is over, your answers will be reviewed by our experts. Pass
                        the test to start earning.</li>
                    <li>For any query, contact us on number/mail provided at the bottom of the page.</li>
                </ul>

            </div>
        </div>
    </div>
    <div class="d-flex">
        <div class="p-2 p-md-3 p-lg-3 d-flex bg-white rounded shadow-sm fs-small mr-2" style="line-height: 1; width: fit-content">
            <i class="fab fa-whatsapp-square  text-green mr-1 mr-md-2 mr-lg-3" style="font-size: 1.5em;!important;"></i> <a target="_blank" href="https://wa.me/917082686818" class="my-auto "><span class="my-auto text-muted">+91-7082686818</span></a>
        </div>
        <div class=" p-2 p-md-3 p-lg-3 d-flex bg-white rounded shadow-sm fs-small" style="line-height: 1; width: fit-content">
            <i class="fas fa-envelope  text-shade1 mr-1 mr-md-2 mr-lg-3" style="font-size: 1.5em;!important;"></i> <a href="mailto:admin@tutorbin.com" class="my-auto text-muted">admin@tutorbin.com</a>
        </div>
    </div>
</div>
{%endblock%}
    
    
    `
}