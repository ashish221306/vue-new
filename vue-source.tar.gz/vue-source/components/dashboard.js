const dashboard = {
  data() {
    return {
      asslist: [],
      bsslist: [],
      img_src: "",
      data_src: "",
      data_id: "",
      data_type: "",
      data_assign: "",
      embedsrc: "",
      embed_id: "",

      //for iinitialising clock

      time: "",

      click: "",
      day: "",
      hour: "",
      minute: "",
      seconds: "",
      // for modal content

      timeheading: {
        text: "",
      },
      question_container: {
        class: [],
      },
      assID: "",
      type: "",
      duration: "",
      ref_container: {
        class: "",
      },
      questions: '<p class="w-100 text-center fs-small">No files attached</p>',
      refs: '<p class="w-100 text-center fs-small">No files attached</p>',
    };
  },

  methods: {
    onerr(event) {
      if (event.target.src != "static/media/branchicons/Misc.svg") {
        event.target.src = "static/media/branchicons/Misc.svg";
      }
    },
    hideFileModal() {},

    getInfo(tutID, type, assID) {
      axios
        .get(`/tutor/explore/${type}/${tutID}/`)
        .then((response) => {
          if (response.data.success == false) {
            alert(
              "This has been assigned to someone else and is no longer available"
            );
          } else {
            this.time = data.deadline.replace(",", "").split(" ");
            if (type == "a") {
              this.timeheading = "Deadline";
              this.assID = "Assignment ID : '+assID";
              this.type = "assignment";
              this.duration;
            } else {
            }
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    getTimeRemaining(endtime) {
      var t = Date.parse(endtime) - Date.parse(new Date());
      var seconds = Math.floor((t / 1000) % 60);
      var minutes = Math.floor((t / 1000 / 60) % 60);
      var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
      //var hours = Math.floor(t / (1000 * 60 * 60));
      var days = Math.floor(t / (1000 * 60 * 60 * 24));
      return {
        total: t,
        days: days,
        hours: hours,
        minutes: minutes,
        seconds: seconds,
      };
    },

    initializeClock(id, endtime) {
      function updateClock() {
        var t = getTimeRemaining(endtime);
        this.day = t.days;
        this.hour = ("0" + t.hours).slice(-2);
        this.minute = ("0" + t.minutes).slice(-2);
        this.seconds = ("0" + t.seconds).slice(-2);

        if (t.total <= 0) {
          clearInterval(timeinterval);
        }
      }
      updateClock();
      var timeinterval = setInterval(updateClock, 1000);
    },

    rejected() {
      axios
        .get(
          "/tutor/respond-to-session/" + type + "/" + tutID + "/?action=reject"
        )
        .then((res) => {
          document
            .querySelector(`.works [data-tutid=${tutID}]`)
            .classList.remove("accepted")
            .classList.add("rejected");
          toggleModal();
        })
        .catch((err) => {
          console.log(err);
        });
    },

    accepted() {
      axios
        .get(
          "/tutor/respond-to-session/" + type + "/" + tutID + "/?action=reject"
        )
        .then((res) => {
          document
            .querySelector(`.works [data-tutid=${tutID}]`)
            .classList.remove("rejected")
            .classList.add("accepted");
          toggleModal();
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },

  created() {
    this.getTimeRemaining();
    if (assgdeadline) {
      var deadline = new Date("assgdeadline.isoformat");
      initializeClock("clockdiv", deadline);
    }

    if (minstarttime) {
      var deadline1 = new Date(minstarttime.isoformat);
      initializeClock("clockdiv1", deadline1);
    }
  },
  mounted() {
    this.asslist = this.$root.userData.asslist;
    this.bsslist = this.$root.userData.bsslist;
    console.log("asslist :" + this.asslist);
  },
  template: `
 
    <div class="modal-cover">
    <div class="assign-details p-4 shadow b-r-pill bg-white">
        <a class="modal-close" onclick="toggleModal()">&times;</a>
        <div class="header">
          <div class="my-auto">
              <h4 class="text-uppercase" id="subject-name"></h4>
              <small id="assID"></small><br>
              <small id="duration"></small>
          </div>
          <!--  <div class="calendar shadow-sm">
                <p  class="px-2 mb-0 monthName">PM</p>
                <p  class="px-2 mb-0 dayName"> 12:02</p>
            </div>-->
            <div class="d-flex gap-12 calendar-container">
                <div class="calendar shadow-sm">
                    <p  class="px-2 mb-0 monthName" id="time-heading"></p>
                    <p  class="px-2 dayNumber time" id="time"></p>
                    <p  class="px-2 year mb-1" id="clock"></p>
 
                </div>
                <div class="calendar shadow-sm">
                    <p  class="px-2 mb-0 monthName" id="month"></p>
                    <p  class="px-2 mb-0 dayName" id="day"></p>
                    <p  class="px-2 dayNumber" id="day-number"></p>
                </div>
            </div>
        </div>
        <div class="body mt-2">
            <div class="row">
                <div class="col-md-6" id="question-container">
                    <p class=" p-1 bg-light shadow-sm fs-small"><i class="fas fa-question-circle mr-1 text-muted"></i>Question</p>
                    <div id="question" >
 
                    </div>
                </div>
                <div class="col-md-6 mt-2 mt-md-0 mt-lg-0" id="ref-container">
                    <p class="p-1 bg-light shadow-sm fs-small"><i class="fas fa-layer-group mr-1 text-muted"></i> Reference</p>
                   <div id="ref">
 
                   </div>
                </div>
            </div>
            <div class="mt-2 text-muted">
                <p class="fs-small mb-2" id="note-container">
                   <span class="font-weight-600">NOTE:</span> <span id="note"></span>
                </p>
            </div>
            <div class="text-muted">
                <p class=" mb-0 fs-small">
                    If you want to ask anything regarding this <span id="type"></span>, close the popup and click on the chat button.
                </p>
                <table class="fs-small mt-1">
                    <!--<tr class="d-none">
                        <td class="d-flex">
                            <i class="fas fa-user fa-sm mr-2 my-auto"></i>Manager <span class="float-right">:</span>
                        </td>
                        <td>
                            <span class="text-capitalize ml-2 my-auto" id="manager"></span>
                        </td>
                    </tr>-->
                    <tr>
                        <td class="d-flex">
                            <i class="fas fa-phone fa-sm mr-2 my-auto"></i>Phone <span class="float-right">:</span>
                        </td>
                        <td>
                            <a href="tel:+91-7082686818" class="ml-2" id="phone"></a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="footer mt-4">
            <button class="btn btn-outline-danger shadow-sm mr-1" id="reject" @click="rejected()">Not Interested &times;</button>
            <button class="btn btn-outline-success  shadow-sm ml-1" id="accept" @click="accepted()">Interested &#10003;</button>
        </div>
 
    </div>
 </div>

 <div class="file-viewer-modal">
 <embed :src="data_src" :data-id="embed_id" :data-type="data_type" :data-name="data_name" :data-assign="data_assign" >
</div>

<!--availeble details-->
<div id="availabledetails" class="responsive-pd-x">
    <div class="mob-view">
        <div class="d-flex mb-2">
            <i class="fas fa-book mr-2  text-green my-auto"></i><h4 class="my-auto">Homework assignment</h4>
        </div>
        <div v-if="asslist" class="card-group works">
       
          
            <div v-for="atut in asslist"  @click='getInfo(atut.id,"a",atut.assignment.id)' :data-assId="atut.assignment.id" :data-tutid="atut.id" class="card-list" :class="atut.action == 'r'?'rejected':atut.action == 'a'? 'accepted' :'' ">
                <div class="card-image">
                    <img :src="'static/media/branchicons/'+atut.assignment.branch ? atut.assignment.branch : 'Misc'+'.svg'" alt="" @error="onerr">
                </div>
                <div class="card-container">
                    <label>{{atut.assignment.subject}}</label>
                    <img src="static/tutor/images/comment.svg" alt="" class="chat-image" @click.stop="dd += 1;changeselected(atut.atr.id, 'tutor', atut.assignment.id - atut.assignment.subject)">
                    <span>ID: {{atut.assignment.id}}</span>
                    <div class="d-flex justify-content-between w-100 subject-footer">
                        <span><i class="fas fa-calendar-alt mr-1"></i>{{moment(atut.assignment.deadline).format('ll')}} {{moment(atut.assignment.deadline).format('LTS')}}</span>
                        <span v-if="atut.pay_amount"><i class="fas fa-rupee-sign "></i> {{atut.pay_amount}}</span>
                        <span v-else>Not Decided</span>
                    </div>
                </div>
            </div>
        </div>
            
            <p v-else class="text-center w-100">No assignment available</p>
         
        
        <div class="d-flex mt-3 mt-lg-4  mb-2">
            <i class="fas fa-play-circle  mr-2 text-red my-auto"></i><h4 class="my-auto"> Live session</h4>
        </div>
        <div class="card-group works">
           
            <div v-if="bsslist">
            <div v-for="stut in bsslist" @click='getInfo(stut.id,"s",stut.id)' :data-assId="stut.id" :data-tutid="stut.id" class="card-list" :class="stut.action == 'r'? 'rejected ': stut.action == 'a'? 'accepted' : ''">
                <div class="card-image">
                    <img src="'static/media/branchicons'+stut.session.branch?stut.session.branch : 'Misc'+'.svg'" alt="Image" @error="onerr">
                </div>
                <div class="card-container">
                    <label>{{stut.session.subject}}</label>
                    <img src="stati/tutor/images/comment.svg" alt="" class="chat-image" @click.stop="dd += 1;changeselected(stut.str.id, 'stutor', stut.id - stut.subject)">
                    <span>ID: {{stut.session_id}}</span>
                    <div class="d-flex justify-content-between w-100 subject-footer">
                        <span><i class="fas fa-calendar-alt mr-1"></i>{{moment(stut.session.start_time).format('LTS')}} {{moment(stut.session.start_time).format('LTS')}}</span>
                        <span><i class="fas fa-hourglass-half mr-1 "></i> {{moment(stut.session.end_time).format('LTS')}}</span>
                    </div>
                </div>
            </div>
        </div>
     
            <p v-else class="text-center w-100">No live session available</p>
           
        </div>
    </div>
    <div class=" mb-4 web-view">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">Assignments</a>
            </li>
            <li class="nav-item">
                <a class="nav-link  d-badge " :data-badge="bsslist.length" data-toggle="tab" href="#tabs-2" role="tab">Sessions</a>
            </li>
        </ul><!-- Tab panes -->
    </div>
  
    <div class="tab-content web-view">
        <div class="tab-pane active" id="tabs-1" role="tabpanel">
            <!--    homework session-->
            <div class="responsive-pd bg-white rounded">
                <div class="table-title">
                    <div class="d-flex">
                        <i class="fas fa-book mr-2  text-green my-auto"></i><h4 class="my-auto">Homework assignment</h4>
                    </div>
                    <div class="position-relative search">
                        <input type="text" id="assignmentInput" @keyup="searchData('assignmentInput',atab)" class="form-control badge-pill" placeholder="Search">
                        <i class="fas fa-search search-icon fa-sm"></i>
                    </div>
                </div>
    
    
                <div class="">
                   <!--table component-->
                   <table class="assignmentTable table w-100 works">
                    <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Subject</th>
                        <th scope="col">Deadline</th>
                        <th scope="col">Time</th>
                        <th scope="col">Amount</th>
                        <th scope="col" class="nosort">Chat</th>
                    </tr>
                    </thead>
                    <tbody>
                   
                   
                    <tr v-for="atut in asslist" @click='getInfo(atut.id,"a",atut.assignment.id)' :data-assId="atut.assignment.id" :data-tutid="atut.id" :class="'zoom'+ atut.action == 'r'?'rejected' : atut.action == 'a' ? 'accepted':'' ">
                        <td data-label="ID"   scope="row"  data-toggle="modal" data-target="'#details'+atut.id" style="cursor: pointer;"> {{atut.assignment.id}}</td>
                        <td data-label="Subject"  class="text-capitalize font-weight-600"><img src="'static/media/branchicons/' +atut.assignment.branch + '.svg'" alt="Image" width="40" height="40" class="subject-img" @error="onerr">{{atut.assignment.subject}}<span v-if="atut.task_id > 0" >  {{atut.task_id+1 }}</span></td>
                        <td data-label="Deadline" >{{moment(atut.assignment.deadline).format('ll')}}</td>
                        <td data-label="Time"  class="text-red">{{moment(atut.assignment.deadline).format('LTS')}}</td>
                        <td data-label="Amount" ><span v-if="atut.pay_amount"><i class="fas fa-rupee-sign fa-sm text-muted"></i> {{atut.pay_amount}}</span><span v-else>Not Decided</span></td>
                        <td data-label="Chat" @click.stop="dd += 1;changeselected(atut.atr.id, 'tutor', 'atut.assignment.id - atut.assignment.subject')"><img src="static/tutor/images/comment.svg" alt="chat-icon" width="25" height="25" class="chat-icon"><span :id="'chat-badge-'+atut.atr.id" data-with="tutor" class="badge badge-info" v-if="atut.atutorresponse.atutorchatthread.latest_seen==false && atut.atutorresponse.atutorchatthread.latest_from_admin==False ">1</span></td>
                    </tr>
                  
                   
                    </tbody>
                </table>
                </div>
            </div>
            <button type="button" class="d-none" data-toggle="modal" data-target="#displayMessage" id="popmsg"></button>
        </div>
        <div class="tab-pane" id="tabs-2" role="tabpanel">
            <!--    live session-->
            <div class="responsive-pd bg-white rounded">
                <div class="table-title">
                    <div class="d-flex">
                        <i class="fas fa-play-circle  mr-2 text-red my-auto"></i><h4 class="my-auto"> Live session</h4>
                    </div>
                    <div class="position-relative search">
                        <input type="text" id="sessionInput" class="form-control badge-pill" placeholder="Search" onkeyup="searchData('sessionInput',stab)">
                        <i class="fas fa-search search-icon fa-sm"></i>
                    </div>
                </div>
                <div class="">

                   
                    <table class="table sessionTable w-100 works">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Subject</th>
                            <th scope="col">Date</th>
                            <th scope="col">Start time</th>
                            <th scope="col">Duration</th>
                            <th scope="col" class="nosort">Chat</th>
                        </tr>
                        </thead>
                        <tbody>
                      
                        <tr v-for="stut in bsslist" @click='getInfo(stut.id,"s",stut.id)' :data-assId="stut.id" :data-tutid="stut.id" class="zoom" :class="stut.action == 'r'? 'rejected' : stut.action == 'a' ? 'accepted' : '' ">
                            <td data-label="ID"  scope="row" data-toggle="modal" :data-target="'#sdetails'+stut.id" style="cursor: pointer;"> {{stut.id}}</td>
                            <td data-label="Subject"  class="text-capitalize font-weight-600"><img :src="'static/media/branchicons/'+stut.branch+ '.svg'" alt="Image" width="40" height="40" class="subject-img" @error="onerr">{{stut.subject}}</td>
                            <td data-label="Date" >{{moment(stut.start_time).format('LT')}}</td>
                            <td data-label="Start Time"  class="text-green">{{moment(stut.start_time).format('LT')}}</td>
                            <td data-label="Duration"  class="text-red">{{moment(stut.end_time).format('LT')}}</td>
                            <td data-label="Chat"   @click.stop="dd += 1;changeselected(stut.str.id, 'stutor', 'stut.id - stut.subject')"><img src="static/tutor/images/comment.svg" alt="chat-icon" width="25" height="25" class="chat-icon"><span id="chat-badge-{{atut.atr.id}}" data-with="tutor" class="badge badge-info" v-if="atut.atutorresponse.atutorchatthread.latest_seen==False && atut.atutorresponse.atutorchatthread.latest_from_admin==False">1</span></td>
                        </tr>
                       
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>



</div>
<!-- Modal -->
<div class="modal fade" id="displayMessage" tabindex="-1" role="dialog" aria-labelledby="modalTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Message</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                This assignment is already assigned to another tutor
            </div>
        </div>
    </div>
</div>
<!-- CURRENTLY I USE DUMMY TEXT FOR DEVELOPMENT -->
<div id="extradetails"  class="r-menu">
   
    <!--    NEXT ASSIGNMENT-->
    <div v-if="assgdeadline" class="details-card-group mb-lg-3">
        <div class="d-flex mb-2">
            <i class="fas fa-book mx-1 text-green my-auto"></i>   <h5 class=" p-1 my-auto">Next assignments</h5>
        </div>
        <div class="details-card-deck bg-white border-top-left-r-lg shadow-sm">
            <div class="details-card">
                <img :src="'static/media/branchicons'+ minassgatut.assignment.branch+'.svg' " alt="subject-logo" onerror="if (this.src != 'static/media/branchicons/Misc.svg') this.src = 'media/branchicons/Misc.svg'">
                <div class="d-card-body">
                    <p class="text-capitalize">{{minassgatut.assignment.subject}}</p>
                    <small class="text-muted"><i class="fas fa-clock mr-1"></i>{{moment(minassgatut.assignment.deadline).format('ll')}} {{moment(minassgatut.assignment.deadline).format('LT')}}</small>
                </div>
                <a href="'tutor:assignment'+minassgatut.id" target="_blank" class="arrow-right"> <i class="fa fa-arrow-right my-auto flex-fill text-end" aria-hidden="true"></i></a>
            </div>
            <div class="shadow" id="clockdiv">
                <ul class="p-0 text-center">
                    <li><span class="days">10</span>days</li>
                    <li><span class="hours">02</span>Hours</li>
                    <li><span class="minutes">30</span>Minutes</li>
                    <li><span class="seconds">01</span>Seconds</li>
                </ul>
            </div>
        </div>
    </div>
  
  
    <!--    NEXT SESSION -->
    <div v-if='minstarttime' class="details-card-group">
        <div class="d-flex mb-2">
            <i class="fas fa-play-circle mx-1 text-red my-auto"></i><h5 class="p-1 my-auto">Next session</h5>
        </div>
    <div class="details-card-deck bg-white border-top-left-r-lg shadow-sm">
        <div class="details-card">
            <img src="'static/media/branchicons/'+minsessionstut.branch+'.svg'" alt="subject-logo" @error="onerr">
            <div class="d-card-body">
                <p class="text-capitalize">{{minsessionstut.subject}}</p>
                <small class="text-muted"><i class="fas fa-clock mr-1"></i>{{minsessionstut.start_time|moment().format("MMM Do YY")}} to  {minsessionstut.end_time|moment().format("MMM Do YY") }}</small>
            </div>
            <a href="tutor/session/minsessionstut" target="_blank"> <i class="fa fa-arrow-right my-auto flex-fill text-end" aria-hidden="true"></i></a>
        </div>
        <div class="shadow" id="clockdiv1">
            <ul class="p-0 text-center">
                <li><span class="days">10</span>days</li>
                <li><span class="hours">02</span>Hours</li>
                <li><span class="minutes">30</span>Minutes</li>
                <li><span class="seconds">01</span>Seconds</li>
            </ul>
        </div>
    </div>
</div>

<!--    NOTIFICATIONS -->
    
    <recent-notifications></recent-notifications>
   
</div>
    
    
    
    
    `,
};
