const work={

    data(){
        return{

        }
    },
    methods:{
       
         onerror(){
          if(this.src!='static/media/branchicons/Misc.svg'){
            this.src = 'static/media/branchicons/Misc.svg'
          }
         },
          searchData(id,searchtab){
            searchtab.search($("#"+id).val()).draw();
        }

    },
    template:`
   work component
    <div id="availabledetails" class="responsive-pd-x" :class="{{(atutor.length) ? 'w-100' :''}}" >
    <!--    homework session-->
    <div class="mob-view">
        <div class="d-flex mb-2">
            <i class="fas fa-book mr-2  text-green my-auto"></i><h4 class="my-auto">Homework assignment</h4>
        </div>
        <div class="card-group ">
           
          <div v-if="tutor.length">
            <div for="t in atutor" class="card-list" @click="window.location='tutor/assignment/'+t.id">
                <div class="card-image">
                    <img :src="static/media/branchicons/{{ t.assignment.branch }}.svg" alt="" v-on:error="onerror">
                </div>
                <div class="card-container">
                    <label>{{t.assignment.subject}}</label>
                    <img src="/static/tutor/images/comment.svg" alt="" class="chat-image">
                    <span>ID: {{t.assignment_id}}</span>
                    <div class="d-flex justify-content-between w-100 subject-footer">
                        <span><i class="fas fa-calendar-alt mr-1"></i>{{t.assignment.deadline|date:"jS M"}} {{t.assignment.deadline|date:"H:i"}}</span>
                        <span><i class="fas fa-rupee-sign mr-1 "></i> {{t.amount}}{{t.expert_review?'(For Review)':''}}</span>
                    </div>
                </div>
            </div>
        </div>
          
            <p v-else class="text-center w-100">No assignment available</p>
          
        </div>
        <div class="d-flex mt-3 mt-lg-4  mb-2">
            <i class="fas fa-play-circle  mr-2 text-red my-auto"></i><h4 class="my-auto"> Live session</h4>
        </div>
        <div class="card-group ">
           
            <div v-if="atutor.length">
           
            <div v-for="s in stutor" class="card-list" @click="window.location='tutor/session's.id">
                <div class="card-image">
                    <img src="{% static 'media/branchicons' %}/{{ s.session.branch }}.svg" alt="Image" onerror="{{if (this.src != 'static/media/branchicons/Misc.svg'){ this.src = 'static/media/branchicons/Misc.svg'">
                </div>
                <div class="card-container">
                    <label>{{s.session.subject}}</label>
                    <img src="static/tutor/images/comment.svg" alt="" class="chat-image">
                    <span>ID: {{s.session_id}}</span>
                    <div class="d-flex justify-content-between w-100 subject-footer">
                        <span><i class="fas fa-calendar-alt mr-1"></i>{{s.session.start_time|date:"jS M"}} {{s.session.start_time|date:"H:i"}}</span>
                        <span><i class="fas fa-hourglass-half mr-1 "></i> {{s.session.end_time|date:"H:i"}}</span>
                    </div>
                </div>
            </div>
        </div>
         
            <p v-else class="text-center w-100">No live session available</p>
         
        </div>
    </div>

    <div class="responsive-pd bg-white rounded mb-4 web-view">
        <div class="table-title">
            <div class="d-flex">
                <i class="fas fa-book mr-2  text-green my-auto"></i><h4 class="my-auto">Homework assignment</h4>
            </div>
            <div class="position-relative search">
                <input type="text" id="assignmentInput" class="form-control badge-pill" placeholder="Search" onkeyup="searchData('assignmentInput',atab)">
                <i class="fas fa-search search-icon fa-sm"></i>
            </div>
        </div>
        <div>
            <table class="table assignmentTable">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Deadline</th>
                    <th scope="col">Time</th>
                    <th scope="col">Amount</th>
                    <th scope="col" class="nosort">Chat</th>
                </tr>
                </thead>
                <tbody v-if="atutor.length" class="position-relative">
              
                <div class="deadline right-0 " id="assignment">
                    <div class="arrow-left"></div>
                    <h4 class="text-muted">Deadline in</h4>

                    <div class="countdown py-3">
                        <div class="bloc-time days d-time" data-init-value="0">
                            <span class="count-title">Days</span>

                            <div class="figure days days-1">
                                <span class="top">0</span>
                                <span class="top-back">
                                 <span>0</span>
                                 </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                 <span>0</span>
                                </span>
                            </div>

                            <div class="figure hours days-2">
                                <span class="top">0</span>
                                <span class="top-back">
                                     <span>0</span>
                                      </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                     <span>0</span>
                                    </span>
                            </div>
                        </div>
                        <div class="bloc-time hours h-time" data-init-value="0">
                            <span class="count-title">Hours</span>

                            <div class="figure hours hours-1">
                                <span class="top">0</span>
                                <span class="top-back">
                                 <span>0</span>
                                 </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                 <span>0</span>
                                </span>
                            </div>

                            <div class="figure hours hours-2">
                                <span class="top">0</span>
                                <span class="top-back">
                                     <span>0</span>
                                      </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                     <span>0</span>
                                    </span>
                            </div>
                        </div>

                        <div class="bloc-time min m-time" data-init-value="0">
                            <span class="count-title">Minutes</span>

                            <div class="figure min min-1">
                                <span class="top">0</span>
                                <span class="top-back">
                                    <span>0</span>
                                </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                    <span>0</span>
                                </span>
                            </div>

                            <div class="figure min min-2">
                                <span class="top">0</span>
                                <span class="top-back">
                                     <span>0</span>
                                </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                    <span>0</span>
                                </span>
                            </div>
                        </div>

                        <div class="bloc-time sec s-time" data-init-value="0">
                            <span class="count-title">Seconds</span>

                            <div class="figure sec sec-1">
                                <span class="top">0</span>
                                <span class="top-back">
                                  <span>0</span>
                                </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                   <span>0</span>
                                </span>
                            </div>

                            <div class="figure sec sec-2">
                                <span class="top">0</span>
                                <span class="top-back">
                                  <span>0</span>
                                </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                   <span>0</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
              
                <tr  v-for="t in atutor" @click="window.location= 'tutor/assignment'+{t.id}">
                    <td data-label="ID"  scope="row" class="zoom" :class="{{t.expert_review ? 'expert':''}}" >
                        {{t.assignment_id}}</td>
                    <td data-label="Subject"  class="text-capitalize font-weight-600"><img src="'static/media/branchicons/'+t.assignment.branch.svg"  alt="Image" width="40" height="40" class="subject-img" onerror="if (this.src != 'static/media/branchicons/Misc.svg') this.src = 'static/media/branchicons/Misc.svg'"></span> {{t.assignment.subject}}</td>
                    <td data-label="Deadline" >{{t.assignment.deadline|date:"jS M"}}</td>
                    <td data-label="Time"  class="text-red">{{t.assignment.deadline|date:"H:i"}}</td>
                    <td data-label="Amount" >{{t.amount}} {{t.expert_review?:'(For Review)':''}}</td>
                    <td data-label="Chat"><img src="static/tutor/images/comment.svg" alt="chat-icon" width="25" height="25" class="chat-icon"><span :id="chat-badge-{{t.atutorresponse.id}}" data-with="tutor" class="badge badge-info"></span></td>
                </tr>
              
               
                </tbody>
            </table>
        </div>
    </div>
    <!--    live session-->
    <div class="responsive-pd bg-white rounded web-view">
        <div class="table-title">
            <div class="d-flex">
                <i class="fas fa-play-circle  mr-2 text-red my-auto"></i><h4 class="my-auto"> Live session</h4>
            </div>
            <div class="position-relative search">
                <input type="text" id="sessionInput" class="form-control badge-pill" placeholder="Search" @keyup="searchData('sessionInput',stab)">
                <i class="fas fa-search search-icon fa-sm"></i>
            </div>
        </div>
        <div class="">
            <table class="table sessionTable">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Date</th>
                    <th scope="col">Start time</th>
                    <th scope="col">End time</th>
                    <th scope="col" class="nosort">Chat</th>
                </tr>
                </thead>
                <tbody v-if="stutor.length" class="position-relative">
             
                <div class="deadline right-0 " id="session">
                    <div class="arrow-left"></div>
                    <h4 class="text-muted">Deadline in</h4>

                    <div class="countdown py-3 clock">
                        <div class="bloc-time days d-time" data-init-value="0">
                            <span class="count-title">Days</span>

                            <div class="figure days days-1">
                                <span class="top">0</span>
                                <span class="top-back">
                                 <span>0</span>
                                 </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                 <span>0</span>
                                </span>
                            </div>

                            <div class="figure hours days-2">
                                <span class="top">0</span>
                                <span class="top-back">
                                     <span>0</span>
                                      </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                     <span>0</span>
                                    </span>
                            </div>
                        </div>
                        <div class="bloc-time hours h-time" data-init-value="0">
                            <span class="count-title">Hours</span>

                            <div class="figure hours hours-1">
                                <span class="top">0</span>
                                <span class="top-back">
                                 <span>0</span>
                                 </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                 <span>0</span>
                                </span>
                            </div>

                            <div class="figure hours hours-2">
                                <span class="top">0</span>
                                <span class="top-back">
                                     <span>0</span>
                                      </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                     <span>0</span>
                                    </span>
                            </div>
                        </div>

                        <div class="bloc-time min m-time" data-init-value="0">
                            <span class="count-title">Minutes</span>

                            <div class="figure min min-1">
                                <span class="top">0</span>
                                <span class="top-back">
                                    <span>0</span>
                                </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                    <span>0</span>
                                </span>
                            </div>

                            <div class="figure min min-2">
                                <span class="top">0</span>
                                <span class="top-back">
                                     <span>0</span>
                                </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                    <span>0</span>
                                </span>
                            </div>
                        </div>

                        <div class="bloc-time sec s-time" data-init-value="0">
                            <span class="count-title">Seconds</span>

                            <div class="figure sec sec-1">
                                <span class="top">0</span>
                                <span class="top-back">
                                  <span>0</span>
                                </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                   <span>0</span>
                                </span>
                            </div>

                            <div class="figure sec sec-2">
                                <span class="top">0</span>
                                <span class="top-back">
                                  <span>0</span>
                                </span>
                                <span class="bottom">0</span>
                                <span class="bottom-back">
                                   <span>0</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
              
                <tr v-for="s in stutor" @click="window.location='tutor/session/{{s.id}}'">
                    <td data-label="ID"  scope="row" class="zoom" >
                        {{s.session_id}}</td>
                    <td data-label="Subject"  class="text-capitalize font-weight-600"><img :src="static/media/branchicons/{{ s.session.branch }}.svg" width="40" height="40" class="subject-img" alt="Image" @error="if(this.src != 'static/media/branchicons/Misc.svg') {this.src = 'static/media/branchicons/Misc.svg'}"></span> {{s.session.subject}}</td>
                    <td data-label="Date" >{{s.session.start_time|date:"jS M"}}</td>
                    <td data-label="Start Time"  class="text-green">{{s.session.start_time|date:"H:i"}}</td>
                    <td data-label="End Time"  class="text-red">{{s.session.end_time|date:"H:i"}}</td>
                    <td data-label="Chat" ><img src="static/tutor/images/comment.svg" alt="chat-icon" width="25" class="chat-icon" height="25"><span :id="chat-badge-{{t.atutorresponse.id}}" data-with="tutor" class="badge badge-info"></span></td>
                </tr>
             
               
                </tbody>
            </table>
        </div>
    </div>
</div>

    `
}