const payment={

    data(){
        return{
            redeemable:'',
            tutorprofile:[],
            paymentmode:'',
            redeemed:[]
        }
    },
    methods:{
        checkPaymentMode() {
            var mode= $("#payment-mode").find(":selected").text();
            if(mode == 'Bank')
            {
                $("#dynamic-form").empty().append(form);
            }
            else if(mode == 'UPI')
            {
                $("#dynamic-form").empty().append(' <div class="form-group">\n' +
                    '                                      <label for="upi-id">UPI ID</label>\n' +
                    '                                      <input type="text" class="form-control" id="upi-id"   name="upi-id"  :value="tutorprofile.upi_id">\n' +
                    '                                  </div>');
            }
        }
    },
    mounted(){
         this.redeemable=this.$root.userData.tutorprofile.balance;
         this.tutorprofile=this.$root.userData.tutorprofile;
         console.log("this.tutorprofile")
    },
    computed:{

        





    },




    template:  `
   
    <div class="main-container ">
    <div class="row mt-lg-5">
        <div class=" col-lg-12">
            <div class="payment-profile">
                <div class="display ">
                    <h1 class="position-relative">Redeemable & Total earning <i
                            class="fas fa-info-circle payment-info cursor-pointer" data-toggle="modal"
                            data-target="#paymentInfo"></i></h1>
                    <h2>{{redeemable}} / {{tutorprofile.balance}} INR</h2>
                </div>
                <div class="withdrawal">

                    <form v-if="tutorprofile.bank_ac" class="my-2" name="redeem" role="form"
                        action="/tutor/redeemmoney" method="post" enctype="multipart/form-data">

                        <div class="payment-row">
                            <input type="text" class="form-control" name="amount" id="amount1" pattern="^[0-9.]*$"
                                placeholder="Enter Amount to Redeem" autocomplete="off">
                            <button class="btn  shadow-sm fs-small"><i
                                    class="fas fa-coins  mr-2"></i>Redeem</button>
                        </div>
                    </form>

                </div>

                <div v-if="!tutorprofile.bank_ac"><i class="fas fa-exclamation-triangle text-red mr-2"></i><span
                        class="text-red font-weight-bold">Add your account details to get started with
                        payments</span></div>
                <small class="d">*30% of the money earned will be kept on hold for next 10 days. Meanwhile, the
                    solutions will be reviewed by the student.
                    In case of improper solutions, money might be deducted from your account.</small>
            </div>
        </div>
        <div class="col-lg-12 ">
            <div class="tabs">
                <!--                first tab-->
                <div class="tab-2">
                    <label for="tab2-1" class="text-capitalize tab-label"><i
                            class="fas fa-file-invoice mr-2 fa-lg text-base"></i> Payment details</label>
                    <input id="tab2-1" name="tabs-two" type="radio" :checked="!formerror ? checked :'' ">
                    <div>
                        <table class="table paymentTable">
                            <thead>
                                <tr>
                                    <th scope="col">Trans. ID</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">TDS</th>
                                    <th scope="col">Current Balance</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr for="m in redeemed">
                                    <td data-label="Trans. ID">{{m.transid ? m.transid : m.reqid.fields.0}}</td>





                                    <td data-label="Date">{{ m.time}}</td>
                                    <!-- <td data-label="Date">{{ m.time|date:"M j, H:i" }}</td> -->
                                    <td data-label="Status" style="text-transform: capitalize;">{{m.status}}</td>

                                    <td v-if="m.status=='transferred'" class="amount text-base" data-label="Amount">
                                        <span>&#8377; </span>{{ m.amount }}</td>

                                    <td v-else-if="m.status=='earned'" class="amount text-green"
                                        data-label="Amount"><span>&#43; &#8377; </span>{{ m.amount }}</td>

                                    <td v-else-if="m.status='updated'" class="amount" data-label="Amount">
                                        <strike><span>&#43; &#8377; </span>{{ m.amount }}</strike></td>

                                    <td v-else class="amount text-red" data-label="Amount"><span>&#45; &#8377;
                                        </span>{{ m.amount }}</td>

                                    <td v-if="m.tds" class="amount amount-orange">&#45; &#8377;
                                        {{parseFloat(m.tds).toFixed(2)}}</td>
                                    <td class="amount text-muted font-weight-bold" data-label="Current Balance">
                                        <span> &#8377; </span>{{ parseFloat(m.current_balance).toFixed(2)}}</td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
                <!--                second tab-->
                <!--            if not user.tutorprofile.razorx_id -->
                <!-- {% with acc_status=tutorprofile.razorx_id %} -->

                <div class="tab-2">
                    <label for="tab2-2" class="text-capitalize tab-label"><i
                            class="fas fa-user-circle mr-2 fa-lg text-base"></i> Accounts Info</label>
                    <input id="tab2-2" name="tabs-two" type="radio" :checked="formerror ? checked :'' ">
                    <div>
                        <div class="w-75 mx-auto">
                            <form action="tutor/payment" method="post" enctype="multipart/form-data">
                                <!-- {% csrf_token %} -->
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="payment-mode">Payment mode</label>
                                        <select v-model="paymentmode" id="payment-mode" class="form-control"
                                            name="mode" :disabled="!acc_status=='None'">
                                            <option>Choose...</option>
                                            <option :selected="tutorprofile.mode == 'Bank' ">Bank</option>
                                            <!-- <option {%if tutorprofile.mode == 'UPI' %} selected{%endif%}>UPI</option> -->
                                        </select>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="pan-number">PAN Number</label>
                                        <input type="text" class="form-control" id="pan-number"
                                            placeholder="Enter Your PAN Number" :value="tutorprofile.pan" disabled>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="pan-name">Name on PAN</label>
                                        <input type="text" class="form-control" id="pan-name"
                                            :readonly="!acc_status == None" :value="tutorprofile.nameonpan"
                                            disabled>
                                    </div>
                                </div>
                                <div v-if="paymentmode == 'Bank'" id="dynamic-form">
                                    <div class="form-group">
                                         <label for="acc-name">Name in Account</label>
                                         <input type="text" class="form-control" minlength="3" id="acc-name"
                                            required :readonly="!acc_status == None" name="ac_name"
                                            :value="tutorprofile.ac_name" pattern="[a-z A-Z]+"
                                            @invalid="this.setCustomValidity(\'Field accepts only alphabets\')"
                                            @input="setCustomValidity(\'\')"> {{form.errors.ac_name}}
                                         </div>
                                     <div class="form-row">
                                         <div class="form-group col-md-6">
                                             <label for="acc-number">Bank Account Number</label>
                                             <input minlength="5" maxlength="35" inputmode="numeric"
                                                pattern="[0-9]*" autocomplete="off"
                                                :type="!user.tutorprofile.razorpay_id ? 'password' :'text'"
                                                class="form-control" id="acc-number" required name="bank_ac"
                                                :readonly="!acc_status == None ? true :false "
                                                :value="tutorprofile.bank_ac"
                                                @invalid="this.setCustomValidity(\'Please Enter valid account number\')"
                                                @input="setCustomValidity(\'\')">
                                             </div>
                                        
                                         <div v-if="acc_status == None" class="form-group col-md-4"
                                            id="acc-confirm">
                                             <label for="acc-confirm">Confirm Account Number</label>
                                             <input minlength="5" maxlength="35" inputmode="numeric"
                                                pattern="[0-9]*" autocomplete="off" type="text" class="form-control"
                                                required name="acc-confirm"
                                                @invalid="this.setCustomValidity(\'Please Enter valid account number\')"
                                                @input="setCustomValidity(\'\')">
                                             </div>
                                        
                                         <div class="form-group col-md-2">
                                             <label for="acc-ifsc">IFSC Code</label>
                                             <input type="text" required class="form-control" id="acc-ifsc"
                                                name="ifsc" :readonly="acc_status!= None"
                                               :value="tutorprofile.ifsc">
                                             </div>
                                         </div>

                                </div>

                                <div v-if="paymentmode == 'UPI'">
                                    <div class="form-group">
                                        <label for="upi-id">UPI ID</label>
                                        <input type="text" class="form-control" id="upi-id" name="upi-id"
                                            :value="tutorprofile.upi_id">
                                    </div>
                                </div>





                                <div class="">

                                    <span v-if="formerror" class="text-red">{{formerror}}</span>

                                </div>
                                <div class="form-row">
                                    <div class="col-12 d-flex justify-content-center">
                                        <button type="submit" id="update_payment" class="btn btn-light shadow-sm"
                                            :disabled="!acc_status == None">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="paymentInfo" tabindex="-1" aria-labelledby="paymentInfoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="paymentInfoLabel">Payment Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table w-100 table-borderless">
                    <thead class="thead-light">
                        <tr>
                            <th colspan="2">
                                Balance
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="font-weight-600">
                            <td>Money Earned in previous 10 days</td>
                            <td class="text-end">{{earned_recently}}{{earned_recently ? INR :''}} </td>
                        </tr>
                        <tr class="font-weight-600">
                            <td>Money on hold (30% of {{earned_recently? earned_recently + 'INR' : 'money earned' }}
                                )</td>
                            <td class="text-end"> {{on_hold}} {{on_hold? 'INR' :''}}</td>
                        </tr>
                    </tbody>
                </table>
                <table class="table w-100 table-borderless">
                    <thead class="thead-light">
                        <tr>
                            <th colspan="2">
                                TDS
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="font-weight-600">
                            <td>Total TDS filed by Tutorbin on your behalf</td>
                            <td class="text-end">{{tutorprofile.tds}} INR</td>
                        </tr>
                        <tr class="font-weight-600">
                            <td>TDS to be filed by Tutorbin on your behalf</td>
                            <td class="text-end"> {{tds}} {{tds ? 'INR' : ''}} </td>
                        </tr>
                    </tbody>
                </table>
                <span class="font-weight-bold d-block pl-12 ">Note :</span>
                <ul class="payment-note">
                    <li>Register on the <a href="https://www.incometaxindiaefiling.gov.in/home"
                            target="_blank">portal</a>. Check for Form 26A on the portal, you will get details
                        related to TDS deposited on your behalf. </li>
                    <li class="mt-1">portal home -> form 26A -> abcd -> asfsda</li>
                </ul>
            </div>
        </div>
    </div>
</div>

    `
}