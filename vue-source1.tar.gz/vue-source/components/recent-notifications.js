const recent_notifications={

    template:`
    <div class="details-card-group side-notification mt-3">
        <div class="d-flex mb-2">
            <i class="fas fa-bell text-yellow mx-1 my-auto"></i> <h5 class=" p-1 my-auto"> Recent notifications</h5>
        </div>
        <div class="side-notificaction-container">
            <template v-for="notif in notifs">
                <a href="/tutor/dashboard/" v-if="notif.ntype == 'newWorkAvailable'" @click.prevent="setStorage(notif.wid,'/tutor/dashboard/')">
                    <div class="details-card" :class="[notif.seen == true || notif.seen == 'True' ? 'read' : '']">
                        <div class="d-card-body">
                            <p class="text-capitalize font-weight-bold text-base2">[[notif.atitle]]</p>
                            <small class="text-muted">[[notif.msg]]</small>
                            <small class="text-muted"><i class="far fa-clock mr-1"></i>[[notif.time]]</small>
                        </div>
                    </div>
                </a>
                <a :href="'/tutor/assignment/'+notif.wid" v-else-if="notif.wt == 'a' || notif.wt == 'expS' || notif.ntype == 'expertassigned'">
                    <div class="details-card" :class="[notif.seen == true || notif.seen == 'True' ? 'read' : '']">
                        <div class="d-card-body">
                            <p class="text-capitalize font-weight-bold text-base2">[[notif.atitle]] </p>
                            <small class="text-muted">[[notif.msg]]</small>
                            <small class="text-muted"><i class="far fa-clock mr-1"></i>[[notif.time]]</small>
                        </div>
                    </div>
                </a>
                <a :href="'/tutor/session/'+notif.wid" v-else-if="notif.wt == 's'">
                    <div class="details-card" :class="[notif.seen == true || notif.seen == 'True' ? 'read' : '']">
                        <div class="d-card-body">
                            <p class="text-capitalize font-weight-bold text-base2">[[notif.atitle]] </p>
                            <small class="text-muted">[[notif.msg]]</small>
                            <small class="text-muted"><i class="far fa-clock mr-1"></i>[[notif.time]]</small>
                        </div>
                    </div>
                </a>
                <a v-else>
                    <div class="details-card" :class="[notif.seen == true || notif.seen == 'True' ? 'read' : '']">
                        <div class="d-card-body">
                            <p class="text-capitalize font-weight-bold text-base2">[[notif.atitle]] </p>
                            <small class="text-muted">[[notif.msg]]</small>
                            <small class="text-muted"><i class="far fa-clock mr-1"></i>[[notif.time]]</small>
                        </div>
                    </div>
                </a>
            </template>
        </div>
    </div>
    
    `
}