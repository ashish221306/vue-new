const asignement_info_modal={
    data(){
return{
   
}
    },

  


   template:`
   
   <div class="modal-cover">
   <div class="assign-details p-4 shadow b-r-pill bg-white">
       <a class="modal-close" onclick="toggleModal()">&times;</a>
       <div class="header">
         <div class="my-auto">
             <h4 class="text-uppercase" id="subject-name"></h4>
             <small id="assID"></small><br>
             <small id="duration"></small>
         </div>
         <!--  <div class="calendar shadow-sm">
               <p  class="px-2 mb-0 monthName">PM</p>
               <p  class="px-2 mb-0 dayName"> 12:02</p>
           </div>-->
           <div class="d-flex gap-12 calendar-container">
               <div class="calendar shadow-sm">
                   <p  class="px-2 mb-0 monthName" id="time-heading"></p>
                   <p  class="px-2 dayNumber time" id="time"></p>
                   <p  class="px-2 year mb-1" id="clock"></p>

               </div>
               <div class="calendar shadow-sm">
                   <p  class="px-2 mb-0 monthName" id="month"></p>
                   <p  class="px-2 mb-0 dayName" id="day"></p>
                   <p  class="px-2 dayNumber" id="day-number"></p>
               </div>
           </div>
       </div>
       <div class="body mt-2">
           <div class="row">
               <div class="col-md-6" id="question-container">
                   <p class=" p-1 bg-light shadow-sm fs-small"><i class="fas fa-question-circle mr-1 text-muted"></i>Question</p>
                   <div id="question" >

                   </div>
               </div>
               <div class="col-md-6 mt-2 mt-md-0 mt-lg-0" id="ref-container">
                   <p class="p-1 bg-light shadow-sm fs-small"><i class="fas fa-layer-group mr-1 text-muted"></i> Reference</p>
                  <div id="ref">

                  </div>
               </div>
           </div>
           <div class="mt-2 text-muted">
               <p class="fs-small mb-2" id="note-container">
                  <span class="font-weight-600">NOTE:</span> <span id="note"></span>
               </p>
           </div>
           <div class="text-muted">
               <p class=" mb-0 fs-small">
                   If you want to ask anything regarding this <span id="type"></span>, close the popup and click on the chat button.
               </p>
               <table class="fs-small mt-1">
                   <!--<tr class="d-none">
                       <td class="d-flex">
                           <i class="fas fa-user fa-sm mr-2 my-auto"></i>Manager <span class="float-right">:</span>
                       </td>
                       <td>
                           <span class="text-capitalize ml-2 my-auto" id="manager"></span>
                       </td>
                   </tr>-->
                   <tr>
                       <td class="d-flex">
                           <i class="fas fa-phone fa-sm mr-2 my-auto"></i>Phone <span class="float-right">:</span>
                       </td>
                       <td>
                           <a href="tel:+91-7082686818" class="ml-2" id="phone"></a>
                       </td>
                   </tr>
               </table>
           </div>
       </div>
       <div class="footer mt-4">
           <button class="btn btn-outline-danger shadow-sm mr-1" id="reject" onclick="rejected()">Not Interested &times;</button>
           <button class="btn btn-outline-success  shadow-sm ml-1" id="accept" onclick="accepted()">Interested &#10003;</button>
       </div>

   </div>
</div>
   
   
   `

   
}