const table_data={
    props:['tableclass','tabledata'],
      data(){
        
          return{
              list:[],
             
          }
      },
     methods:{
         getInfo(type,tutID,assID){
             axios.get(`/tutor/explore/${type}/${tutID}/`).then((response)=>{
              console.log("res from axios: "+response)
             }).catch((err)=>{
               console.log(err)
             })
         }
     },
     filters:{

     },
 mounted(){
     this.asslist=this.$root.userData.asslist;
    

 }

     ,

    template:`

    <table :class="tableclass">
    <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Subject</th>
                        <th scope="col">Deadline</th>
                        <th scope="col">Time</th>
                        <th scope="col">Amount</th>
                        <th scope="col" class="nosort">Chat</th>
                    </tr>
    </thead>
    <tbody>
    <tr v-for="atut in asslist" @click='getInfo(atut.id,"a",atut.assignment.id)' :data-assId="atut.assignment.id" :data-tutid="atut.id" class="zoom" :class="atut.action == 'r'? rejected : atut.action == 'a'? accepted: null ">
    <td data-label="ID"   scope="row"  data-toggle="modal" :data-target="'#details'+atut.id" style="cursor: pointer;"> {{atut.assignment.id}}</td>
    <td data-label="Subject"  class="text-capitalize font-weight-600"><img :src="'/static/media/branchicons/'+atut.assignment.branch+'.svg'" alt="Image" width="40" height="40" onerror="if (this.src != 'static/media/branchicons/Misc.svg') this.src = '/static/media/branchicons/Misc.svg'" class="subject-img" >{{atut.assignment.subject}}<span v-if="atut.task_id > 0">(Part {{atut.task_id + 1}})</span></td>
    <td data-label="Deadline" >{{atut.assignment.deadline}}</td>
    <td data-label="Time"  class="text-red">{{atut.assignment.deadline}}</td>
    <td data-label="Amount" ><span v-if="atut.pay_amount"><i class="fas fa-rupee-sign fa-sm text-muted"></i> {{atut.pay_amount}}</span><span v-else>Not Decided</span></td>
    <td data-label="Chat" @click.stop="dd += 1;changeselected(atut.atr.id, 'tutor', atut.assignment.id - atut.assignment.subject)"><img src="/static/tutor/images/comment.svg" alt="chat-icon" width="25" height="25" class="chat-icon"><span  >1</span></td>
    </tr> 
  
   
    </tbody>
</table>
    
    
    `
}