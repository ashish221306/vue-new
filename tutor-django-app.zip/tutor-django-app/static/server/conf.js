const hostt = 'localhost:8001';
const protocoll = 'ws://';
