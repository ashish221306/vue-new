source ../env/bin/activate
pip3 uninstall -y -r apps.txt
pip3 install -r repos.txt

