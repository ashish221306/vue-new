from django import template
from tutor.widgets import admin_mobile_list

register = template.Library()

def manager_phone(value):
    try:
        return admin_mobile_list[value]
    except:
        return None

register.filter('manager_phone',manager_phone)
