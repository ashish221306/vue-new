from rest_framework import serializers
from .models import TutorProfile,TSubjects
from portal.models import ATask,ATutorResponse,QA,RA,ATutor,Session,STutorResponse,RS,Assignment,STutor
from portal.serializers import ATutorChatThreadSerializer
import json

class AssignmentSerializer(serializers.ModelSerializer):
    
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(AssignmentSerializer, self).__init__(*args, **kwargs)

        if remove_fields:
            # for multiple fields in a list
            for field_name in remove_fields:
                self.fields.pop(field_name)
    
    class Meta:
        model = Assignment
        fields = '__all__'

class SimpleSessionSerializer(serializers.ModelSerializer):
    
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(SimpleSessionSerializer, self).__init__(*args, **kwargs)

        if remove_fields:
            # for multiple fields in a list
            for field_name in remove_fields:
                self.fields.pop(field_name)
    
    class Meta:
        model = Session
        fields = '__all__'

class ATutorSerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(ATutorSerializer, self).__init__(*args, **kwargs)

        if remove_fields:
            for field_name in remove_fields:
                self.fields.pop(field_name)
    
    assignment = AssignmentSerializer(many=False,read_only=True)

    class Meta:
        model = ATutor
        fields = '__all__'

class STutorSerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(STutorSerializer, self).__init__(*args, **kwargs)

        if remove_fields:
            for field_name in remove_fields:
                self.fields.pop(field_name)
    
    session = SimpleSessionSerializer(many=False,read_only=True)

    class Meta:
        model = STutor
        fields = '__all__'

class TSubjectsSerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(TSubjectsSerializer,self).__init__(*args, **kwargs)

        if remove_fields:
            for field_name in remove_fields:
                self.fields.pop(field_name)

    class Meta:
        model = TSubjects
        fields = '__all__'


class TutorProfileSerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(TutorProfileSerializer,self).__init__(*args, **kwargs)

        if remove_fields:
            for field_name in remove_fields:
                self.fields.pop(field_name)

    class Meta:
        model = TutorProfile
        fields = '__all__'


class QASerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(QASerializer,self).__init__(*args, **kwargs)

        if remove_fields:
            for field_name in remove_fields:
                self.fields.pop(field_name)

    class Meta:
        model = QA
        fields = '__all__'

class RASerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(RASerializer,self).__init__(*args, **kwargs)

        if remove_fields:
            for field_name in remove_fields:
                self.fields.pop(field_name)

    class Meta:
        model = RA
        fields = '__all__'

class RSSerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(RSSerializer,self).__init__(*args, **kwargs)

        if remove_fields:
            for field_name in remove_fields:
                self.fields.pop(field_name)

    class Meta:
        model = RS
        fields = '__all__'


class ATutorResponseSerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(ATutorResponseSerializer, self).__init__(*args, **kwargs)

        if remove_fields:
            # for multiple fields in a list
            for field_name in remove_fields:
                self.fields.pop(field_name)
    

    atutor = ATutorSerializer(many=False, read_only=True)


    # closecount = serializers.SerializerMethodField('interested_close')
    # lastfive = serializers.SerializerMethodField('int_lfive')

    # def interested_close(self,tutor_resps):
    #     try:
    #         clscnt = tutor_resps.closecount
    #     except AttributeError:
    #         clscnt = "N/A"
    #     return clscnt

    # def int_lfive(self,tutor_resps):
    #     try:
    #         lfive = tutor_resps.lastfive
    #     except AttributeError:
    #         lfive = "N/A"
    #     return lfive



    # tutor = TutorProfileSerializer(many=False, read_only=True)
    class Meta:
        model = ATutorResponse
        fields = '__all__'




class ATaskSerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(ATaskSerializer, self).__init__(*args, **kwargs)

        if remove_fields:
            # for multiple fields in a list
            for field_name in remove_fields:
                self.fields.pop(field_name)
        

    filters = serializers.SerializerMethodField('filters_field')
    atr = serializers.SerializerMethodField('atr_field')
    action = serializers.SerializerMethodField('action_field')
    qa = serializers.SerializerMethodField('qa_field')
    ra = serializers.SerializerMethodField('ra_field')
    atutorresponse  = serializers.SerializerMethodField('atutorresponse_field')
    # atutorresponse  = ATutorChatThreadSerializer(many=True,read_only=True)



    def atutorresponse_field(self,task):
        try:
            atutorresponse = ATutorResponseSerializer(task.atutorresponse,read_only = True).data
        except AttributeError:
            atutorresponse = None
        return atutorresponse

    def ra_field(self,task):
        try:
            ra = RASerializer(task.ra,many=True,read_only=True,remove_fields=['assignment']).data
        except AttributeError:
            ra = []
        return ra

    def qa_field(self,task):
        try:
            qa = QASerializer(task.qa,many=True,read_only=True,remove_fields=['assignment']).data
        except AttributeError:
            qa = []
        return qa

    def action_field(self,task):
        try:
            act = task.action
        except AttributeError:
            act = "N/A"
        return act

    def filters_field(self,task):
        return json.loads(task.filters)
    
    def atr_field(self,task):
        try:
            atr = ATutorResponseSerializer(task.atr,read_only=True).data
        except AttributeError:
            atr = "N/A"
        return atr

    assignment = AssignmentSerializer(many=False,read_only = True)

    class Meta:
        model = ATask
        fields = '__all__'

class STutorResponseSerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(STutorResponseSerializer, self).__init__(*args, **kwargs)

        if remove_fields:
            # for multiple fields in a list
            for field_name in remove_fields:
                self.fields.pop(field_name)

    tutor = TutorProfileSerializer(many=False, read_only=True)
    stutor = STutorSerializer(many=False,read_only = True)

    class Meta:
        model = STutorResponse
        fields = '__all__'

class SessionSerializer(serializers.ModelSerializer):
    def __init__(self, *args, **kwargs):
        remove_fields = kwargs.pop('remove_fields', None)
        super(SessionSerializer,self).__init__(*args, **kwargs)

        if remove_fields:
            # for multiple fields in a list
            for field_name in remove_fields:
                self.fields.pop(field_name)

    str = STutorResponseSerializer(many=False, read_only=True)
    rs = serializers.SerializerMethodField('rs_field')
    action = serializers.SerializerMethodField('action_field')
    filters = serializers.SerializerMethodField('filters_field')


    def rs_field(self,session):
        try:
            rs = RASerializer(session.rs,many=True,read_only=True,remove_fields=['assignment']).data
        except AttributeError:
            rs = []
        return rs
    
    def action_field(self,session):
        try:
            act = session.action
        except AttributeError:
            act = "N/A"
        return act
    
    def filters_field(self,session):
        return json.loads(session.filters)



    class Meta:
        model = Session
        fields = '__all__'

