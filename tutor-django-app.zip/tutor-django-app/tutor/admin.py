from django.contrib import admin
from django.utils.html import format_html
from .models import TutorProfile, TSubjects, RedeemMoney, AllTutNotif, Books, TimeSlot

def activate_accounts(modeladmin, request, queryset):
    for query in queryset:
        user = query.user
        user.is_active = True
        user.save()
def deactivate_accounts(modeladmin, request, queryset):
    for query in queryset:
        user = query.user
        user.is_active = False
        user.save()
activate_accounts.short_description = "Activate accounts"
deactivate_accounts.short_description = "Deactivate accounts"

class VerifyPanAndDegree(TutorProfile):
    class Meta:
        proxy = True
class TutorProfileAdmin(admin.ModelAdmin):
    list_display = ['name','phone','whatsapp','university','get_active']
    search_fields = ['name','user__username','phone','whatsapp','user__email']
    ordering = ('-user__date_joined',)
    list_filter = ('tested','verified',)
    readonly_fields = ('newtest',)
    raw_id_fields = ('user','referred_by',)
    list_per_page = 50
    actions = (activate_accounts,deactivate_accounts)
    def get_active(self, obj):
        return obj.user.is_active
    get_active.short_description = 'Active'
class TutorProfileAdmin1(admin.ModelAdmin):
    def pan_image(self, obj):
        if obj.panpic and not obj.panverified:
            return format_html('<img src="{}" width="400"/>'.format(obj.panpic.url))
    def degree_image(self, obj):
        if obj.degreepic and not obj.degreeverified:
            return format_html('<img src="{}" width="400"/>'.format(obj.degreepic.url))
    list_display = ['name','pan','pan_image','highest_degree','department','specialisation','degree_image','panverified','degreeverified']
    search_fields = ['name','user__username','phone','whatsapp','user__email', 'id']
    ordering = ('-user__date_joined',)
    list_per_page = 10
    list_editable = ('panverified','degreeverified',)
    readonly_fields = ('newtest',)
    raw_id_fields = ('user','referred_by',)
class TSubjectsAdmin(admin.ModelAdmin):
    list_display = ['userprofile','branch','subject','selected','tested']
    search_fields = ['userprofile__name','subject']
    raw_id_fields = ('userprofile',)
class RedeemAdmin(admin.ModelAdmin):
    list_display = ['userprofile','time','amount','current_balance']
    search_fields = ['userprofile__name']
    raw_id_fields = ('userprofile',)

admin.site.register(TutorProfile, TutorProfileAdmin)
admin.site.register(VerifyPanAndDegree, TutorProfileAdmin1)
admin.site.register(TSubjects,TSubjectsAdmin)
admin.site.register(RedeemMoney,RedeemAdmin)
admin.site.register(AllTutNotif)
admin.site.register(Books)
admin.site.register(TimeSlot)
