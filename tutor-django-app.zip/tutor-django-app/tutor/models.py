from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.validators import MinValueValidator, MaxValueValidator
import uuid


def bookuploadpath(instance, filename):
    return 'Books/{0}/{1}/{2}/'.format(str(instance.branch).replace(' ','_'), str(instance.subject).replace(' ','_'), filename)


def profileuploadpath(instance, filename):
    try:
        return 'Profile/{0}/{1}/'.format(str(instance.user.id).replace(' ','_'),filename)
    except:
        return 'Profile/{0}/{1}/'.format(str(instance.user.id).replace(' ','_'),'dp')

def panuploadpath(instance, filename):
    try:
        return 'PAN/{0}/{1}/'.format(str(instance.user.id).replace(' ','_'),filename)
    except:
        return 'PAN/{0}/{1}/'.format(str(instance.user.id).replace(' ','_'),'pan')

def degreeuploadpath(instance, filename):
    try:
        return 'degree/{0}/{1}/'.format(str(instance.user.id).replace(' ','_'),filename)
    except:
        return 'degree/{0}/{1}/'.format(str(instance.user.id).replace(' ','_'),'degree')


class TutorProfile(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, null=True, blank=True)
    phone = models.CharField(max_length=100, null=True, blank=True)
    whatsapp = models.CharField(max_length=20, null=True, blank=True)
    verified = models.BooleanField(default=False)
    tested = models.BooleanField(default=False)
    expert = models.BooleanField(default=False)
    agreed = models.BooleanField(default=False)
    newtest = models.BooleanField(default=False)
    star = models.BooleanField(default=False)
    expert = models.BooleanField(default=False)
    protutor = models.BooleanField(default=False)
    inactive = models.BooleanField(default=False)
    university = models.CharField(max_length=200, null=True, blank=True)
    department = models.CharField(max_length=100, null=True, blank=True)
    specialisation = models.CharField(max_length=100, null=True, blank=True)
    highest_degree = models.CharField(max_length=100, null=True, blank=True)
    degreeverified = models.BooleanField(default=False)
    degreepic = models.FileField(blank=True, null=True, upload_to=degreeuploadpath, max_length=500)
    balance = models.FloatField(null=True, blank=True, default=0)
    tds = models.FloatField(default=0)
    #mode = models.CharField(max_length=20, null=True, blank=True)
    mode = models.CharField(max_length=20, null=True, blank=True, default='Bank')
    nameonpan = models.CharField(max_length=200, null=True, blank=True)
    pan = models.CharField(max_length=20, null=True, blank=True)
    panpic = models.FileField(blank=True, null=True, upload_to=panuploadpath, max_length=500)
    panverified = models.BooleanField(default=False)
    #number = models.CharField(max_length=20, null=True, blank=True)
    #upi = models.CharField(max_length=20, null=True, blank=True)
    ac_name = models.CharField(max_length=40, null=True, blank=True)
    bank_ac = models.CharField(max_length=30, null=True, blank=True)
    ifsc = models.CharField(max_length=20, null=True, blank=True)
    razorpay_id = models.CharField(max_length=20, null=True, blank=True, default=None)
    razorx_id = models.CharField(max_length=20, null=True, blank=True, default=None)
    rating = models.FloatField(null=True, blank=True, default=0)
    firebase_token = models.CharField(max_length=500, null=True, blank=True, default=None)
    absent_count = models.IntegerField(default=0)
    makhaya_count = models.IntegerField(default=0)
    allow_sub_update = models.BooleanField(default=False)
    request_sub_update = models.BooleanField(default=False)
    total_sessions = models.IntegerField(default=0)
    subs_list = models.CharField(blank=True, null=True, max_length=100)
    avatar = models.CharField(blank=True,null=True,max_length=2)
    referral_code = models.CharField(max_length=50, blank=True, null=True)
    referred_by = models.ForeignKey('self', blank=True, null=True, on_delete=models.SET_NULL)
    profilepic = models.FileField(blank=True, null=True, upload_to=profileuploadpath, max_length=500)
    countrycode = models.CharField(max_length=100, null=True, blank=True)
    total_earned = models.FloatField(default=0)
    last_help = models.DateTimeField(null=True,blank=True)
    interest_count = models.PositiveSmallIntegerField(default=0)
    form_factor = models.CharField(max_length=50,null=True,blank=True)#[[atut_id,atud_rating],[4256,4.56],[4535,3.78]]

    class Meta:
        ordering = ('name',)

    def __str__(self):
        return str(self.name) +' | ' + str(self.whatsapp)


#@receiver(post_save, sender=User)
#def create_user_profile(sender, instance, created, **kwargs):
#    if created:
#        TutorProfile.objects.create(user=instance)


#@receiver(post_save, sender=User)
#def save_user_profile(sender, instance, **kwargs):
#    instance.tutorprofile.save()


class RedeemMoney(models.Model):
    userprofile = models.ForeignKey(TutorProfile, null=True, on_delete=models.CASCADE)
    amount = models.FloatField(null=True, blank=True)
    status = models.CharField(max_length=100, null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True)
    account = models.CharField(max_length=200, null=True, blank=True)
    reqid = models.UUIDField(default=uuid.uuid4, editable=False)
    transid = models.CharField(max_length=200, null=True, blank=True)
    tds = models.FloatField(null=True, blank=True)
    current_balance = models.FloatField(null=True, blank=True)
    smartpind = models.BooleanField(default=False)
    class Meta:
        ordering = ('-time',)
    def __str__(self):
        return str(self.userprofile) + ' - ' + str(self.amount)


class TSubjects(models.Model):
    userprofile = models.ForeignKey(TutorProfile, null=True, on_delete=models.CASCADE)
    branch = models.CharField(blank=True, max_length=50)
    subject = models.CharField(max_length=100, null=True, blank=True)
    rating = models.FloatField(null=True, blank=True, default=0.01)
    selected = models.BooleanField(default=True)
    tested = models.BooleanField(default=False)
    failed = models.BooleanField(default=False)

    class Meta:
        ordering = ('branch','subject',)

    def __str__(self):
        return self.userprofile.name + '-' + self.subject


class Books(models.Model):
    branch_list = (
        ("Chemical Engineering","Chemical Engineering"),
        ("Chemistry","Chemistry"),
        ("Civil","Civil"),
        ("Economics","Economics"),
        ("Electrical and Electronics","Electrical and Electronics"),
        ("Mathematics","Mathematics"),
        ("Mechanical","Mechanical"),
        ("Misc","Misc"),
        ("Physics","Physics"),
        ("Software Works","Software Works")
    )
    bookname = models.CharField(blank=True, max_length=50)
    branch = models.CharField(blank=True, max_length=50, choices=branch_list)
    subject = models.CharField(max_length=100, null=True, blank=True)
    bookfile = models.FileField(blank=True, null=True, upload_to=bookuploadpath)

    def __str__(self):
        return str(self.id) + ' - ' + str(self.branch) + ' - ' + str(self.subject)

    def extension(self):
        extension = self.bookfile.name.split('.')[-1]
        return extension


class TimeSlot(models.Model):
    slot = models.IntegerField(unique=True)
    range = models.CharField(max_length=20, null=True, blank=True)
    tutors = models.ManyToManyField(TutorProfile, blank=True)

    def __str__(self):
        return self.range

class AllTutNotif(models.Model):
    detail = models.CharField(max_length=250)

    def __str__(self):
        return str(self.detail)
