from django import forms
from django.contrib.auth.models import User
from portal.models import AA
from .models import TutorProfile, TSubjects, RedeemMoney


class AAForm(forms.ModelForm):

    class Meta:
        model = AA
        fields = ['answer', 'comment']


#class ASForm(forms.ModelForm):

#    class Meta:
#        model = AS
#        fields = ['answer', 'comment']


class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def clean_username(self):
        username = self.cleaned_data.get('username').lower()
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError(u'Username already registered.')
        return username
    def clean_email(self):
        email = self.cleaned_data.get('email')
        username = self.cleaned_data.get('username')
        if email and User.objects.filter(email=email).exclude(username=username).exists():
            raise forms.ValidationError(u'Email addresses must be unique.')
        return email


class ProfileForm(forms.ModelForm):

    class Meta:
        model = TutorProfile
        fields = ['name', 'university', 'department', 'degreepic', 'specialisation', 'highest_degree']

    # def clean_phone(self):
    #     phone = self.cleaned_data.get('phone')
    #     if hasattr(self,'id'):
    #         if phone and TutorProfile.objects.filter(phone=phone).exclude(id = self.id).exists():
    #             raise forms.ValidationError(u'Phone no. already registered')
    #     elif phone and TutorProfile.objects.filter(phone=phone,verified=True).exists():
    #         raise forms.ValidationError(u'Phone no. already registered')
    #     return phone

class ProfileForm1(forms.ModelForm):

    class Meta:
        model = TutorProfile
        fields = ['whatsapp', 'university']



class SubjectsForm(forms.ModelForm):

    class Meta:
        model = TSubjects
        fields = ['branch', 'subject']


class PaymentForm(forms.ModelForm):

    class Meta:
        model = TutorProfile
        fields = ['pan', 'ac_name', 'bank_ac', 'ifsc', 'razorpay_id', 'razorx_id', 'mode']


class RedeemMoneyForm(forms.ModelForm):

    class Meta:
        model = RedeemMoney
        fields = ['amount']
