function openmodal1() {
  document.getElementById('mymodal1').style.display = "flex";
}

function close1modal1() {
  window.parent.hideFileModal();


}


function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "flex";
  dots[slideIndex-1].className += " active";
  var targetDemo = $(dots[slideIndex-1]);
  var container = $('#iconrow');
  var scrollVal = $(targetDemo).position().left-$(container).width()/2+$(targetDemo).width()/2;
  if (scrollVal>1 || scrollVal<1){
    $(container).animate({scrollLeft:'+='+scrollVal},500);
  }


}
document.onkeydown = function(evt) {
    evt = evt || window.event;
    var isEscape = false;
    if ("key" in evt) {
        isEscape = (evt.key == "Escape" || evt.key == "Esc");
    } else {
        isEscape = (evt.keyCode == 27);
    }
    if (isEscape) {
        close1modal1();
    }
    if(evt.keyCode == 39){
      plusSlides(1);
    }
    else if(evt.keyCode == 37){
      plusSlides(-1);
    }
};


function removeq(filename,id){
    $('.deleteModalFileName').html(filename);
    $('#confirmDeleteModal').modal('show');
    // $('.deleteConfirmBtn').attr('data-url','/deletefile/?type='+$(this).parent().data('type')+'&id='+$(this).parent().data('id'));
    $('.deleteConfirmBtn').data('id',id);
    $('.deleteConfirmBtn').data('type',filetype);
}

// {{baseurl}}/portal/checkplagiarism/{{model}}/{{q.id}}/
function plagModal(filename,filetype,id){
    $('.plagFileName').html(filename);
    $('#plagmodal').modal('show');
    $('.plagConfirmBtn').data('id',id);
    $('.plagConfirmBtn').data('type',filetype);
}

$('.plagConfirmBtn').click(function(){
  var type =$(this).data('type');
  var id = $(this).data('id');
  // $('.plagConfirmBtn').hide()
  $('.loadShadow').show()
  $.ajax({ // create an AJAX call...
    type: 'GET', // GET or POST
    url: '/portal/checkplagiarism/'+type+'/'+id,
    success: function(response) { // on success..
      if(response.success == true){
        $('.loadShadow').hide()
        $('#plagmodal').modal('hide');
        $("#plag"+type+id).prop("onclick", null).off("click").html('<span class="fa fa-file-contract fa-fw"></span> Generating Report');
      }
      else{
        $('.loadShadow').hide()
        $('#plagmodal').modal('hide');
        alertError(true)
      }
    },
    error: function(err){alertError(true)}
  })
  // window.location.href = '/portal/checkplagiarism/'+type+'/'+id
})

function alertError(reload){
  $('#loader-div').hide();
  flashAlert(false,'', reload);
}
function flashAlert(isSuccess,message, reload){
  if(isSuccess){
    var element = '<div class="position-absolute w-100 alertbox"><div class="alert alert-success alert-dismissible alert-autodismiss"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Success!</strong> '+message+'</div></div>';
  }
  else{
    if(message=='')
     message = 'Please try again';
    var element = '<div class="position-absolute w-100 alertbox"><div class="alert alert-danger alert-dismissible alert-autodismiss"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Something went wrong!</strong> '+message+'</div></div>';
  }
  var shownalert = $('#mymodal1').prepend(element);
  window.setTimeout(function(){$('.alertbox:eq(0)').slideUp(500)},2000)
  setTimeout(function(){
    if (reload) {
      location.reload()
    }
  },1000)
}
$('.deleteConfirmBtn').click(function(){
  var type =$(this).data('type');
  var id = $(this).data('id');
  var url = '/portal/removefiles/?type='+type+'&id='+id
  $('#confirmDeleteModal').modal('hide');
  $('#loaded-div').show()
  $.ajax({ // create an AJAX call...
      type: 'GET', // GET or POST
      url: url,
      success: function(response) { // on success..
        if(response.success == true){
          $('#loader-div').hide();
          // $('.files-input-btn[data-id="'+id+'"][data-type="'+type+'"]',parent.document).remove();
          $('.right.p-1','.mySlides[data-id="'+id+'"]').prepend('<span class="helper mr-2 text-danger">Removed</span>');
          // $('.demo[data-id="'+id+'"],.mySlides[data-id="'+id+'"]').remove();
          // plusSlides(-1);
          flashAlert(true,'File deleted successfully.');
        }
        else{alertError(false)}
      },
      error: function(err){alertError(false)}
  });
})

$('#mymodal1').click(function(evt){
  if(evt.target.id=='mymodal1' || evt.target.id=='iconrow'){
    close1modal1();
  }
})
$('.viewerimage').click(function(){
  $(this).toggleClass(['zoomtowidth','cursor-zoomout']);
})
$('.close2').click(function(){
  $(this).find('.fa').toggleClass(['fa-minus','fa-comment-dots']);
  $(this).toggleClass('show-comment');
  $(this).parent().toggleClass('minimized-caption');
})

function multidown(){
  var link = document.getElementsByClassName('aDownload');

  for (var i = 0; i < link.length; i++) {
    link[i].setAttribute('target','_blank');
    console.log(link[i]);
    link[i].click();
    link[i].removeAttribute('target');
  }
}
$(document).ready(function (){
    var id=window.parent.findEmbedID();
    $("[data-id="+ id +"]").click();
})
