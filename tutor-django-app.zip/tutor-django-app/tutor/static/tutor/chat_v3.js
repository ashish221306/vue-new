/*  TUTOR API RESPONSE
* assignment: {pk: 4284, subject: "Testing"}
atr:
    assignment: 4284
    atutor: 14273
    id: 758395
    open: true
    status: 6
    tutor: 83
__proto__: Object
chat: Array(5)
0: {message: "hello ", seen: true, sender: 39, from_name: "admin", timestamp: "29 Oct, 11:14 AM"}
1: {message: "text again", seen: true, sender: 39, from_name: "admin", timestamp: "29 Oct, 11:18 AM"}
2: {message: "kfhdfhogifdvhfv'polgjad", seen: true, sender: 39, from_name: "admin", timestamp: "29 Oct, 11:19 AM"}
3: {message: "hgfhkjlh", seen: true, sender: 39, from_name: "admin", timestamp: "29 Oct, 11:21 AM"}
4: {message: "gsfdsf", seen: true, sender: 39, from_name: "admin", timestamp: "29 Oct, 11:22 AM"}

*/
/* STUTOR API RESPONSE
{
    chat: Array(9), str: {…}, session: {…}, user: 83}
    chat: (9) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
    session: {pk: 11, subject: "Solid Works"}
    str: {id: 17, tutor: 83, stutor: 22249, status: 6, open: true, …}
    user: 83
}
 */
var replyClass=""; // FOR IDENTIFYING MESSAGE TYPE
var float="";
var el=''; // USED FOR APPEND HTML ELEMENT
function chat_open(atr_id, withh) {
    $('.messages').empty();
    if (withh == 'tutor') {
        fetch(tchatboxurl + '?atr_id='+atr_id)
        .then(response => response.json())
        .then(data => {
            var t2 = JSON.parse(data);
            var chats = t2.chat // ALL CHATS
            var oldchat = t2.oldchat    // BOOLEAN
            var assignment = t2.assignment // INFORMATION ABOUT SUBJECT AND ASSIGNMENT ID
            var atr = t2.atr
            var userId = t2.user

            getMessages(assignment,chats,atr_id,withh,userId);

        })
    } else if (withh == 'stutor') {


        fetch(stchatboxurl + '?str_id='+atr_id)
        .then(response => response.json())
        .then(data => {
            var t2 = JSON.parse(data)
            var chats = t2.chat // all chats
            var session = t2.session // subject and id
            var str = t2.str // some information
            var userId = t2.user
            getMessages(session,chats,atr_id,withh,userId);
        })
    }
    $(".chat-app_content").animate({ scrollTop: $('.chat-app_content').prop("scrollHeight")}, 1000);
}

function getMessages(obj,chats,atr_id,withh,userId) {
    $('.messages').empty();
    $('.title').empty().text(obj.pk + ' - ' + obj.subject);
    $.each(chats,(index,chat)=>{
        if (chat.sender == userId)
        {
            replyClass="";
            float="justify-content-end"
        }else{
            replyClass="reply";
            float="justify-content-start"
        }
        if (replyClass == 'reply'){
            el+='<div><small class="'+float+' text-muted">'+chat.timestamp +'</small>'+'<div class="message '+replyClass+'">'+'<p class="text">'+chat.message+'</p>'+ '</div></div>';
        }else{
            el+='<div><div class="message '+replyClass+'">'+'<p class="text">'+chat.message+'</p>'+ '</div>'+' <small class="'+float+' text-muted">'+chat.timestamp +'</small></div>';
        }
    });
    $(".messages").empty().append(el);
    el="";
    toggleChat();
    if (window.location.href.includes('assignment') || window.location.href.includes('session')) {
        if (window.location.href.includes('?chat')) {
            $(".chat-input").focus()
        }
    } else {
        $(".chat-input").focus()
    }
    activateClickListnerChat();
    seencheck = true;
    seemsg(atr_id, withh);
    $(".send").attr('data-ass',atr_id);
    $(".send").attr('data-with',withh);
    $(".chat-app_content").animate({ scrollTop: $('.chat-app_content').prop("scrollHeight")}, 1000);
}
