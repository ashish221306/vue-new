// var chatSocket = new ReconnectingWebSocket(
//     protocoll + hostt +
//     '/ws/student/' + user_id + '/');


const vueApp = Vue.createApp({
    delimiters: ['[[', ']]'],
    

});

const vm = vueApp.mount('#vueapp');
