const countdown = {
    name: 'countdown',

    mounted() {
        window.setInterval(() => {
            this.now = Math.trunc((new Date()).getTime() / 1000);
        }, 1000);
    },
    props: {
        date: {
            type: String
        }
    },
    data() {
        return {
            number: [],
            now: Math.trunc((new Date()).getTime() / 1000)
        }
    },

    filter: {
        two_digits: function (value) {

            if (value < 0) {
                return '00';
            }
            if (value.toString().length <= 1) {
                return `0${value}`;
            }
            return value;


        }

    },


    computed: {
        dateInMilliseconds() {
            return Math.trunc(Date.parse(this.date) / 1000)
        },
        seconds() {
            return (this.dateInMilliseconds - this.now) % 60;
        },
        minutes() {
            return Math.trunc((this.dateInMilliseconds - this.now) / 60) % 60;
        },
        hours() {
            return Math.trunc((this.dateInMilliseconds - this.now) / 60 / 60) % 24;
        },
        days() {
            return Math.trunc((this.dateInMilliseconds - this.now) / 60 / 60 / 24);
        }
    }
    ,
    methods: {
        two_digits(value) {

            if (value < 0) {
                return '00';
            }
            if (value.toString().length <= 1) {
                return `0${value}`;
            }
            return value;


        },

        getdigit(num, i) {
            this.number = String(num).split("").map((num) => {
                return Number(num)
            })

            return this.number[i]
        }

    }

    ,
    template: `
    <ul v-if="this.$route.name=='dashboard'" class="p-0 text-center">
                <li><span class="days">{{ two_digits(days) }}</span>days</li>
                <li><span class="hours">{{two_digits(hours)}}</span>Hours</li>
                <li><span class="minutes">{{two_digits(minutes) }}</span>Minutes</li>
                <li><span class="seconds">{{two_digits(seconds)}}</span>Seconds</li>
    </ul>
    
   
    
    
    
    `
}


