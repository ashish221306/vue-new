const nextassign={
    name:'nextassign',
    props:{
        listdata:{
            type:Object
        },
        type:{
            type:String
        }
    },

mounted(){

    if(this.type=='assign'){
        initializeClock('clockdiv',this.listdata.assignment.deadline)
    }else{
        initializeClock('clockdiv1',this.listdata.time)

    }


}

    ,
    template:`
   
    <div class="details-card-group" :class="type=='assign'? 'mb-lg-3' : '' ">
        <div class="d-flex mb-2">
            <i  class="fas  mx-1 text-green my-auto" :class="type=='assign' ? 'fa-book text-green' :'fa-play-circle text-red' "></i>   <h5 class=" p-1 my-auto">{{type=='assign' ? 'Next assignments' : ' Next sessions '}}</h5>
        </div>
        <div class="details-card-deck bg-white border-top-left-r-lg shadow-sm">
            <div class="details-card ">
            
               <template v-if="type=='assign'">
               <img :src="this.$root.staticUrl+'/media/branchicons'+ listdata.assignment.branch + '.svg' " alt="subject-logo" @error="this.$root.onerr">
               <div class="d-card-body">
                   <p class="text-capitalize">{{listdata.assignment.subject}}</p>
                   <small class="text-muted"><i class="fas fa-clock mr-1"></i>{{ this.$root.momentfilter(listdata.assignment.deadline,'LL')}} {{ this.$root.momentfilter(listdata.assignment.deadline,'LT')}}</small>
               </div>
               </template>
               <template v-else>
               <img :src="this.$root.staticUrl+'/media/branchicons/'+listdata.branch+'.svg'" alt="subject-logo" @error=" this.$root.onerr">
            <div class="d-card-body">
                <p class="text-capitalize">{{listdata.subject}}</p>
                <small class="text-muted"><i class="fas fa-clock mr-1"></i>{{ this.$root.momentfilter(listdata.start_time,"LL")}} to  {{ this.$root.momentfilter(listdata.end_time,'LL') }}</small>
            </div>
               </template>
                <a :href="'/tutor/'+  type=='assign' ? 'assignment/' :'session/' +listdata.id" target="_blank" class="arrow-right"> <i class="fa fa-arrow-right my-auto flex-fill text-end" aria-hidden="true"></i></a>
            </div>


          


            <div class="shadow" :id="type=='assign'? 'clockdiv' : 'clockdiv1' ">
            <ul class="p-0 text-center">
                        <li><span class="days"></span>days</li>
                        <li><span class="hours"></span>Hours</li>
                        <li><span class="minutes"></span>Minutes</li>
                        <li><span class="seconds"></span>Seconds</li>
            </ul>
            </div>

           
        </div>
    </div>
    
    `
}




function getTimeRemaining(endtime) {
    var t = Date.parse(endtime) - Date.parse(new Date());
    if(t<0)
    t=0;
    var seconds = Math.floor((t / 1000) % 60);
    var minutes = Math.floor((t / 1000 / 60) % 60);
    var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
    //var hours = Math.floor(t / (1000 * 60 * 60));
    var days = Math.floor(t / (1000 * 60 * 60 * 24));
    return {
        'total': t,
        'days': days,
        'hours': hours,
        'minutes': minutes,
        'seconds': seconds
    };
}

function initializeClock(id, endtime) {
    var clock = document.getElementById(id);
    var daysSpan = clock.querySelector('.days');
    var hoursSpan = clock.querySelector('.hours');
    var minutesSpan = clock.querySelector('.minutes');
    var secondsSpan = clock.querySelector('.seconds');

    function updateClock() {
        var t = getTimeRemaining(endtime);
        daysSpan.innerHTML = t.days;
        hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
        minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
        secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

        if (t.total <= 0) {
            t.total=0
            clearInterval(timeinterval);
        }
    }
    updateClock();
    var timeinterval = setInterval(updateClock, 1000);

}