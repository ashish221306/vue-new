const table_data = {
    name: 'table_data',
    props: ['listtype', 'listdata'],

    methods: {
        callfunction(id, type, assid, time) {
            if (this.$route.name == 'dashboard') {
                this.$parent.getInfo(id, type, assid, time)
            } else {
                this.$router.push = `/tutor/session/${id}`
            }
        }

        , getduration(et,st) {
            var startTime = moment(st, 'YYYY-MM-DDThh:mm:ssTZD')
            var endTime = moment(et, 'YYYY-MM-DDThh:mm:ssTZD')
            var h = moment(endTime.diff(startTime)).format("hh:mm:ss");
            return h
        }


    },
    created() {
         
            
    }
    ,

    template: `
    <div class="table-title">
    <div class="d-flex">
        <i class="fas mr-2  my-auto" :class="listtype=='asslist'? 'fa-book text-green' : 'fa-play-circle text-red' "></i><h4 class="my-auto">{{listtype=='asslist'? 'Homework assignment' : 'Live Session'}}</h4>
    </div>
    <div class="position-relative search">
        <input type="text" class="form-control badge-pill" placeholder="Search">
        <i class="fas fa-search search-icon fa-sm"></i>
    </div>
</div>
    <table class="table w-100 works" :class="listtype == 'asslist' ? 'assignmentTable' :'sessionTable'">
    <thead>
    <tr>
        <th scope="col">ID</th>
        <th scope="col">Subject</th>

        <template v-if="listtype=='asslist'">
        <th scope="col">Deadline</th>
        <th scope="col">Time</th>
        <th scope="col">Amount</th>
        </template>
       
       <!-- <template v-else-if="listtype=='sessionlist'">
        <th scope="col">Date</th>
        <th scope="col">Start Time</th>
        <th scope="col">End time</th>
        </template> -->

       <template v-else>
       <th scope="col">Date</th>
       <th scope="col">Start Time</th>
       <th scope="col">Duration</th>
       </template>
     <th scope="col" class="nosort">Chat</th>
    
     </tr>
    </thead>
    <tbody class="position-relative">
   <tr v-if="listtype=='asslist'" v-for="atut in listdata" @click='callfunction(atut.id,"a",atut.assignment.id,atut.assignment.deadline)'  class="zoom" :class="atut.action == 'r' ? 'rejected' : (atut.action == 'a' ? 'accepted':'' )">
   <td data-label="ID"   scope="row"  data-toggle="modal" data-target="'#details'+atut.id" style="cursor: pointer;"> {{atut.assignment.id}}</td>
   <td data-label="Subject"  class="text-capitalize font-weight-600"><img :src="this.$root.staticUrl+'/media/branchicons/' +atut.assignment.branch + '.svg'" alt="Image" width="40" height="40" class="subject-img" @error="this.$parent.onerr">{{atut.assignment.subject}}<span v-if="atut.task_id > 0 " >  {{atut.task_id+1 }}</span></td>
   <td data-label="Deadline" >{{this.$root.momentfilter(atut.assignment.deadline,'Do MMM')}}</td>
   <td data-label="Time"  class="text-red">{{this.$root.momentfilter(atut.assignment.deadline,'HH:MM')}}</td>
   <td data-label="Amount" ><span v-if="atut.pay_amount"><i class="fas fa-rupee-sign fa-sm text-muted"></i> {{atut.pay_amount}} {{ this.$route.name=='dashboard' ? ( atut.expert_review ? '(For Review)':'') : '' }}</span><span v-else>Not Decided</span></td>
   <td data-label="Chat" @click.stop="this.$root.$refs.chatvue.changeselected(atut.atr.id, 'tutor', atut.assignment.id +'-'+ atut.assignment.subject) "><img :src="this.$root.staticUrl+'/tutor/images/comment.svg' " alt="chat-icon" width="25" height="25" class="chat-icon"><span :id="'chat-badge-'+atut.atr.id"  class="badge badge-info" v-if="atut.atutorresponse">1</span></td>
   </tr>


   

 <tr v-if="listtype=='bsslist' " v-for="stut in listdata" @click="callfunction(stut.id,'s',stut.id,stut.start_time)" class="zoom" :class="stut.action == 'r' ? 'rejected' : (stut.action == 'a' ? 'accepted' : '') ">
 <td data-label="ID"  scope="row" data-toggle="modal" :data-target="'#sdetails'+stut.id" style="cursor: pointer;"> {{stut.id}}</td>
 <td data-label="Subject"  class="text-capitalize font-weight-600"><img :src="this.$root.staticUrl+'/media/branchicons/' + stut.branch + '.svg' " alt="Image" width="40" height="40" class="subject-img" @error="this.$parent.onerr">{{stut.subject}}</td>
 <td data-label="Date" >{{this.$root.momentfilter(stut.start_time,'Do MMM')}}</td>
 <td data-label="Start Time"  class="text-green">{{this.$root.momentfilter(stut.start_time,'HH:MM')}}</td>
 <td data-label="Duration"  class="text-red">{{getduration(stut.end_time,stut.start_time)}}</td>
 <td data-label="Chat"  @click.stop="this.$root.$refs.chatvue.changeselected(stut.str.id, 'stutor', stut.id +'-'+ stut.subject)"><img :src="this.$root.staticUrl+'/tutor/images/comment.svg' " alt="chat-icon" width="25" height="25" class="chat-icon"><span id="chat-badge-{{atut.atr.id}}" data-with="tutor" class="badge badge-info" v-if="stut.atutorresponse">1</span></td>
 </tr>



 <tr v-if="listtype=='sessionlist'" v-for="stut in listdata" @click="callfunction(stut.id,'s',stut.id,stut.session.start_time)" class="zoom" :class="stut.action == 'r' ? 'rejected' : (stut.action == 'a' ? 'accepted' : '') ">
 <td data-label="ID"  scope="row" data-toggle="modal" :data-target="'#sdetails'+stut.id" style="cursor: pointer;"> {{stut.id}}</td>
 <td data-label="Subject"  class="text-capitalize font-weight-600"><img :src="this.$root.staticUrl+'/media/branchicons/' + stut.session.branch + '.svg' " alt="Image" width="40" height="40" class="subject-img" @error="this.$parent.onerr">{{stut.session.subject}}</td>
 <td data-label="Date" >{{this.$root.momentfilter(stut.session.start_time,'Do MMM')}}</td>
 <td data-label="Start Time"  class="text-green">{{this.$root.momentfilter(stut.session.start_time,'HH:MM')}}</td>
 <td data-label="Duration"  class="text-red">{{this.$root.momentfilter(stut.session.end_time,'HH:MM')}}</td>
 <td data-label="Chat"><img :src="this.$root.staticUrl+'/tutor/images/comment.svg'" alt="chat-icon" width="25" height="25" class="chat-icon"><span id="chat-badge-{{atut.atr.id}}"  class="badge badge-info" v-if="stut.atutorresponse">1</span></td>
 </tr>
</tbody>
</table>
    
    
    `
}

