const chat_component={
    name:'chat-component',
    data(){
        return{
            loader:true,
            user_id: user_id ? user_id : false,
            chatData: {},
            selected: false,
            reply_to: false,
            // dd: 0,
          
            chatSocket: null,
            notifs: [],
            chat_notifs: [],
        
            unreadnotifs: 0,
            unreadchatnotifs: 0,
            sound:Boolean,
        }
      },
      created() {
          // Requesting for web notifications
          // Notification.requestPermission()
          //     .then((res)=>{
          //             if(res === "granted"){
          //                 this.sound=true
          //             }else{
          //                 this.sound=false;
          //             }
          //     });
          this.sound = true;
  
          this.chatSocket = new ReconnectingWebSocket(
              protocoll + hostt +
              '/ws/tutor/' + user_id + '/');
          this.chatSocket.onopen = () => {
          }
          this.chatSocket.onmessage = (e) => {
              var data = JSON.parse(e.data)
              if (data.type == "chat_message") {
                  this.addmessage(data)
              } else if (data.type == 'notif') {
                  if (data.ntype != 'chat_notif') {
                      this.addNotifs([data])
                     if (this.sound){
                         $(window).focus()
                         $("#notifSound")[0].play()
                     }
                  } else {
                      this.chat_notifs = this.chat_notifs.filter(n => n.atr_id != data.atr_id)
                      this.addchatNotifs([data])
                      if (this.sound){
                          $(window).focus()
                          $("#msgSound")[0].play()
                      }
                  }
              } else if (data.type == 'seen') {
                  let notif = this.chat_notifs.find(n => n.atr_id == data.ass && n.with == data.with)
                  // console.log(notif)  let promise = Notification.requestPermission();
                  if (notif)
                      notif.seen = true
                  this.unreadchatnotifs = this.chat_notifs.filter(n => n.seen == false || n.seen == 'False').length
              }
          }
          this.getnotifs();
          this.getchatnotifs();
          // this.getChat();
         setTimeout(function (){
             if(window.location.pathname === '/tutor/dashboard/'){
                 const id =localStorage.getItem('assID');
                 if (id){
                      if($('.web-view').is(':visible')){
                          if ($(`tr[data-assId='${id}']`).length){
                              $(`tr[data-assId='${id}']`).click()
                          }else{
                              $('#popmsg').click()
                          }
                      }else if($('.mob-view').is(':visible')){
                          if ($(`div[data-assId='${id}']`).length){
                              $(`div[data-assId='${id}']`).click()
                          }else{
                              $('#popmsg').click()
                          }
                      }
                     localStorage.removeItem('assID')
                 }
             }
         },500)
      },
      mounted() {
          if (thread_id.length > 0 && type.length > 0 && main_id.length > 0) {
              var d = {}
              d.id = thread_id
              d.type = type
              d.main_id = main_id
              this.selected = d
              // setTimeout(function(){
              //     $("html, body").animate({ scrollTop: $(document).height() - $(window).height() });
              //     $('#chatinput').focus();
              //  }, 500);
          };
      },
      watch: {
          // newMessage(value) {
          //     value ? socket.emit('typing', this.username) : socket.emit('stopTyping')
          // }
          selected: {
              deep: true,
              handler (n, o) {
                  // console.log(this.selected)
                  if (this.selected.id) {
                      this.getChat()
                  }
              }
          }
      },
      methods: {

       
          changeselected(id, type, main_id) {
              const d = {}
              d.id = id
              d.type = type
              d.main_id = main_id
              this.selected = d
          },
          showchatfile() {
              type = this.selected.type == 'tutor' ? 't' : 's'
              showchatfile(this.selected.id, type)
          },
          openChatFileinModal(file_id) {
              type = this.selected.type == 'tutor' ? 't' : 's'
              openChatFileinModal(file_id, this.selected.id, type)
          },
          getnotifs() {
              axios.get('/tutor/checknot/')
              .then((response) => {
                  const data = response.data
                  // console.log(data)
                  if (Array.isArray(data))
                    this.addNotifs(data)
              })
              .catch(function(err){
                  console.log(err)
                  alert('Something went wrong',err);
              })
          },
          getchatnotifs() {
              axios.get('/tutor/checkmsgs/')
              .then((response) => {
                  const data = response.data
                  // console.log(data)
                  if (Array.isArray(data))
                    this.addchatNotifs(data)
              })
              .catch(function(err){
                  console.log(err)
                  alert('Something went wrong',err);
              })
          },
          async getChat() {
              // console.log(this.selected)
              if (this.selected.id) {
                  const url = window.location.href
                  this.chatData = {}
                  await axios.get('/portal/tchatbox_api/?id='+this.selected.id+'&type='+this.selected.type)
                  .then((response) => {
                      const data = JSON.parse(response.data);
                      var assc = {}
                      assc.id = this.selected.id
                      assc.chats = data.chat
                      assc.typing = ''
                      assc.minimize = (url.includes('assignment') || url.includes('session')) ? (window.location.search.includes('?chat') ? false : true) : false
                      assc.reply_to = false
                      assc.seencheck = true
                      this.chatData[this.selected.id] = assc
                      this.loader = false;
                      if (!assc.minimize) {
                          this.seenmsg()
                          setTimeout(function(){
                              $(".chat-app_content").animate({ scrollTop: $('.chat-app_content').prop("scrollHeight")}, 100)
                              $('#chatinput').focus();
                          }, 100);
                      }
                  })
                  .catch(function(err){
                      this.loader = false
                      console.log(err)
                      alert('Something went wrong',err);
                  })
              }
          },
          addmessage(data) {
              if (this.selected && this.selected.id == data.ass) {
                  // console.log(this.chatData[data.ass].chats.length)
                  this.chatData[data.ass].chats.push(data)
                  if (data.from != user_id) {
                      this.chatData[data.ass].seencheck = true
                  }
                  // console.log(this.chatData[data.ass].chats.length)
                  $(".chat-app_content").animate({ scrollTop: $('.chat-app_content').prop("scrollHeight")}, 100);
              }
          },
          sendmessage() {
              if (this.chatData[this.selected.id].typing != "") {
                  this.chatSocket.send(JSON.stringify({
                      // 'type': 'texting',
                      // 'ass': ass_id,
                      // 'message': text,
                      // 'with': 'student',
                      'type': 'msg',
                      'ass': this.selected.id,
                      'message': this.chatData[this.selected.id].typing,
                      'with': this.selected.type,
                      'reply_to': this.chatData[this.selected.id].reply_to ? this.chatData[this.selected.id].reply_to.id : null,
                  }));
                  this.chatData[this.selected.id].typing = ''
                  this.chatData[this.selected.id].reply_to = false
              }
          },
          replyto(id, msg) {
              this.chatData[this.selected.id].reply_to = { 'id': id, 'msg': checkstringorurl(msg) };
              $(".chat-app_content").animate({ scrollTop: $('.chat-app_content').prop("scrollHeight")}, 100);
              $("#chatinput").focus();
          },
          addNotifs(data) {
              const newNotifs = data
              // var unreads = data.filter(n => n.seen == false || n.seen == 'False').length
              const curNotifs = this.notifs
              this.notifs = [...newNotifs, ...curNotifs]
              this.unreadnotifs = this.notifs.filter(n => n.seen == false || n.seen == 'False').length
          },
          addchatNotifs(data) {
              const newNotifs = data
              // var unreads = data.filter(n => n.seen == false || n.seen == 'False').length
              const curNotifs = this.chat_notifs
              this.chat_notifs = [...newNotifs, ...curNotifs]
              this.unreadchatnotifs = this.chat_notifs.filter(n => n.seen == false || n.seen == 'False').length
          },
          readnotifs() {
          
        



              setTimeout(() => {
                  axios.get('/tutor/marknseen/')
                  .then((response) => {
                      this.notifs.forEach(n => n.seen = true);
                      this.unreadnotifs = 0
                  })
                  .catch(function(err) {
                      console.log(err)
                      alert('Something went wrong',err);
                  })
              }, 1500)
          },
          scrollToMsg(id,e){
              e.preventDefault()
              document.getElementById("msg-"+id).scrollIntoView({ behavior: 'smooth', block: 'center' })
              $("#msg-"+id).addClass('intoView');
              setTimeout(()=>{
                  $("#msg-"+id).removeClass('intoView');
              },1500)
          },
          async addfile(event) {
              const files = event.target.files
              for (file in [...Array(files.length).keys()]) {
                  const cm = {
                      'from': this.user_id,
                      'fileno': file,
                      'message': 'https://static.tutorbin.com/static/img/spinner.svg',
                      'filename': files[file].name,
                      'msgtype': 'file',
                      'reply_to_id': null,
                  }
                  this.chatData[this.selected.id].chats.push(cm)
                  $(".chat-app_content").animate({ scrollTop: $('.chat-app_content').prop("scrollHeight")}, 100)
                  params = this.chatData[this.selected.id].reply_to ? '?replyto='+this.chatData[this.selected.id].reply_to.id : ''
                  this.chatData[this.selected.id].reply_to = false
                  var data = new FormData();
                  data.append('file', files[file]);
                  if (this.selected.type == 'tutor') {
                      var url = '/tutor/atchatfileupload/'+this.selected.id+'/'+params
                  } else if (this.selected.type == 'stutor') {
                      var url = '/tutor/stchatfileupload/'+this.selected.id+'/'+params
                  }
  
                  // console.log(url)
                  await axios.post(url, data)
                  .then((response) => {
                      this.chatData[this.selected.id].chats = this.chatData[this.selected.id].chats.filter(n => n.fileno != file)
                      // console.log('dd')
                  })
                  .catch(function(err) {
                      console.log(err)
                  })
              }
          },
          downloadchatfile(id) {
              url = this.selected.type == 'tutor' ? '/tutor/atutorchatfiledownload/'+id+'/' : '/tutor/stutorchatfiledownload/'+id+'/'
              axios.post(url)
              .then((response) => {
                  const data = response.data
                  if (data.success) {
                      window.open(data.url)
                  }
              })
              .catch(function(err){
                  console.log(err)
                  alert('Something went wrong',err);
              })
          },
          texting: _.debounce(function() {
              if (this.chatData[this.selected.id].typing.length >= 0) {
                  // console.log(this.chatData[this.selected.id].typing)
                  this.chatSocket.send(JSON.stringify({
                      'type': 'texting',
                      'ass': this.selected.id,
                      'message': this.chatData[this.selected.id].typing,
                      'with': this.selected.type,
                  }));
              }
              this.seenmsg()
          }, 500),
          seenmsg: _.debounce(function() {
              if (this.chatData[this.selected.id].seencheck) {
                  // console.log('ff')
                  this.chatSocket.send(JSON.stringify({
                      'type': 'seen',
                      'ass': this.selected.id,
                      'with': this.selected.type,
                      'from': this.selected.type,
                  }));
                  this.chatData[this.selected.id].seencheck = false
              }
          }, 500),
          setStorage:(id,url)=>{
              localStorage.setItem('assID',id)
              window.location.href=url;
          }
      },





template:`

<div class="action-icons">
                <!--<span class="shadow-sm" @click="closeSideNav()"> <i class="fas fa-bars fa-lg p-1 text-info" id="nav-icon"></i></span>-->
                <span class="shadow-sm " id="chat-btn" :class="unreadchatnotifs>0?'':'notify-hide'" :data-unread="unreadchatnotifs"  ><i class="fas fa-comment fa-lg p-1 text-warning"></i></span>
                <span class="shadow-sm " id="notify-btn" :data-unread="unreadnotifs" :class="unreadnotifs>0?'':'notify-hide'" @click="readnotifs();"><i class="fas fa-bell fa-lg p-1 text-info"></i></span>
            </div>
            <div class="chat-dialog shadow-sm b-r-pill">
            <h5>Recent chats</h5>
            <hr class="mb-0"/>
            <div class="notify-container" id="chats">
                <div v-if="chat_notifs.length>0">
                    <template v-for="notif in chat_notifs">
                        <a :href="notif.with == 'tutor' ? '/tutor/assignment/'+ notif.atutor +'?chat' : '/tutor/session/'+ notif.atutor +'?chat'"  v-if="notif.atutor != null">
                            <div class="details-card " :class=" notif.seen == true || notif.seen == 'True' ? 'read' : ''" data-ass="chat-notif-a-758399" data-with="stutor">
                                <div class="d-card-body"><p class="text-capitalize font-weight-bold text-base2">{{notif.subject}}</p>
                                    <small class="m-0 p-0 text-xs">{{notif.msg}}</small><small class="text-muted"> <i class="fas fa-hourglass-start mr-1"></i>{{notif.time}}</small>
                                </div>
                            </div>
                        </a>
                        <a v-else @click="changeselected(notif.atr_id, notif.with, notif.subject)" >
                            <div class="details-card " :class=" notif.seen == true || notif.seen == 'True' ? 'read' : ''" data-ass="chat-notif-a-758399" data-with="stutor">
                                <div class="d-card-body"><p class="text-capitalize font-weight-bold text-base2">{{notif.subject}}</p>
                                    <small class="m-0 p-0 text-xs">{{notif.msg}}</small><small class="text-muted"> <i class="fas fa-hourglass-start mr-1"></i>{{notif.time}}</small>
                                </div>
                            </div>
                        </a>
                    </template>
                </div>
                <div v-else>
                    <p class="text-center text-muted py-2 mb-0">No chats</p>
                </div>

            </div>
        </div>


        <div class="notify shadow-sm b-r-pill r-shit">
        <h5>Notifications</h5>
        <hr class="mb-0"/>
        <div class="notify-container" id="notification">
            <div v-if="notifs.length>0">
                <template v-for="notif in notifs">
                    <a href="/tutor/dashboard/" v-if="notif.ntype == 'newWorkAvailable'" @click.prevent="setStorage(notif.wid,'/tutor/dashboard/')">
                        <div class="details-card" :class=" notif.seen == true || notif.seen == 'True' ? 'read' : ''">
                            <div class="d-card-body">
                                <p class="text-capitalize font-weight-bold text-base2">{{notif.atitle}} </p>
                                <small class="text-muted">{{notif.msg}}</small>
                                <small class="text-muted"><i class="far fa-clock mr-1"></i>{{notif.time}}</small>
                            </div>
                        </div>
                    </a>
                    <a :href="'/tutor/assignment/'+notif.wid" v-else-if="notif.wt == 'a' || notif.wt == 'expS' || notif.wt == 'expertassigned'">
                        <div class="details-card" :class="notif.seen == true || notif.seen == 'True' ? 'read' : ''">
                            <div class="d-card-body">
                                <p class="text-capitalize font-weight-bold text-base2">{{notif.atitle}} </p>
                                <small class="text-muted">{{notif.msg}}</small>
                                <small class="text-muted"><i class="far fa-clock mr-1"></i>{{notif.time}}</small>
                            </div>
                        </div>
                    </a>
                    <a :href="'/tutor/session/'+notif.wid" v-else-if="notif.wt == 's'">
                        <div class="details-card" :class=" notif.seen == true || notif.seen == 'True' ? 'read' : ''">
                            <div class="d-card-body">
                                <p class="text-capitalize font-weight-bold text-base2">{{notif.atitle}} </p>
                                <small class="text-muted">{{notif.msg}}</small>
                                <small class="text-muted"><i class="far fa-clock mr-1"></i>{{notif.time}}</small>
                            </div>
                        </div>
                    </a>
                    <a href="/tutor/profile/" v-else-if="notif.wt == 'rs'">
                        <div class="details-card" :class=" notif.seen == true || notif.seen == 'True' ? 'read' : ''">
                            <div class="d-card-body">
                                <p class="text-capitalize font-weight-bold text-base2">{{notif.atitle}} </p>
                                <small class="text-muted">{{notif.msg}}</small>
                                <small class="text-muted"><i class="far fa-clock mr-1"></i>{{notif.time}}</small>
                            </div>
                        </div>
                    </a>
                    <a v-else>
                        <div class="details-card" :class=" notif.seen == true || notif.seen == 'True' ? 'read' : '' ">
                            <div class="d-card-body">
                                <p class="text-capitalize font-weight-bold text-base2">{{notif.atitle}} </p>
                                <small class="text-muted">{{notif.msg}}</small>
                                <small class="text-muted"><i class="far fa-clock mr-1"></i>{{notif.time}}</small>
                            </div>
                        </div>
                    </a>
                </template>
            </div>
            <div v-else>
                <p class="text-center text-muted py-2 mb-0">No notification</p>
            </div>
        </div>
    </div>




            <!--tutor chatbox -->

            <div class="tutor-chatbox">
            <template v-for="data in chatData">
                <div class="chat_new h-100">
                    <div id="chat-app" class="chat-app is-active" :class="data.minimize ? 'minimize-chat' : ''">
                        <div class="chat-app_toggle toggle">
                            <div class="icon send" @click="sendmessage()">
                                <i class="fas fa-paper-plane"></i>
                            </div>
                        </div>

                        <div class="chat-app_box">
                            <div class="chat-app_header">
                                <div class="close" @click="chatData={};selected.id=false"></div>
                                <span @click="showchatfile()" data-toggle="modal" data-target="#showChatFileModal"  style="cursor: pointer;"><i class="fas fa-folder-open open-files"></i></span>
                                <div class="branding" @click="data.minimize = !data.minimize">
                                    <div class="content">
                                        <p class="title truncate">{{selected.main_id}}</p>
                                    </div>
                                </div>

                            </div>

                            <div class="chat-app_content">
                                <div class="messages w-100">
                                    <template v-for="chat in data.chats">
                                        <div class="message" :id="'msg-'+chat.chat_id" :class="[chat.from == user_id ? '' : 'reply']">
                              <span @click="replyto(chat.chat_id, chat.message)"><i  class="fas cursor-pointer"
                                                                                     :class="[chat.from == user_id ? 'reply-font' : 'reply-message-font',
                                chat.from == user_id ? 'fa-reply' : 'fa-share']"></i></span>
                                            <a  class="a-hover-none cursor-pointer" v-if="chat.reply_to_id !== null" @click.prevent="scrollToMsg(chat.reply_to_id,$event)">
                                                <div class="reply-to-div">
                                                    <p class="truncate">{{chat.reply_to_msg}}</p>
                                                </div>
                                            </a>
                                            <template v-if="chat.msgtype == 1 || chat.msgtype == 'file'">
                                                <img :src="chat.message" alt="media" class="media rounded  my-1" style="cursor: pointer;" @click="openChatFileinModal(chat.chat_id)">
                                                <p class="text" v-if="chat.filename">{{chat.filename.split(/[/]+/).pop().slice(0,15)}}{{chat.filename.split(/[/]+/).pop().length > 15 ? '...' : ''}}</p>
                                                <p class="text" v-else @click="downloadchatfile(chat.chat_id)" style="cursor: pointer;">{{chat.message.split(/[/]+/).pop().slice(0,15)}}{{chat.message.split(/[/]+/).pop().length > 15 ? '...' : ''}}</p>
                                            </template>
                                            <template v-else-if="chat.msgtype == 0 || chat.msgtype == 'text'">
                                                <p class="text">{{chat.message}}</p>
                                            </template>
                                        </div>
                                        <small class="text-muted" :class="[chat.from == user_id ? 'justify-content-end' : 'justify-content-start']">{{chat.time}}</small>
                                    </template>
                                </div>
                            </div>

                            <div class="reply-to" v-if="data.reply_to">
                                <p class="text">{{data.reply_to.msg}}</p>
                                <span @click="data.reply_to=false"><i class="fas fa-times-circle cancel"></i></span>
                            </div>
                            <div class="chat-app_footer">
                                <i class="fas fa-file-upload attachment"  @click="document.getElementById('attachment').click()"></i>
                                <input type="file" name="attachment" class="d-none" id="attachment" @change="addfile" multiple>
                                <input class="chat-input" id="chatinput" type="text" @click="seenmsg()" @input="data.typing;texting();" @keyup.enter="sendmessage()" v-model="data.typing" placeholder="Type...">
                            </div>

                        </div>
                    </div>
                </div>
            </template>

        </div>




`





}








