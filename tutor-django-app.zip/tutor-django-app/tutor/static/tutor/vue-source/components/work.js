const work = {
    name: 'work',

    data() {
        return {
            workdata: [],
        }
    },
  

    created() {
        axios.get(`/tutor/api/work/`).then(({data}) => {
            this.workdata = data;
            console.log('workdata')
            console.log(this.workdata.atutor[0].time)
        }).catch((err) => {
            console.log('not find' + err)
        })


    },

    template: `

    <div id="availabledetails" class="responsive-pd-x" :class="workdata.atutor ? '' :'w-100'">
   <mobileview v-if="this.$root.windowwidth<=600" :listdata="workdata"></mobileview>
   <!--    homework session-->
   <template v-else>
      <div class="responsive-pd bg-white rounded mb-4 web-view">
         <countdown setID="assignment" :date="this.workdata.atutor[0].time"></countdown>
         <table-data listtype="asslist" :listdata="workdata.atutor"></table-data>
      </div>
      <!--live session-->
      <div class="responsive-pd bg-white rounded web-view">
        <countdown setID="session" :date="workdata.stutor.time"></countdown>
         <table-data listtype="sessionlist" :listdata="workdata.stutor"></table-data>
      </div>
   </template>
</div>

    `
}


