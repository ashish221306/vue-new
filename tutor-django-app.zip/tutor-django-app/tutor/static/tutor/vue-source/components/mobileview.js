const mobileview = {
    name: 'mobileview',
    props:['listdata'],


    methods:{

      callfunction(id,type,assid,time){
         if(this.$route.name=='dashboard'){
            this.$parent.getInfo(id,type,assid,time)
        }
            this.$router.push=''
        
       }
     

    },

    template: `

    <div class="mob-view mb-3">
   <div class="d-flex mb-2">
      <i class="fas fa-book mr-2 text-green my-auto"></i>
      <h4 class="my-auto">Homework assignment</h4>
   </div>

   <div class="card-group works">
      <template v-if="listdata">
         <div v-for="atut in this.$route.name=='dashboard'? listdata.asslist : listdata.atutor"
         @click='callfunction(atut.id,"a",atut.assignment.id,atut.assignment.deadline)' class="card-list"
            :class="atut.action == 'r' ? 'rejected': ( atut.action == 'a'? 'accepted' :'')">
            <div class="card-image">
               <img
                  :src="this.$root.staticUrl +'/media/branchicons/'+(atut.assignment.branch ? atut.assignment.branch : 'Misc')+'.svg'"
                  alt="" @error="this.$root.onerr" />
            </div>

            <div class="card-container">
               <label>{{atut.assignment.subject}}</label>
               <img :src="this.$root.staticUrl+'/tutor/images/comment.svg'" alt="" class="chat-image"
                  @click.stop="this.$root.$refs.chatvue.changeselected(atut.atr.id, 'tutor','hello')" />
               <span>ID: {{atut.assignment.id}}</span>
               
               <div class="d-flex justify-content-between w-100 subject-footer">
                  <span><i class="fas fa-calendar-alt mr-1"></i>{{
                     this.$root.momentfilter(atut.assignment.deadline,'ll')}} {{
                     this.$root.momentfilter(atut.assignment.deadline,'LTS')}}</span>
                  <span v-if="atut.pay_amount"><i class="fas fa-rupee-sign"></i> {{atut.pay_amount}}</span>
                  <span v-else>Not Decided</span>
               </div>
            </div>
         </div>
       </template>
      <p v-else class="text-center w-100">No assignment available</p>
   </div>

     

      <div class="d-flex mt-3 mt-lg-4 mb-2">
         <i class="fas fa-play-circle mr-2 text-red my-auto"></i>
         <h4 class="my-auto">Live session</h4>
      </div>

      <div class="card-group works">
         <template v-if="listdata.bsslist && this.$route.name=='dashboard'">
            <div v-for="stut in listdata.bsslist" @click='callfunction(stut.id ,"s", stut.id ,stut.start_time)' class="card-list"
               :class="stut.action == 'r'? 'rejected ': stut.action == 'a'? 'accepted' : ''">
               <div class="card-image">
                  <img :src="this.$root.staticUrl+'/media/branchicons'+ stut.branch ? stut.branch : ('Misc' ) +'.svg'" alt="Image"
                     @error="this.$root.onerr" />
               </div>
               <div class="card-container">
                  <label>{{stut.subject}}</label>
                  <img :src="this.$root.staticUrl+'/tutor/images/comment.svg'" alt="" class="chat-image"
                     @click.stop="this.$root.$refs.chatvue.changeselected(stut.str.id, 'stutor', stut.id - stut.subject)" />
                  <span>ID: {{stut.id}}</span>
                  <div class="d-flex justify-content-between w-100 subject-footer">
                     <span><i class="fas fa-calendar-alt mr-1"></i>{{
                        this.$root.momentfilter(stut.start_time,'ll')}} {{
                        this.$root.momentfilter(stut.start_time,'LTS')}}</span>
                     <span><i class="fas fa-hourglass-half mr-1"></i> {{
                        this.$root.momentfilter(stut.end_time,'LTS')}}</span>
                  </div>
               </div>
            </div>
         </template>

         
       <template v-else-if="this.$route.name=='work' && listdata.stutor ">
       
       <div v-for="s in listdata.stutor" class="card-list" @click="window.location='tutor/session' +s.id">
           <div class="card-image">
               <img :src="this.$root.staticUrl+'/media/branchicons/'+s.session.branch+'.svg' " alt="Image" onerror="this.$root.onerr">
           </div>
           <div class="card-container">
               <label>{{s.session.subject}}</label>
               <img :src="this.$root.staticUrl+'/tutor/images/comment.svg'" alt="" class="chat-image">
               <span>ID: {{s.session_id}}</span>
               <div class="d-flex justify-content-between w-100 subject-footer">
                   <span><i class="fas fa-calendar-alt mr-1"></i>{{this.$root.momentfilter(s.session.start_time,'Do MMM')}} {{this.$root.momentfilter(s.session.start_time,'HH:MM')}}</span>
                   <span><i class="fas fa-hourglass-half mr-1 "></i> {{this.$root.momentfilter(s.session.end_time,'HH:MM')}}</span>
               </div>
           </div>
       </div>
     
       </template> 

         <p v-else class="text-center w-100">No live session available</p>
      </div>
   
</div>
`
}

