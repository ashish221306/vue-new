var playNotif = function(){
    document.getElementById('notifSound')[0].play();
}
var playMsgtone = function(){
    document.getElementById('msgSound')[0].play();
}

document.onpageshow=function () {
    var pathname1 = window.location.pathname;
    if(pathname1=="/tutor/dashboard/"){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#sidebar li:first-child').classList.add("blue-text");
    }
    else if(pathname1=="/tutor/all_assignments/" || pathname1.includes('oldassg')){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#homeSubmenu > li:first-child').classList.add("blue-text");
        document.getElementById('homeSubmenu').classList.add('in');
    }
    else if(pathname1=="/tutor/all_sessions/" || pathname1.includes('oldsession')){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#homeSubmenu > li:last-child').classList.add("blue-text");
        document.getElementById('homeSubmenu').classList.add('in');
    }
    else if(pathname1=="/tutor/work/" || pathname1.includes('assignment') || pathname1.includes('aanswer') || pathname1.includes('session')){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#sidebar .components > li:nth-of-type(2)').classList.add("blue-text");
    }
    else if(pathname1=="/tutor/profile/"){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#sidebar li:nth-of-type(4)').classList.add("blue-text");
    }
    else if(pathname1=="/tutor/payment/"){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#sidebar li:nth-of-type(5)').classList.add("blue-text");
    }
    else if(pathname1=="/tutor/instructions/"){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#sidebar li:nth-of-type(6)').classList.add("blue-text");
    }
    else if(pathname1=="/tutor/smartpind/"){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#sidebar li.lileftsp').classList.add("blue-text");
    }
    else if(pathname1.includes("/exp")){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#sidebar li.lileftexp').classList.add("blue-text");
    }
    else if(pathname1=="/tutor/testnewsubjects/"){
        document.querySelector('#sidebar li').classList.remove("blue-text");
        document.querySelector('#sidebar li.lilefttest').classList.add("blue-text");
    }

    // document.querySelector("form[name='redeem']").validate({
    //     rules: {
    //         amount: {
    //             required: true,
    //             min: 500,
    //             max: tp_balance
    //         }
    //     },
    //     messages: {
    //         amount: {
    //             min: "Min amount you can redeem is &#8377; 500",
    //             max: "Max amount you can redeem should be less than your balance."
    //         }
    //     },
    //     submitHandler: function(form) {
    //         form.submit();
    //     }
    // });
};
function fq(asg, leng, n, atut){
    // console.log(location.pathname);
    if (location.pathname=='/tutor/dashboard/'){
      // console.log(assgobj[asg]);
      if (assgobj[asg]){
        url1 = '/tutor/marksessseen/a/'+atut+'/';
        $.ajax({url: url1});
        //send call to server to mark read
        assgobj[asg] = false;
      }
    }
    if(leng == 0){
        alert("No questions added yet");
    }
    else{
      var embedq = $('#embedq');
      $(embedq).after('<embed id="embedq" style="width: 100%; height: 100%; position: fixed; left: 0px; top: 0px; z-index: 1060;" src="/tutor/aquestion1/'+asg+'">');
      embedq.remove();
        document.getElementById('qslidenumber').value = n;
    }
}
function fq11(q,n){
  var embedq = $('#embedq');
  $(embedq).after('<embed id="embedq" style="width: 100%; height: 100%; position: fixed; left: 0px; top: 0px; z-index: 1060;" src="/tutor/tquestion/'+q+'">');
  embedq.remove();
  document.getElementById('qslidenumber').value = n;
}

function fref(asg, leng, n, atut){
    if (location.pathname=='/tutor/dashboard/'){
      if (assgobj[asg]){
        url1 = '/tutor/marksessseen/a/'+atut+'/';
        $.ajax({url: url1});
        //send call to server to mark read
        assgobj[asg] = false;
      }
    }
    if(leng == 0){
        alert("No reference attached");
    }
    else{
      var embedq = $('#embedq');
      $(embedq).after('<embed id="embedq" style="width: 100%; height: 100%; position: fixed; left: 0px; top: 0px; z-index: 1060;" src="/tutor/areference1/'+asg+'">');
      embedq.remove();
        document.getElementById('qslidenumber').value = n;
    }
}
function fsref(asg, leng, n){
    if (location.pathname=='/tutor/dashboard/'){
      if (sessobj[asg]){
        url1 = '/tutor/marksessseen/s/'+asg+'/';
        $.ajax({url: url1});
        //send call to server to mark read
        sessobj[asg] = false;
      }
    }
    if(leng == 0){
        alert("No reference attached");
    }
    else{
      var embedq = $('#embedq');
      $(embedq).after('<embed id="embedq" style="width: 100%; height: 100%; position: fixed; left: 0px; top: 0px; z-index: 1060;" src="/tutor/sreference1/'+asg+'">');
      embedq.remove();
        document.getElementById('qslidenumber').value = n;
        //document.getElementById('refmatcheck').value = true;
    }
}
function fans(leng, n, asg){
    if(leng == 0){
        alert("No answers added yet");
    }
    else{
      var embedq = document.getElementById('embedq');
      var el=document.createElement('embed')
      embedq.after('<embed id="embedq"  src="/tutor/aanswers1/'+asg+'">');
     el.setAttribute('id','embedq')
     el.setAttribute('style',"width: 100%; height: 100%; position: fixed; left: 0px; top: 0px; z-index: 1060;")
     el.setAttribute('src',`/tutor/aanswers1/${asg}`)
      embedq.remove();
        document.getElementById('qslidenumber').value = n;
    }
}



// var readmsg = function(id,checka){
//   if(checka){
//     $.ajax({
//       type: 'GET',
//       url: '/tutor/seetutmsg/'+id,
//     });
//   }
//   else{
//     $.ajax({
//       type: 'GET',
//       url: '/tutor/seestutmsg/'+id,
//     });
//   }
// };

// var tcheckmsg_call = function() {
//   $.ajax({
//     type: 'GET',
//     url: tutcheckmsgurl,
//     success: function(data) {
//       // console.log(data)
//       $('#tutorchatdropdownbox ul').empty();
//       if (data.length){
//         $.each(data, function(index, item) {
//           if (item.atutor) {
//             if (item.forassg) {
//               var withh = "tutor"
//               var link = 'href="/tutor/assignment/'+ item.atutor +'?chat"'
//             } else {
//               var withh = "stutor"
//               var link = 'href="/tutor/session/'+ item.atutor +'?chat"'
//             }
//           } else {
//             if (item.forassg) {
//               var withh = "tutor"
//               var link = 'onclick="chat_open('+item.atr_id+','+"'tutor'"+')"'
//             } else {
//               var withh = "stutor"
//               var link = 'onclick="chat_open('+item.atr_id+','+"'stutor'"+')"'
//             }
//           }
//           if (item.seen){
//             $('#tutorchatdropdownbox ul').append('<li data-ass="chat-notif-a-'+item.atr_id+'" data-with="'+withh+'"><a '+link+' style="cursor: pointer"><b>'+  item.subject +'</b>'+ item.msg +'<span class="pull-right">'+item.updated+'</span></a></li>');
//           } else {
//             $('#tutorchatdropdownbox ul').append('<li data-ass="chat-notif-a-'+item.atr_id+'" data-with="'+withh+'"><a '+link+' class="unreadnotif" style="cursor: pointer"><b>'+ item.subject +'</b>'+ item.msg +'<span class="pull-right">'+item.updated+'</span></a></li>');
//           }
//         });

/*var tcheckmsg_call = function() {
    var unreadMsg=0;
  $.ajax({
    type: 'GET',
    url: tutcheckmsgurl,
    success: function(data) {
      // console.log(data)
      $('#chats').empty();
      if (data.length){
          $("#chat-btn").removeClass('notify-hide');
        $.each(data, function(index, item) {
          if (item.atutor) {
              // old code
           /!* if (item.forassg) {
              var withh = "tutor"
              var link = 'href="/tutor/assignment/'+ item.atutor +'?chat"'
            } else {
              var withh = "stutor"
              var link = 'href="/tutor/session/'+ item.atutor +'?chat"'
            }*!/
              if (item.forassg) {
                  var withh = "tutor"
                  var link = 'onclick="chat_open('+item.atr_id+','+"'tutor'"+')"'
              } else {
                  var withh = "stutor"
                  var link = 'onclick="chat_open('+item.atr_id+','+"'stutor'"+')"'
              }
          } else {
            if (item.forassg) {
              var withh = "tutor"
              var link = 'onclick="chat_open('+item.atr_id+','+"'tutor'"+')"'
            } else {
              var withh = "stutor"
              var link = 'onclick="chat_open('+item.atr_id+','+"'stutor'"+')"'
            }
          }
          if (item.seen){
            $('#chats').append('<a '+ link +' data-with='+withh+'><div class="details-card read" data-ass="chat-notif-a-'+item.atr_id+'" data-with="'+withh+'">' +
                ' <div class="d-card-body">' + '<p class="text-capitalize font-weight-bold text-base2">'+ item.subject+'</p>' + '<small class="m-0 p-0 text-xs">'+ item.msg +'</small>' + '<small class="text-muted"> <i class="fas fa-hourglass-start"></i> '+ item.updated +'</small>' + '</div></div></a>');
          }else{
              unreadMsg++;
              $('#chats').append('<a '+ link +' data-with='+withh+' style="cursor: pointer"><div class="details-card" data-ass="chat-notif-a-'+item.atr_id+'" data-with="'+withh+'">' +
                  ' <div class="d-card-body">' + '<p class="text-capitalize font-weight-bold text-base2">'+ item.subject+'</p>' + '<small class="m-0 p-0 text-xs">'+ item.msg +'</small>' + '<small class="text-muted"> <i class="fas fa-hourglass-start"></i> '+ item.updated +'</small>' + '</div></div></a>');
          }
        });

        unreads = unreadMsg;
        if (unreads) {
           $("#chat-btn").attr('data-unread',unreads);
        } else {
            $("#chat-btn").attr('data-unread',0);
            $("#chat-btn").addClass('notify-hide');
        }
      } else {
        $('#chats').empty();
          $("#chat-btn").addClass('notify-hide');
          // playMsgtone();

        $('#chats').append(' <p class="p-2 text-center text-muted">No new chats</p>');
      }
    }
  });
};*/

// notification function
/*var checknotif_call = function() {
  $.ajax({
      type: 'GET',
      url: tutorchecknoturl,
      success: function(data) {
        $('#notification , .side-notificaction-container').empty();
        $('side-notificaction-container').empty();
        if (data.length){
          var x = 0;
          $.each(data, function(index, item) {

            if(item.ntype == 'newWorkAvailable' || item.ntype == "removed"){
              url1 = '/tutor/dashboard/';
            }
            else if(item.ntype == "workAssigned" || item.ntype == "workCancelled" || item.ntype == "tEdit"){
              if(item.wt == "a")
                url1="/tutor/assignment/"+item.wid;
              else
                url1="/tutor/session/"+item.wid;
            }
            else if(item.ntype == "rating" || item.ntype == "studentFeedback"){
              if(item.wt == "a")
                url1="/tutor/all_assignments/";
              else
                url1="/tutor/all_sessions/";
            }
            else if(item.ntype == "amountPaid"){
              url1 = '/tutor/payment/';
            }
            else if(item.ntype == "expS"){
              url1 = '/tutor/assignment/'+item.wid;
            }
            else if(item.ntype == "expertassigned"){
              url1 = '/tutor/assignment/'+item.wid;
            }
            else{
              url1 = "/tutor/";
            }
            if (item.seen){
              $('#notification , .side-notificaction-container').append('<a href="'+ url1 + '">' +
                  '<div class="details-card read">\n' +
                  '<div class="d-card-body"><p class="text-capitalize font-weight-bold text-base2">'+ item.atitle +'</p>'+
                  '<small class="text-muted"> '+ item.msg +'</small>' + '<small class="text-muted"><i class="far fa-clock"></i> '+item.time+'</small></div></div></a>');
            }
            else{
              $('#notification ,.side-notificaction-container').append('<a href="'+ url1 + '">' +
                  '<div class="details-card ">\n' +
                  '<div class="d-card-body"><p class="text-capitalize font-weight-bold text-base2">'+ item.atitle +'</p>'+
                  '<small class="text-muted"> '+ item.msg +'</small>' + '<small class="text-muted"><i class="far fa-clock"></i> '+item.time+'</small></div></div></a>');
              x+=1;
            }
          });
          if (x){
              $("#notify-btn").attr('data-unread',x);
              $("#notify-btn").removeClass('notify-hide');
          }
          else{
              // $('#notification').empty();
              $("#notify-btn").addClass('notify-hide');
              $("#notify-btn").attr('data-unread',0);
              // $('#notification').append(' <p class="p-2 text-center text-muted">No new notification</p>');
          }
        }
        else{
          $('#notification').empty();
            $("#notify-btn").addClass('notify-hide');
          $('#notification').append(' <p class="p-2 text-center text-muted">No new notification</p>');
        }
      }
    });

};*/


// $("#modal-progress").on('hidden.bs.modal', function () {
//       window.location.reload();
// });

// $(document).ready(function (){
//     var chknotifinterval = 10000; // 10 secs
//    /* checknotif_call();
//     tcheckmsg_call();
//     // call when notify-btn click
//     $('#notify-btn').click(function () {

//     });*/

// })

