$(function () {
    $('#msg-container').animate({ scrollTop: $('#msg-list').height() }, 1000);
});

var seencheck = true;

function seemsg(atr, withh) {
    // console.log(seencheck)
    if (seencheck) {
        seencheck = false;
        if (chatSocket.readyState == 0) {
            setTimeout(() => {
            chatSocket.send(JSON.stringify({
                'type': 'seen',
                'ass': atr.toString(),
                'with': withh,
                'from': withh,
            }));
             }, 3000);
        } else {
            chatSocket.send(JSON.stringify({
                'type': 'seen',
                'ass': atr.toString(),
                'with': withh,
                'from': withh,
            }));
        }
    }
}

var url = window.location.href;
var res = url.split("/");

var usid = user_id;

// console.log(usid)

var chatSocket = new ReconnectingWebSocket(
    protocoll + hostt +
    '/ws/tutor/' + usid + '/');


chatSocket.onopen = function () {
    $('#chatLoader').hide();
    // seemsg();
    // playMsgtone();
    // playNotif()
    console.log('connected')
};

function notif_add(item) {

    // chat notification
    if (item.ntype == 'chat_notif') {

        let seenClass = 'unreadnotif';

        if (item.seen == 'True' || item.seen == true) {
            seenClass = 'read';
        }
        if (item.atutor) {
            if (item.with == 'tutor') {
                var link = 'onclick="chat_open('+item.atr_id+','+"'tutor'"+')"'
            } else if (item.with == 'stutor') {
                var link = 'onclick="chat_open('+item.atr_id+','+"'stutor'"+')"'
            }
        } else {
          if (item.with == 'tutor') {
            var link = 'onclick="chat_open('+item.atr_id+','+"'tutor'"+')"'
          } else if (item.with == 'stutor') {
            var link = 'onclick="chat_open('+item.atr_id+','+"'stutor'"+')"'
          }
        }

        $('#chat-badge-' + item.atr_id + '[data-with="'+item.with+'"]').html(1)


        $('[data-ass="chat-notif-a-' + item.atr_id + '"][data-with="'+item.with+'"]').remove()


        if (item.with == 'tutor') {
            $('#chats').prepend('<a href='+ link  + '>' +
                '<div class="details-card '+ seenClass +' ">\n' +
                '<div class="d-card-body"><p class="text-capitalize font-weight-bold text-base2">'+ item.assg_title +'</p>'+
                '<small class="text-muted"> '+ item.msg +'</small>' + '<small class="text-muted"><i class="far fa-clock"></i> '+item.time+'</small></div></div></a>');

            unreads = parseInt($("#chat-btn").attr('data-unread')) +1;
            console.log('unread tutor socket js calls ' ,unreads);
            if (unreads) {
                $("#chat-btn").attr('data-unread',);
                $("#chat-btn").removeClass('notify-hide');
            } else {
                $('#tutorchatdropdownbox button span').empty();
            }

        } else {
            $('#chats').prepend('<a href='+ link  + '>' +
                '<div class="details-card read">\n' +
                '<div class="d-card-body"><p class="text-capitalize font-weight-bold text-base2">'+ item.assg_title +'</p>'+
                '<small class="text-muted"> '+ item.msg +'</small>' + '<small class="text-muted"><i class="far fa-clock"></i> '+item.time+'</small></div></div></a>');

            unreads = parseInt($("#chat-btn").attr('data-unread')) +1;
            console.log('unread else one socket js calls ',unreads);
            if (unreads) {
                $("#chat-btn").attr('data-unread',unreads);
                $("#chat-btn").removeClass('notify-hide');
            } else {
                $("#chat-btn").addClass('notify-hide');
            }
        }

    } else {

        if (item.ntype == 'newWorkAvailable' || item.ntype == "removed") {
            url1 = '/tutor/dashboard/';
        }
        else if (item.ntype == "workAssigned" || item.ntype == "workCancelled" || item.ntype == "tEdit") {
            if (item.wt == "a")
                url1 = "/tutor/assignment/" + item.wid;
            else
                url1 = "/tutor/session/" + item.wid;
        }
        else if (item.ntype == "rating" || item.ntype == "studentFeedback") {
            if (item.wt == "a")
                url1 = "/tutor/all_assignments/";
            else
                url1 = "/tutor/all_sessions/";
        }
        else if (item.ntype == "amountPaid") {
            url1 = '/tutor/payment/';
        }
        else {
            url1 = "/tutor/";
        }

        let seenClass = 'unreadnotif';

        if (item.seen == 'True' || item.seen == true) {
            seenClass = 'read';
        }

        $('#notification,.side-notificaction-container').prepend('<a href="'+ url1 + '">' +
            '<div class="details-card '+ seenClass+'">\n' +
            '<div class="d-card-body"><p class="text-capitalize font-weight-bold text-base2">'+ item.atitle +'</p>'+
            '<small class="text-muted"> '+ item.msg +'</small>' + '<small class="text-muted"><i class="far fa-clock"></i> '+item.time+'</small></div></div></a>');

        unreads = parseInt($('#notify-btn').attr('data-unread'))+1;
        if (unreads) {
            $('#notify-btn').attr('data-unread',unreads);
            $("#notify-btn").removeClass('notify-hide');
        } else {
            $("#notify-btn").addClass('notify-hide');
        }
    }
}

/*
{type: "chat_message", ass: "758396", message: "hello", from: 83, with: "tutor", …}
ass: "758396"
from: 83
message: "hello"
time: "29 Oct, 04:37 PM"
type: "chat_message"
with: "tutor"
 */
chatSocket.reconnectDecay = 2;

chatSocket.onmessage = function (e) {
    var data = JSON.parse(e.data);
    console.log(`onmessage calls `,data)
    var message = data['message'];
    var time = data['time'];
    var msglist = $('#msg-list');
    var alignclass = 'reply';
    // var divclass = ' msg-left';
    if (data['type'] == 'notif') {
        var item = data
        notif_add(item)

        if (item.ntype != 'chat_notif') {
            if ((item.wid).toString() != (res[5]).toString()) {
                playNotif();
                // console.log('1')
            }
        } else {
            if (!$('input[data-ass="' + item.atr_id + '"][data-with="'+item.with+'"]').length) {
                playMsgtone();
            }
        }

    } else {
        if (data['type'] == 'chat_message') {

                if (usid == data['from']) {
                    alignclass = '';

                    var itemtoadd = '<div class="message '+ alignclass +' ">' +
                        '<p class="text">'+ message +'</p>' +
                        '  <small>'+ time+ '</small>'+ '</div>';
                }
                else {
                    seencheck = true;
                    var itemtoadd = '<div class="message '+ alignclass +' ">' +
                        '<p class="text">'+ message +'</p>' +
                        '  <small>'+ time+ '</small>'+ '</div>';
                }
                $('.messages').append(itemtoadd);
            $(".chat-app_content").animate({ scrollTop: $('.chat-app_content').prop("scrollHeight")}, 10);

        } else if (data['type'] == 'seen') {
            if (document.querySelector('#chat-badge-'+data['ass']+'[data-with="'+data['with']+'"]')) {
                document.querySelector('#chat-badge-'+data['ass']+'[data-with="'+data['with']+'"]').innerText = ''
            }


        }
    }
};

// console.log(seencheck)
chatSocket.onclose = function (e) {
    console.error('Chat socket closed unexpectedly');
};

function activateClickListnerChat() {
    $('.chat-input').focus(function (e) {
        var text = $(this).val();
        var atr = $(".send").attr('data-ass');
        var withh = $(".send").attr('data-with');
        console.log(`atr id ${atr} and with ${withh} message ${text}`);
        seemsg(atr, withh);
        chatSocket.send(JSON.stringify({
            'type': 'texting',
            'ass': atr,
            'message': text,
            'with': withh,
        }));
    });

    var chatmsginput = document.querySelector('.chat-input');
    if (chatmsginput) {
        document.querySelector('.chat-input').onkeyup = function (e) {
            var atr = $(".send").attr('data-ass')
            if (e.keyCode === 13) {  // enter, return
                document.querySelector('.send').click();
            }
            // seemsg(atr);
        };
       /* document.querySelector('.chat-input').onclick = function (e) {
            var atr = $(".send").attr('data-ass')
            var withh = $(".send").attr('data-with')
            seemsg(atr, withh);
            // console.log(seencheck, 'click')
        }*/
        $('.chat-input').click(function () {
            var atr = $(".send").attr('data-ass')
            var withh = $(".send").attr('data-with')
            seemsg(atr, withh);
        });
    }




    var chatmsgsubmit = $(".send");
    if (chatmsgsubmit) {
        document.querySelector('.send').onclick = function (e) {
            var messageInputDom = document.querySelector('.chat-input');
            var message = messageInputDom.value;
            var atr = $(".send").attr('data-ass')
            var withh =$(".send").attr('data-with')
            console.log("attr value ",atr, "with " ,withh);
            if (message != '') {
                chatSocket.send(JSON.stringify({
                    'type': 'msg',
                    'ass': atr,
                    'with': withh,
                    'message': message,
                }));
                messageInputDom.value = '';
            }
            seemsg(atr, withh);
        };
    }

}
