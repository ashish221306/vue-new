// menu stickey
new WOW().init();


// menu stickey
$(window).load(function(){
  $("#header").sticky({ topSpacing: 0 });
});


// menu toggle
$("#togglebutton").click(function(){
    $("#navbar").toggle();
});


//owl carousel
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    lazyLoad:true,
    autoplay:true,
    autoplayHoverPause:true,
    autoplayTimeout:5000,
    nav:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:3
        }
    }
})



//owl carousel
$(document).ready(function($) {
    var Body = $('body');
    Body.addClass('preloader-site');
});
$(window).ready(function() {
    $('.preloader-wrapper').fadeOut();
    $('body').removeClass('preloader-site');
});


//smooth scrooling
$(document).ready( function() {
	var scrollLink = $('.scroll');
	// Smooth scrolling
	scrollLink.click( function(e) {
		e.preventDefault();
		$('body,html').animate({
			scrollTop: $(this.hash).offset().top - 120
		}, 1000 );
	} );
	// Active link switching
	$(window).scroll( function() {
		var scrollbarLocation = $(this).scrollTop();
		scrollLink.each(function() {
			var sectionOffset = $(this.hash).offset().top - 20;
			if ( sectionOffset <= scrollbarLocation ) {
				$(this).parent().addClass('active');
				$(this).parent().siblings().removeClass('active');
			}
		})
	})
})
