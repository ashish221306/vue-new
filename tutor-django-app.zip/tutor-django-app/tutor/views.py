from __future__ import division
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib.auth import logout
from django.shortcuts import render, get_object_or_404, HttpResponse, HttpResponseRedirect
from django.core import serializers
from django.http import JsonResponse
from django.contrib.auth.decorators import user_passes_test, login_required
from .forms import UserForm, ProfileForm, SubjectsForm, AAForm, PaymentForm, RedeemMoneyForm, ProfileForm1
#from testtutor.forms import QTestForm
from portal.models import Assignment, Session, AChat, QA, AA, Branch, Subject, STChat, ATutor, STutor, RA, RS, ATChat, Xsubject, Xbranch, OverAllNotification, ExpertTutorReview, ATask, ATutorResponse, STutorResponse, ATutorChatThread, ATutorChatMessage, STutorChatThread, STutorChatMessage, ATutorChatFile, STutorChatFile
from .models import TutorProfile, TSubjects, RedeemMoney, AllTutNotif, TimeSlot
from testtutor.models import TestAssignment, QTest, TestChat, QPool
import time, requests, json
from django.views import View
from django.utils import timezone
from datetime import datetime, timedelta, time
import pytz, random, re, shutil
from django.db.models import Sum, Count, Q, F
from django.core.mail import send_mail as core_send_mail
from django.core.mail import get_connection, EmailMultiAlternatives
import threading
from django.template import loader
from django.core.files import File
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from .widgets import admin_mobile_list
import os, difflib
from student.widgets import notify_student
from portal.widgets import notify_admin
from .widgets import notify_single_tutor
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import math

# serializers

from .serializers import TutorProfileSerializer,ATaskSerializer,ATutorSerializer,TSubjectsSerializer,SessionSerializer,STutorSerializer

#Asycnchronous send mail
class EmailThread(threading.Thread):
    def __init__(self, subject, body, from_email, recipient_list, fail_silently, html):
        self.subject = subject
        self.body = body
        self.recipient_list = recipient_list
        self.from_email = from_email
        self.fail_silently = fail_silently
        self.html = html
        #For helpacads side
        threading.Thread.__init__(self)

    def run (self):
        msg = EmailMultiAlternatives(self.subject, self.body, self.from_email, self.recipient_list, self.fail_silently)
        if self.html:
            msg.attach_alternative(self.html, "text/html")
        #for helpacads side
        msg.send()

def send_mail(subject, body, from_email, recipient_list, fail_silently, html, *args, **kwargs):
    EmailThread(subject, body, from_email, recipient_list, fail_silently, html).start()

class QuesChangeView(View):
    def get(self, request, assignment_id):
        photos_list_o = QA.objects.filter(assignment=assignment_id)
        photos_list_p = list(photos_list_o.values('question'))
        old_listQ = request.session['old_listQ']
        photos_list = [item for item in photos_list_p if item not in old_listQ]

        del request.session['old_listQ']
        old_listQ = photos_list_p
        request.session['old_listQ'] = old_listQ
        return JsonResponse(photos_list, safe=False)


class RefChangeView(View):
    def get(self, request, assignment_id):
        photos_list_o = RA.objects.filter(assignment=assignment_id)
        photos_list_p = list(photos_list_o.values('reference'))
        old_listR = request.session['old_listR']
        photos_list = [item for item in photos_list_p if item not in old_listR]

        del request.session['old_listR']
        old_listR = photos_list_p
        request.session['old_listR'] = old_listR
        return JsonResponse(photos_list, safe=False)


class TChangeView(View):
    def get(self, request, assignment_id):
        atut = get_object_or_404(ATutor, assignment=assignment_id, tutor__user=request.user)
        photos_list_o = AA.objects.filter(tutor_assignment=atut, active_status=1)
        photos_list_p = list(photos_list_o.values('answer'))
        old_list = request.session['old_list']
        photos_list = [item for item in photos_list_p if item not in old_list]
        if len(photos_list) != 0:
            up_file = photos_list[0]['answer']
            if 'up_file' in request.session:
                del request.session['up_file']
            request.session['up_file'] = up_file

        del request.session['old_list']
        old_list = photos_list_p
        request.session['old_list'] = old_list
        return JsonResponse(photos_list, safe=False)

class TProgressBarUploadView(View):
    def get(self, request, assignment_id):
        atut = get_object_or_404(ATutor, assignment=assignment_id, tutor__user=request.user)
        photos_list = AA.objects.filter(tutor_assignment=atut, active_status=1)

        return render(self.request, 'student/aanswers.html', {'photos': photos_list})

    def post(self, request, assignment_id):
        # form = AAForm(self.request.POST, self.request.FILES)
        tutor_assignment = get_object_or_404(ATutor, assignment=assignment_id, tutor__user=request.user)
        # photos_list = AA.objects.filter(tutor_assignment=tutor_assignment, active_status=1)
        status = 1
        # if assignment.status in ['forward','closed','open','final','askpay','notfinal']:
        #     status = 3
        data = {'is_valid': False}
        answers = request.FILES.getlist('answer')
        assignment = tutor_assignment.assignment
        data = {'is_valid': False}
        if not assignment.status in ['tutorreview','complete','red','orange']:
            if len(answers):
                answers_list = []
                for a in answers:
                    aa = AA(answer=a,tutor_assignment=tutor_assignment,active_status=status)
                    aa.save()
                    answers_list.append({'id':aa.id,'name':aa.filename()})
                tutor_assignment.submitted = False
                tutor_assignment.save()


                ntitle=str(request.user.tutorprofile.name)+" uploaded solutions for "+assignment.subject+" assignment - "+str(assignment.id)
                nmsg="Deadline: "+assignment.deadline.astimezone(timezone.get_current_timezone()).strftime("%d %b, %I:%M %p")
                OverAllNotification.objects.filter(n_type="solutionsUploaded", work_type='a', work_id=assignment.id, to_id=request.user.tutorprofile.id).delete()
                notify_admin('solutionsUploaded', 'a', assignment, request.user.tutorprofile.id, nmsg)

                    # tutor_assignment.alen+=1
                # tutor_assignment.save()
                # if form.is_valid() and tutor_assignment.assignment.status not in ['complete','tutorreview']:
                #     q = form.save(commit=False)
                #     q.tutor_assignment = tutor_assignment
                #     q.save()

                    #NotifyAdmin
                # ntitle=str(request.user.tutorprofile.name)+" uploaded solutions for "+tutor_assignment.assignment.subject+" assignment - "+str(tutor_assignment.assignment.id)
                # nmsg="Deadline: "+tutor_assignment.assignment.deadline.astimezone(timezone.get_current_timezone()).strftime("%d %b, %I:%M %p")
        #             OverAllNotification.objects.filter(n_type="solutionsUploaded", work_type='a', work_id=tutor_assignment.assignment.id, to_id=request.user.tutorprofile.id).delete()
        #             notify_admin('solutionsUploaded', 'a', tutor_assignment.assignment, tutor_assignment.tutor.id, nmsg)
                    # OverAllNotification.objects.create(n_type="solutionsUploaded", work_type='a', work_id=tutor_assignment.assignment.id, notification_to='a', to_id=request.user.tutorprofile.id, title=ntitle, notif_message=nmsg)


                    #Notify Expert Tutors
        #             exptuts = ATutor.objects.filter(assignment=tutor_assignment.assignment, expert_review=True)
        #
        #             for t in exptuts:
        #                 notify_single_tutor('expS', 'a', t, t.tutor.id, 'Solutions Updated by the Tutor')

                    # asg = Assignment.objects.get(id = assignment_id)
                    # answersfromall = True
                    # for at in asg.atutor_set.all():
                    #     if not at.aa_set.all():
                    #         answersfromall = False
                    # if answersfromall:
                    #     if asg.status != 'forward':
                    #         asg.status='forward'
                    #         asg.save()

                data = {'is_valid': True, 'uploaded':answers_list}
        return JsonResponse(data)


def index(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/dashboard/')
    return render(request, 'tutor/index.html')

# dummy files render for testing purpose
def testotp(request):
    return render(request, 'tutor/verifyotp_new.html')
def testpan(request):
    return render(request, 'tutor/verifypan_new.html')
def testterms(request):
    return render(request, 'tutor/terms_new.html')
def testaddprofile(request):
    return render(request, 'tutor/addprofile_new.html')


def register(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/dashboard/')
    else:
        refcode = request.GET.get('referral','')
        referral_code=False
        if refcode and refcode != 'None':
            request.session['referralcode'] = refcode
            referral_code = refcode
        if request.method=='POST':
            request.POST = request.POST.copy()
            usrnm = request.POST['username']
            umail = request.POST['email']
            phone = request.POST['phone']
            if umail:
                if User.objects.filter(email=umail).exists():
                    return render(request, 'tutor/register.html', {'error_message': 'Email already registered'})
            if phone:
                if TutorProfile.objects.filter(phone=phone).exists():
                    return render(request,'tutor/register.html',{'error_message':'Phone number registered'})
            # if usrnm:
            #     request.POST['username'] = usrnm.lower()
        form = UserForm(request.POST or None)
        if form.is_valid():
            if not refcode and 'referralcode' in request.session:
                referral_code=request.session['referralcode']
            user = form.save(commit=False)
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user.set_password(password)
            user.save()
            tutorprofile = TutorProfile.objects.create(user=user)
            tutorprofile.phone = request.POST['phone']
            tutorprofile.whatsapp = request.POST['whatsapp']
            tutorprofile.agreed = True
            tutorprofile.save()
            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    if referral_code:
                        request.session['referralcode']=referral_code
                    #Send Mail
                    if settings.ENV_TYPE == 'prod':
                        mailcontext = {
                            'username': user.username,
                        }
                        body = loader.render_to_string('testtutor/welcomemail.txt', mailcontext).strip()
                        htmlmsg = loader.render_to_string('testtutor/welcomemail.html', mailcontext)
                        send_mail('Welcome to TutorBin', body, 'Team TutorBin<admin@tutorbin.com>',[user.email],fail_silently=False, html=htmlmsg)
                    return HttpResponseRedirect('/tutor/sendotp/')
            else:
                return render(request, 'tutor/register.html', {'error_message': 'Choose different username'})
        context = {
            "form": form, 'registration_closed': False
        }
        return render(request, 'tutor/register.html', context)


def addprofile(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        # if not hasattr(request.user,'tutorprofile'):
        #     tutorprofile = get_object_or_404(TutorProfile, user=request.user)
        #     refcode = str(request.user.username)
        #     chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        #     for i in range(6):
        #         refcode+=random.choice(chars)
        #     tutorprofile.referral_code = refcode
        #     tutorprofile.save()
        tutorprofile = request.user.tutorprofile
        if not hasattr(tutorprofile, 'refcode'):
            refcode = str(request.user.username)
            chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
            for i in range(6):
                refcode+=random.choice(chars)
            tutorprofile.referral_code = refcode
            tutorprofile.save()
        if 'referralcode' in request.session:
            referral = request.session['referralcode']
            if referral!='' and referral!='None':
                referrer = TutorProfile.objects.get(referral_code=referral)
                tutorprofile.referred_by = referrer
                tutorprofile.save()
            del request.session['referralcode']
        profile_form = ProfileForm(request.POST or None, instance=request.user.tutorprofile)
        if profile_form.is_valid():
            editprofile = profile_form.save(commit=False)
            editprofile.user = request.user
            editprofile.save(update_fields=['name', 'university', 'department', 'specialisation', 'highest_degree'])


            tp = TutorProfile.objects.get(user=request.user)
            if request.FILES.get('degreepic',False):
                tp.degreepic = request.FILES.get('degreepic')
            else:
                context = {
                    "profile_form": profile_form, 'error_message':'You can not leave the document field empty. Please upload a document'
                }
                return render(request, 'tutor/addprofile.html', context)
            tp.save()

            # whatsappno = request.POST.get('whatsapp')
            # phoneno = request.POST.get('phone')
            # if not whatsappno:
            #     TutorProfile.objects.filter(user=request.user).update(whatsapp=phoneno)
#             slotlist=[]
#             startslottime = int(request.POST.get('startslottime','1'))
#             startslotam = request.POST.get('startslotam',"AM")
#             endslottime = int(request.POST.get('endslottime','2'))
#             endslotam = request.POST.get('endslotam',"AM")
#             if startslottime==12:
#                 if startslotam=="AM":
#                     startslottime=0
#             elif startslotam=="PM":
#                 startslottime = 12+int(startslottime)
#             if endslottime==12:
#                 if endslotam=="AM":
#                     endslottime=0
#             elif endslotam=="PM":
#                 endslottime = 12+int(endslottime)
#
#             if endslottime < startslottime:
#                 for x in range(startslottime,24):
#                     slotlist.append(x)
#                 for x in range(0,endslottime):
#                     slotlist.append(x)
#             else:
#                 for x in range(startslottime,endslottime):
#                     slotlist.append(x)
#             for s in slotlist:
#                 TimeSlot.objects.filter(slot=s).first().tutors.add(request.user.tutorprofile)
            contact = { "names": [ { "givenName": tutorprofile.name + ' (' + str(tutorprofile.id) + ')' } ], "phoneNumbers": [ { "value": '+91'+str(tutorprofile.whatsapp) } ], "emailAddresses": [ { "value": request.user.email } ] }
            if settings.ENV_TYPE == 'prod':
                auth_req = requests.post('https://www.googleapis.com/oauth2/v4/token', data = { "client_id": "682014210976-l2brcij1q3lo9go4gde5h3otp42lfn81.apps.googleusercontent.com",
                        "client_secret": "Sy5pu1xWvLKJ5jk9vlxRa29O", "refresh_token": "1//04-2Yb07rVjuVCgYIARAAGAQSNwF-L9IrrG78-6c4xYyPdrHL8RlRmqAIgfaTp_Lju0Vu_5FOgt_JTybtMj8CqKHHkVQTeb4cozo",
                        "grant_type": "refresh_token", "access_type":"offline" })
                contact_req = requests.post('https://people.googleapis.com/v1/people:createContact', data=json.dumps(contact),
                                            headers={"Authorization": "Bearer "+auth_req.json()['access_token']} )
            try:
                body = {
                    "requests": [
                        {
                        "image": {"source": {"imageUri": tp.degreepic.url}},
                        "features": [{"type": "TEXT_DETECTION"}]
                        }
                    ]
                }
                rr = requests.post('https://vision.googleapis.com/v1/images:annotate?key=AIzaSyBd6XXUYupJ7S8hvNsvCTzJt9BscHoGdB0', json=body)
                result = rr.json()
                pictext = result['responses'][0]['fullTextAnnotation']['text'].upper()
                tp = TutorProfile.objects.get(user=request.user)

                if tp.name.upper() in pictext and tp.highest_degree.upper() in pictext:
                    tp.degreeverified = True
                    tp.save()
                    return HttpResponseRedirect('/tutor/verifypan/')
            except:
                return HttpResponseRedirect('/tutor/verifypan/')

            return HttpResponseRedirect('/tutor/verifypan/')


        context = {
            "profile_form": profile_form,
        }
        return render(request, 'tutor/addprofile.html', context)


def sendotp(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        user = request.user
        ph = '+91' + str(user.tutorprofile.phone)
        url = 'http://control.msg91.com/api/sendotp.php'
        params = {
            "authkey": '143039Amkd6v0B45965c8ea',
            "message": '##OTP## is your one time verification(OTP) code to register on Tutorbin.',
            "sender": 'TUTBIN',
            "mobile": ph,
        }
        if settings.ENV_TYPE == 'prod':
            r = requests.get(url, params)
            data = r.json()
        else:
            data = {'type':'success'}
        if data["type"] == "success":
            return HttpResponseRedirect('/tutor/verifyotp/')
        else:
            return render(request, 'tutor/register.html', {'error_message': 'Something went wrong. Please contact our support'})


def verifyotp(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        # if not request.user.tutorprofile.name:
        #     return HttpResponseRedirect('/tutor/addprofile/')
        # elif request.user.tutorprofile.verified:
        #     return HttpResponseRedirect('/tutor/verifypan/')
        if request.method == 'POST':
            user = request.user
            ph = '+91' + str(user.tutorprofile.phone)
            url = 'http://control.msg91.com/api/verifyRequestOTP.php'
            params = {
                "authkey": '143039Amkd6v0B45965c8ea',
                "mobile": ph,
                "otp": int(request.POST.get("otp"))
            }
            if settings.ENV_TYPE == 'prod':
                r = requests.get(url, params)
                data = r.json()
            else:
                data = {'type':'success'}
            if data["type"] == "success":
                TutorProfile.objects.filter(user=user).update(verified=True)
                TutorProfile.objects.filter(phone=user.tutorprofile.phone).exclude(user=user).delete()
                test = TestAssignment.objects.get_or_create(tutor=request.user.tutorprofile)
                return HttpResponseRedirect('/tutor/addprofile/')
            else:
                return render(request, 'tutor/verifyotp.html', {'error_message': 'Wrong OTP. Click Next to Resend OTP.'})
        return render(request, 'tutor/verifyotp.html')


def verifypan(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        if not request.user.tutorprofile.name:
            return HttpResponseRedirect('/tutor/addprofile/')
        elif request.user.tutorprofile.panverified and request.user.tutorprofile.panpic:
            return HttpResponseRedirect('/tutor/dashboard/')
        elif request.method == 'POST':
            user = request.user
            pan = request.POST.get('pan', None)
            nameonpan = request.POST.get('nameonpan', None)

            if not TutorProfile.objects.filter(pan=pan).exclude(user__id=user.id).exists():

                if len(pan) == 10 and re.search(r'^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]$', re.sub(r'\s+', '', pan)):

                    tp = user.tutorprofile
                    tp.pan = pan
                    tp.nameonpan = nameonpan
                    if request.FILES.get('panpic',False):
                        tp.panpic = request.FILES.get('panpic')
                    else:
                        tp.save()
                        context = {
                            'error_message':'You can not leave the PAN card field empty. Please upload a PAN card'
                        }
                        return render(request, 'tutor/verifypan.html', context)
                    tp.save()
                    try:
                        body = {
                            "requests": [
                                {"image": {"source": {"imageUri": tp.panpic.url}},
                                "features": [{"type": "TEXT_DETECTION"}]
                                }
                            ]
                        }
                        rr = requests.post('https://vision.googleapis.com/v1/images:annotate?key=AIzaSyBd6XXUYupJ7S8hvNsvCTzJt9BscHoGdB0', json=body)
                        result = rr.json()
                        pictext = result['responses'][0]['fullTextAnnotation']['text'].upper()
                        text_list = pictext.split()
                        matching_names = nameonpan.upper().split()
                        matching_pan = pan.upper().split()
                        info = matching_names + matching_pan

                        matches = 0
                        for i in info:
                            num = difflib.get_close_matches(i, text_list, cutoff=0.8)
                            # print(num)
                            if len(num) > 0:
                                matches += 1


                        if matches == len(info):
                            tp.panverified = True
                            tp.save()
                            return HttpResponseRedirect('/tutor/dashboard/')

                    except:
                        return HttpResponseRedirect('/tutor/dashboard/')
                else:
                    # return HttpResponseRedirect('/tutor/dashboard/')
                    return render(request, 'tutor/verifypan.html', {'error_message': 'Please enter a valid PAN number'})
            else:
                return render(request, 'tutor/verifypan.html', {'error_message': 'This PAN Card number is already in registered. Please use your PAN Card number. In case of any issue, contact support.'})

        return render(request, 'tutor/verifypan.html')



def login_user(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/dashboard/')
    elif request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                if user.is_staff and not user.is_superuser:
                    if user.groups.filter(name = 'allow login').exists():
                        group = user.groups.filter(name = 'allow login').first()
                        group.user_set.remove(user)
                    else:
                        return render(request, 'tutor/login.html', {'error_message': 'Contact a superuser to allow you login','next':next})
                login(request, user)
                return HttpResponseRedirect('/tutor/dashboard/')
            else:
                if user.tutorprofile.tested:
                    return render(request, 'tutor/login.html', {'error_message': 'Your account has been deactivated. Probably you were not taking your job seriously or you were inactive for a long time. For any query, contact us at admin@tutorbin.com'})

                else:
                    return render(request, 'tutor/login.html', {'error_message': 'Your account has been deactivated. Probably you failed our test. For any query, contact us at admin@tutorbin.com'})

        else:
            return render(request, 'tutor/login.html', {'error_message': 'Invalid login credentials'})
    return render(request, 'tutor/login.html')


def logout_user(request):
    logout(request)
    form = UserForm(request.POST or None)
    context = {
        "form": form,
    }
    return HttpResponseRedirect('/tutor/login_user/')


@login_required
def dashboard(request):
    if not hasattr(request.user, 'tutorprofile'):
        if hasattr(request.user,'clientprofile'):
            return HttpResponseRedirect('/dashboard/')
        else:
            return HttpResponseRedirect('/tutor/addprofile/')
    elif request.user.tutorprofile.verified == False:
        return HttpResponseRedirect('/tutor/verifyotp/')
    elif not request.user.tutorprofile.agreed:
        return HttpResponseRedirect('/tutor/tutoragreement/')
    elif not request.user.tutorprofile.panpic:
        return HttpResponseRedirect('/tutor/verifypan/')
    elif request.user.tutorprofile.tested == False:
        if not hasattr(request.user.tutorprofile,'testassignment'):
            TestAssignment.objects.create(tutor=request.user.tutorprofile)
        if request.user.tutorprofile.testassignment.status=='ongoing':
            return HttpResponseRedirect('/tutor/test/')
        return HttpResponseRedirect('/tutor/welcome/')
    else:
        tutor = request.user.tutorprofile

        if tutor.inactive:
            tutor.inactive = False
            tutor.save()

        if not hasattr(tutor,'testassignment'):
            TestAssignment.objects.create(tutor=tutor)
        tsubjects = TSubjects.objects.filter(userprofile=tutor, selected=True, tested=True)
        assignments1 = ATask.objects.filter(is_open=True,shown_to=tutor).order_by('tutor_responses__status','assignment__deadline')
        assignments = []
        for i in assignments1:
            atr = i.tutor_responses.get(tutor=tutor)
            i.atr = atr
            tutor_response = i.tutor_responses.get(tutor=tutor).status
            if tutor_response == 3:
                i.action = 'r'
            elif tutor_response == 4:
                i.action = 'a'
            i.qa = i.assignment.qa_set.filter(active_status=1)
            i.ra = i.assignment.ra_set.filter(active_status=1)
            if tutor_response != 6:
                assignments.append(i)


        minassg = ATutor.objects.filter(assignment__status__in=['open','closed'],tutor=tutor,assignment__deadline__gte=datetime.utcnow().replace(tzinfo=pytz.UTC)).order_by('assignment__deadline').first()
        minsess = STutor.objects.filter(session__status__in=['open','closed'],tutor=tutor,session__start_time__gte=datetime.utcnow().replace(tzinfo=pytz.UTC)).order_by('session__start_time').first()
        mindeadline,minassgatut,minstarttime,minsessionstut=0,0,0,0
        if minassg:
            mindeadline=minassg.assignment.deadline
            minassgatut=minassg
        if minsess:
            minsessionstut = minsess
            minstarttime = minsess.session.start_time
        atut5 = ATutor.objects.filter(assignment__status__in=['complete','red'],rating__isnull=False,tutor=tutor).order_by('-assignment__deadline')[:5]

        sessions1 = Session.objects.filter(is_open=True,shown_to=tutor).order_by('stutor_responses__status','start_time')
        sessions = []
        for i in sessions1:
            str = i.stutor_responses.get(tutor=tutor)
            i.str = str
            stutor_response = i.stutor_responses.get(tutor=tutor).status
            if stutor_response == 3:
                i.action = 'r'
            elif stutor_response == 4:
                i.action = 'a'
            i.rs = i.rs_set.filter(active_status=1)
            if stutor_response != 6:
                sessions.append(i)
        # repeatedsess = list(STutor.objects.filter(session__status='open',tutor=tutor).values_list('session', flat=True))
        # stutorassgopen1 = STutor.objects.filter(session__status__in=['open','closed'],tutor=tutor).values_list('session__start_time','session__end_time')
        # slist = []
        # snewlist = []
        # bsslist = []
        #
        # for a in stutors:
        #     if a.session.included:
        #         if str(tutor.id) in a.session.included.split(','):
        #             if a.session.start_time > datetime.utcnow().replace(tzinfo=pytz.UTC):
        #                 slist.append(a)
        #     elif str(tutor.id) not in a.session.excluded.split(','):
        #         if a.session.subject == a.session.branch:
        #             if a.session.start_time > datetime.utcnow().replace(tzinfo=pytz.UTC):
        #                 checkone = TSubjects.objects.filter(userprofile=tutor, selected=True, tested=True, branch=a.session.branch).count()
        #                 if int(checkone) and a.min_rating <= tutor.rating <= a.max_rating:
        #                     slist.append(a)
        #         else:
        #             for sub in tsubjects:
        #                 if a.session.subject == sub.subject:
        #                     if a.session.start_time > datetime.utcnow().replace(tzinfo=pytz.UTC):
        #                         if (sub.rating >= a.min_rating) and (sub.rating <= a.max_rating):
        #                             slist.append(a)


        # for i in slist:
        #     if i.session.id not in repeatedsess:
        #         try:
        #             actionn = OverAllNotification.objects.filter(n_type='newWorkAvailable',work_type='s',work_id=i.session.id,to_id=tutor.id).order_by('-date_created').values_list('status', flat=True)[:1].get()
        #             if actionn == 2:
        #                 i.action = 'r'#rejected
        #             elif actionn == 3:
        #                 i.action = 'a'#accepted
        #         except:
        #             pass
        #         i.rs = i.session.rs_set.filter(active_status=1)
        #         snewlist.append(i)
        #         repeatedsess.append(i.session.id)
        #
        # for y in snewlist:
        #     checkone = 1
        #     for stime in stutorassgopen1:
        #         trange = list(stime)
        #         if trange[0] < y.session.start_time < trange[1] or trange[0] < y.session.end_time < trange[1] or y.session.start_time < trange[0] < y.session.end_time or y.session.start_time < trange[1] < y.session.end_time or y.session.start_time == trange[0] and y.session.end_time == trange[1]:
        #             checkone = 0
        #     if checkone:
        #         bsslist.append(y)

        if tutor.protutor and not ATutor.objects.filter(tutor=tutor, assignment__status__in=['notfinal','askpay','final','open','closed']).exists():
            pronotassigned = True
        else:
            pronotassigned = False
        
        tutorprofile_json = TutorProfileSerializer(tutor).data
        assignments_json = ATaskSerializer(assignments,many=True,remove_fields=['shown_to']).data
        atut5_json = ATutorSerializer(atut5,many=True).data
        sessions_json = SessionSerializer(sessions,many=True,remove_fields=['shown_to']).data


        minsessionstut_json = 0
        if minsessionstut:
            minsessionstut_json =  STutorSerializer(minsessionstut,remove_fields=['session']).data
            minsessionstut_json["subject"] = minsessionstut.session.subject if minsessionstut.session.subject else minsessionstut.session.subject_actual 
        
        minassgatut_json = 0
        if minassgatut:
            minassgatut_json = ATutorSerializer(minassgatut).data
        
        if minstarttime:
            time_format = "%b %d,%H:%M %Z,%Y-%m-%d %H:%M"
            minstarttime = minstarttime.strftime(time_format)
        if mindeadline:
            time_format = "%b %d,%H:%M %Z,%Y-%m-%d %H:%M"
            mindeadline = mindeadline.strftime(time_format)



        context = {"tutorprofile":tutorprofile_json,"asslist":assignments_json,'pronotassigned': pronotassigned,'bsslist': sessions_json,'assgdeadline':mindeadline, 'minassgatut':minassgatut_json, 'atut5':atut5_json, 'minstarttime':minstarttime, 'minsessionstut':minsessionstut_json}
        # earnings = tutor.total_earned     # totalassg = tutor.total_sessions
        json_ctx = json.dumps(context)
        ctx = {
            "data":json_ctx
        }
        return render(request, 'tutor/dashboard.html',ctx)


#TEST ROUTE
@login_required
def test_dashboard(request):
    if not hasattr(request.user, 'tutorprofile'):
        if hasattr(request.user,'clientprofile'):
            return HttpResponseRedirect('/dashboard/')
        else:
            return HttpResponseRedirect('/tutor/addprofile/')
    elif request.user.tutorprofile.verified == False:
        return HttpResponseRedirect('/tutor/verifyotp/')
    elif not request.user.tutorprofile.agreed:
        return HttpResponseRedirect('/tutor/tutoragreement/')
    elif not request.user.tutorprofile.panpic:
        return HttpResponseRedirect('/tutor/verifypan/')
    elif request.user.tutorprofile.tested == False:
        if not hasattr(request.user.tutorprofile,'testassignment'):
            TestAssignment.objects.create(tutor=request.user.tutorprofile)
        if request.user.tutorprofile.testassignment.status=='ongoing':
            return HttpResponseRedirect('/tutor/test/')
        return HttpResponseRedirect('/tutor/welcome/')
    else:
        tutor = request.user.tutorprofile

        if tutor.inactive:
            tutor.inactive = False
            tutor.save()

        if not hasattr(tutor,'testassignment'):
            TestAssignment.objects.create(tutor=tutor)
        tsubjects = TSubjects.objects.filter(userprofile=tutor, selected=True, tested=True)
        assignments1 = ATask.objects.filter(is_open=True,shown_to=tutor).order_by('tutor_responses__status','assignment__deadline')
        assignments = []
        for i in assignments1:
            atr = i.tutor_responses.get(tutor=tutor)
            i.atr = atr
            tutor_response = i.tutor_responses.get(tutor=tutor).status
            if tutor_response == 3:
                i.action = 'r'
            elif tutor_response == 4:
                i.action = 'a'
            i.qa = i.assignment.qa_set.filter(active_status=1)
            i.ra = i.assignment.ra_set.filter(active_status=1)
            if tutor_response != 6:
                assignments.append(i)


        minassg = ATutor.objects.filter(assignment__status__in=['open','closed'],tutor=tutor,assignment__deadline__gte=datetime.utcnow().replace(tzinfo=pytz.UTC)).order_by('assignment__deadline').first()
        minsess = STutor.objects.filter(session__status__in=['open','closed'],tutor=tutor,session__start_time__gte=datetime.utcnow().replace(tzinfo=pytz.UTC)).order_by('session__start_time').first()
        mindeadline,minassgatut,minstarttime,minsessionstut=0,0,0,0
        if minassg:
            mindeadline=minassg.assignment.deadline
            minassgatut=minassg
        if minsess:
            minsessionstut = minsess
            minstarttime = minsess.session.start_time
        atut5 = ATutor.objects.filter(assignment__status__in=['complete','red'],rating__isnull=False,tutor=tutor).order_by('-assignment__deadline')[:5]


        sessions1 = Session.objects.filter(is_open=True,shown_to=tutor).order_by('stutor_responses__status','start_time')
        sessions = []
        for i in sessions1:
            str = i.stutor_responses.get(tutor=tutor)
            i.str = str
            stutor_response = i.stutor_responses.get(tutor=tutor).status
            if stutor_response == 3:
                i.action = 'r'
            elif stutor_response == 4:
                i.action = 'a'
            i.rs = i.rs_set.filter(active_status=1)
            if stutor_response != 6:
                sessions.append(i)
        # repeatedsess = list(STutor.objects.filter(session__status='open',tutor=tutor).values_list('session', flat=True))
        # stutorassgopen1 = STutor.objects.filter(session__status__in=['open','closed'],tutor=tutor).values_list('session__start_time','session__end_time')
        # slist = []
        # snewlist = []
        # bsslist = []
        #
        # for a in stutors:
        #     if a.session.included:
        #         if str(tutor.id) in a.session.included.split(','):
        #             if a.session.start_time > datetime.utcnow().replace(tzinfo=pytz.UTC):
        #                 slist.append(a)
        #     elif str(tutor.id) not in a.session.excluded.split(','):
        #         if a.session.subject == a.session.branch:
        #             if a.session.start_time > datetime.utcnow().replace(tzinfo=pytz.UTC):
        #                 checkone = TSubjects.objects.filter(userprofile=tutor, selected=True, tested=True, branch=a.session.branch).count()
        #                 if int(checkone) and a.min_rating <= tutor.rating <= a.max_rating:
        #                     slist.append(a)
        #         else:
        #             for sub in tsubjects:
        #                 if a.session.subject == sub.subject:
        #                     if a.session.start_time > datetime.utcnow().replace(tzinfo=pytz.UTC):
        #                         if (sub.rating >= a.min_rating) and (sub.rating <= a.max_rating):
        #                             slist.append(a)


        # for i in slist:
        #     if i.session.id not in repeatedsess:
        #         try:
        #             actionn = OverAllNotification.objects.filter(n_type='newWorkAvailable',work_type='s',work_id=i.session.id,to_id=tutor.id).order_by('-date_created').values_list('status', flat=True)[:1].get()
        #             if actionn == 2:
        #                 i.action = 'r'#rejected
        #             elif actionn == 3:
        #                 i.action = 'a'#accepted
        #         except:
        #             pass
        #         i.rs = i.session.rs_set.filter(active_status=1)
        #         snewlist.append(i)
        #         repeatedsess.append(i.session.id)
        #
        # for y in snewlist:
        #     checkone = 1
        #     for stime in stutorassgopen1:
        #         trange = list(stime)
        #         if trange[0] < y.session.start_time < trange[1] or trange[0] < y.session.end_time < trange[1] or y.session.start_time < trange[0] < y.session.end_time or y.session.start_time < trange[1] < y.session.end_time or y.session.start_time == trange[0] and y.session.end_time == trange[1]:
        #             checkone = 0
        #     if checkone:
        #         bsslist.append(y)

        if tutor.protutor and not ATutor.objects.filter(tutor=tutor, assignment__status__in=['notfinal','askpay','final','open','closed']).exists():
            pronotassigned = True
        else:
            pronotassigned = False

        # earnings = tutor.total_earned     # totalassg = tutor.total_sessions
        tutorprofile_json = TutorProfileSerializer(tutor).data
        assignments_json = ATaskSerializer(assignments,many=True,remove_fields=['shown_to']).data
        atut5_json = ATutorSerializer(atut5,many=True).data
        #ToDo:sessions
        sessions_json = SessionSerializer(sessions,many=True,remove_fields=['shown_to']).data

        if minassgatut:
            minassgatut_json = ATutorSerializer(minassgatut).data

        if minsessionstut:
            minsessionstut_json =  STutorSerializer(minsessionstut,remove_fields=['session']).data
        
        if minstarttime:
            time_format = "%b %d,%H:%M %Z,%Y-%m-%d %H:%M"
            minstarttime_serialized = minstarttime.strftime(time_format)
        context = {"tutorprofile":tutorprofile_json,"asslist":assignments_json,'pronotassigned': pronotassigned,'bsslist': sessions_json,'assgdeadline':mindeadline, 'minassgatut':minassgatut_json, 'atut5':atut5_json, 'minstarttime':minstarttime_serialized, 'minsessionstut':minsessionstut_json}
        # context = {'tutorprofile': tutorprofile_json, 'asslist': assignments_json, 'pronotassigned': pronotassigned,'bsslist': sessions, 'assgdeadline':mindeadline, 'minassgatut':minassgatut, 'atut5':atut5, 'minstarttime':minstarttime, 'minsessionstut':minsessionstut
        #     # , "earnings":earnings['amount__sum'], 'totalassg':totalassg, 'totalsess':totalsess
        # }
        return JsonResponse(context)

@login_required
def tutoragreement(request):
    return render(request,'tutor/tutoragreement.html')

def tutor_agreement(request):
    return render(request,'tutor/tutoragreement.html',{'open':True})

@login_required
def sign_tutor_agreement(request):
    if hasattr(request.user,'tutorprofile'):
        tutor = request.user.tutorprofile
        flag = request.GET.get('agree','')
        if flag == 'true':
            tutor.agreed=True
            tutor.save()
            if tutor.tested:
                return HttpResponseRedirect('/tutor/dashboard/')
            else:
                return HttpResponseRedirect('/tutor/update_subjects/')
        elif flag == 'false':
            tutor.agreed=False
            tutor.save()
            user = request.user
            user.is_active=False
            user.save()
            logout(request)
            return HttpResponseRedirect('/tutor/')

    return render(request,'tutor/tutoragreement.html')

def welcome(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    elif request.user.tutorprofile.verified == False:
        return HttpResponseRedirect('/tutor/addprofile/')
    else:
        user = request.user
        tutorprofile = user.tutorprofile
        if not tutorprofile.tsubjects_set.count():
            return HttpResponseRedirect('/tutor/update_subjects/')
        elif tutorprofile.tested and not tutorprofile.newtest:
            return HttpResponseRedirect('/tutor/dashboard/')
        refdate = datetime.utcnow().replace(tzinfo=pytz.UTC) - timedelta(hours=12)
        test = tutorprofile.testassignment
        teststatus = test.status
        if teststatus == 'assigned':
            context={'tutorprofile':tutorprofile, 'ta': True}
        elif teststatus == 'submitted' or teststatus == 'ongoing' and test.start_time and test.start_time < refdate:
            context={'tutorprofile':tutorprofile, 'subm':True}
        elif teststatus == 'ongoing' and test.start_time >= refdate:
            return HttpResponseRedirect('/tutor/test/')
        elif teststatus=='requested':
            context={'tutorprofile':tutorprofile, 'tar':True}
        elif teststatus=='o':
            context={'tutorprofile':tutorprofile, 'tre':True}
        elif teststatus=='as':
            context={'tutorprofile':tutorprofile, 'as':True}
        elif teststatus=='on' and test.start_time >= refdate:
            return HttpResponseRedirect('/tutor/test/')
        elif teststatus=='re':
            context={'tutorprofile':tutorprofile, 're':True}
        elif teststatus=='su':
            context={'tutorprofile':tutorprofile, 'su':True}
        else:
            context={'tutorprofile': tutorprofile}
        return render(request, 'tutor/welcome.html', context)

def accepttest(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        # ta = TestAssignment.objects.filter(tutor__user=request.user, status='assigned').update(start_time=datetime.utcnow().replace(tzinfo=pytz.UTC),status='ongoing')
        test = request.user.tutorprofile.testassignment
        test.start_time=datetime.utcnow().replace(tzinfo=pytz.UTC)
        if test.status == 'assigned':
            test.status='ongoing'
            test.save()
        elif test.status == 'as':
            test.status='on'
            test.save()
        return HttpResponseRedirect('/tutor/test/')


def submittest(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        # ta = TestAssignment.objects.filter(tutor__user=request.user, status='ongoing').update(status='submitted')
        test = request.user.tutorprofile.testassignment
        if test.status == 'ongoing':
            test.status = 'submitted'
            test.save()
        elif test.status == 'on':
            test.status = 'su'
            test.save()
        return HttpResponseRedirect('/tutor/welcome/')


def requesttest(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    elif request.user.tutorprofile.verified == False:
        return HttpResponseRedirect('/tutor/addprofile/')
    else:
        if not request.user.tutorprofile.newtest:
            tutor = request.user.tutorprofile
            test = tutor.testassignment
            if test.status == 'n' or test.status == 'o':
                subjs_array = []
                subjects = set(TSubjects.objects.filter(userprofile=tutor, selected=True))

                for subj in subjects:
                    subjs_array.append(subj.subject + "-" + subj.branch)

                assignTest(tutor, subjs_array)
        else:
            tutor = request.user.tutorprofile
            test = tutor.testassignment
            if test.status == 're':
                subjs_array = []
                subjects = TSubjects.objects.filter(userprofile=tutor, selected=True, tested=False, failed=False)

                for subj in subjects:
                    subjs_array.append(subj.subject + "-" + subj.branch)

                if len(subjs_array) > 0:
                    assignTest(tutor, subjs_array)

                    tutor.newtest = True
                    tutor.save()
                    if tutor.testassignment.qtest_set.all().count() > 0:
                        tutor.testassignment.status = 'as'
                    else:
                        tutor.testassignment.status = 'su'
                    tutor.testassignment.save()

        return HttpResponseRedirect('/tutor/welcome/')


def test(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        refdate = datetime.utcnow().replace(tzinfo=pytz.UTC) - timedelta(hours=12)
        # ta = TestAssignment.objects.filter(tutor__user=request.user, status='ongoing', start_time__gte=refdate)
        #test = request.user.tutorprofile.testassignment
        test = TestAssignment.objects.filter(tutor=request.user.tutorprofile)
        if test.count() == 0:
            return HttpResponseRedirect("/tutor/")
        else:
            test = test[0]
        if (test.status == 'ongoing' or test.status == 'on') and test.start_time >= refdate:
            qs = test.qtest_set.all().order_by('question__subject', 'id')
            checkifsubm = True
            for q in qs:
                if not q.tanswer:
                    checkifsubm = False
            deadlinee = test.start_time + timedelta(hours=12)
            return render(request, 'tutor/test.html', {'ta': test, 'qs': qs, 'deadlinee': deadlinee, 'checkifsubm': checkifsubm})
        else:
            return HttpResponseRedirect('/tutor/welcome/')

def testnewsubjects(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        refdate = datetime.utcnow().replace(tzinfo=pytz.UTC) - timedelta(hours=12)
        test = request.user.tutorprofile.testassignment
        if test.status in ['re','as','su','on','te']:
            if test.status == 'on' and test.start_time>=refdate:
                qs = test.qtest_set.all().order_by('question__subject','id')
                checkifsubm = True
                for q in qs:
                    if not q.tanswer:
                        checkifsubm = False
                deadlinee = test.start_time + timedelta(hours=12)
                return render(request, 'tutor/test1.html', {'ta':test, 'qs':qs, 'deadlinee':deadlinee, 'checkifsubm':checkifsubm, 'ongoing':True})
            elif test.status in ['on','su']:
                context={'submitted':True}
            elif test.status == 're':
                context={'requested':True}
            elif test.status == 'as':
                context={'assigned':True}
            return render(request, 'tutor/test1.html', context)
        else:
            return HttpResponseRedirect('/tutor/dashboard/')

def tquestion(request, qid):
    assignment = get_object_or_404(TestAssignment, pk=qid)
    #que = QA.objects.all()
    photos_list = QTest.objects.filter(test=assignment).order_by('question__subject','id')
    qList = []
    for x in photos_list:
        if x.question.question:
            qList.append(x.question)
    #request.session['old_listQ'] = old_listQ
    return render(request, 'tutor/tquestion.html', {'assignment': assignment, 'qList': qList})


def answertest(request, qid):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        if request.method == 'POST':
            av = request.POST.get('ansvalue', None)
            ans = request.FILES.get('ans', None)
            q = QTest.objects.get(pk=qid)
            if ans:
                q.tanswer = ans
            q.tanswervalue = av
            q.save()
        # if request.user.tutorprofile.tested:
        #     return HttpResponseRedirect('/tutor/testnewsubjects/')
        return JsonResponse({'success': True})


def accept_assignment(request, atut_id):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        #assignment = get_object_or_404(Assignment, pk=assignment_id)
        t = get_object_or_404(ATutor, pk=atut_id)
        tutorp = TutorProfile.objects.get(user=request.user)
        assignment = t.assignment
        if t.tutor is None and not assignment.atutor_set.filter(tutor=tutorp) and not assignment.is_project:
            t.tutor = tutorp
            t.save()
            #Notify Admin
            ntitle= str(tutorp.name) + " accepted "+ str(assignment.subject) +" assignment - "+str(assignment.id)
            nmsg = "Deadline: " + assignment.deadline.astimezone(timezone.get_current_timezone()).strftime("%d %b, %I:%M %p")
            ovr2 = OverAllNotification.objects.filter(n_type='newWorkAvailable', work_type='a', work_id=assignment.id, to_id=tutorp.id).order_by('-date_created')
            if len(ovr2):
                ovr1 = ovr2[0]
                if ovr1.status == 0:
                    notify_admin('workAccepted', 'a', assignment, tutorp.id, str(tutorp.name)+' accepted without going through any question or material')
                    # OverAllNotification.objects.create(n_type="workAccepted", notification_to='a', work_type='a', work_id=assignment.id, to_id=tutorp.id, title='Alert! - '+str(assignment.id), notif_message=str(tutorp.name)+' accepted without going through any question or material')
                else:
                    notify_admin('workAccepted', 'a', assignment, tutorp.id, nmsg)
                    # OverAllNotification.objects.create(n_type="workAccepted", notification_to='a', work_type='a', work_id=assignment.id, to_id=tutorp.id, title=ntitle, notif_message=nmsg)
                ovr1.status = 3
                ovr1.save()
            admin=User.objects.get(id=1)
            ATChat.objects.create(atutor=t, to=request.user,user=admin, message='Are you sure you will submit all parts of the assignment by the given deadline? If yes, please reply with a positive response.')
            assignment.assigned_tutors += 1
            assignment.save()
            return HttpResponseRedirect('/tutor/assignment/'+atut_id)
        else:
            return render(request, 'tutor/errorpage1.html')

def interest_assignment(request, atut_id):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        tutor = request.user.tutorprofile
        tutor_response = ATutorResponse.objects.filter(task_id=atut_id,tutor=tutor,status__lt=4).first()
        if tutor_response:
            if tutor.protutor and not ATutor.objects.filter(tutor=tutor, assignment__status__in=['notfinal','askpay','final','open','closed']).exists():
                if tutor_response.status != 6:
                    resp = tutor_response
                    resp.status = 6
                    resp.save()
                    task = resp.task
                    assignment_id = task.assignment_id
                    t = resp.tutor
                    atut = ATutor.objects.get_or_create(assignment_id=assignment_id,tutor_id=t.id,defaults={'pay_amount':task.pay_amount,'description':task.description})[0]
                    atr = ATutorResponse.objects.get_or_create(task=task,tutor_id=t,defaults={'status':6,'notified':True})[0]
                    atr.atutor = atut
                    atr.save()
                    notify_single_tutor('workAssigned','a',atut,t.id,None)
                    if hasattr(task.assignment.user,'clientprofile') and not OverAllNotification.objects.filter(n_type="tutorAssigned",notification_to='c',work_type='a',work_id=task.assignment_id).exists():
                        notify_student('a','tutorAssigned',task.assignment,None)
                    t.last_help = datetime.utcnow().replace(tzinfo=pytz.UTC)
                    t.interest_count=0
                    t.save()
                    return HttpResponseRedirect('/tutor/work/')

            if tutor_response.status != 4:
                tutor_response.status = 4
                tutor_response.save()
                tutor = request.user.tutorprofile
                tutor.interest_count += 1
                tutor.save()
                assignment = tutor_response.task.assignment
                assignment.interestedlen += 1
                assignment.save()

        return HttpResponseRedirect('/tutor/dashboard/')


def accept_session(request, stut_id):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        tutor = request.user.tutorprofile
        # st = get_object_or_404(STutor, pk=stut_id)
        session = get_object_or_404(Session, pk=stut_id)
        response = STutorResponse.objects.get(session=session,tutor=tutor)
        # accepted = STutorResponse.objects.filter(session__status__in=['notfinal','final','askpay'],tutor=tutor,status=6)
        checkparallel = True
        if response.status != 6:
            if response.suggested:
                accepted = STutorResponse.objects.filter(session__status__in=['notfinal','final','askpay'],tutor=tutor,status=6)
                for a in accepted:
                    if a.session.start_time < session.start_time < a.session.end_time or a.session.start_time < session.end_time < a.session.end_time or session.start_time < a.session.start_time < session.end_time or session.start_time < a.session.end_time < session.end_time or session.start_time == a.session.start_time and session.end_time == a.session.end_time:
                        checkparallel = False
                if checkparallel:
                    stut = STutor.objects.get_or_create(session_id=session.id,tutor_id=tutor.id)[0]
                    response.status = 6
                    response.stutor = stut
                    response.save()
                    notify_single_tutor('workAssigned','s',stut,tutor.id,None)
                    tutor.last_help = datetime.utcnow().replace(tzinfo=pytz.UTC)
                    tutor.interest_count=0
                    tutor.save()
                    return HttpResponseRedirect('/tutor/work/')

            if response.status != 4:
                response.status = 4
                response.save()
                tutor.interest_count += 1
                tutor.save()
                return HttpResponseRedirect('/tutor/dashboard/')
        # else:
        return HttpResponseRedirect('/tutor/dashboard/')
        # if not session.stutor_set.filter(tutor=tutorp) and checkparallel:
        #     if st.tutor is None:
        #         st.tutor = tutorp
        #         st.save()
        #         #Notify Admin
        #         ntitle= str(tutorp.name) + " accepted "+ str(session.subject) +" session - "+str(session.id)
        #         nmsg = "Start time: " + session.start_time.astimezone(timezone.get_current_timezone()).strftime("%d %b, %I:%M %p")
        #         ovr1 = OverAllNotification.objects.filter(n_type='newWorkAvailable', work_type='s', work_id=session.id, to_id=tutorp.id).order_by('-date_created')[0]
        #         if ovr1.status == 0:
        #             OverAllNotification.objects.create(n_type="workAccepted", notification_to='a', work_type='s', work_id=session.id, to_id=tutorp.id, title='Alert! - '+str(session.id), notif_message=str(tutorp.name)+' accepted without going through any ref. material')
        #         else:
        #             OverAllNotification.objects.create(n_type="workAccepted", notification_to='a', work_type='s', work_id=session.id, to_id=tutorp.id, title=ntitle, notif_message=nmsg)
        #         ovr1.status = 3
        #         ovr1.save()
        #         session.assigned_tutors += 1
        #         session.save()
        #         return HttpResponseRedirect('/tutor/work/')
        #     #elif st.tutor is not None and :
        #
        #     else:
        #         st1 = session.stutor_set.filter(tutor=None)
        #         if session.subject == session.branch:
        #             for t in st1:
        #                 if t.min_rating <= tutorp.rating <= t.max_rating:
        #                     t.tutor = tutorp
        #                     t.save()
        #                     #Notify Admin
        #                     ntitle= str(tutorp.name) + " accepted "+ str(session.subject) +" session - "+str(session.id)
        #                     nmsg = "Start time: " + session.start_time.astimezone(timezone.get_current_timezone()).strftime("%d %b, %I:%M %p")
        #                     ovr1 = OverAllNotification.objects.filter(n_type='newWorkAvailable', work_type='s', work_id=session.id, to_id=tutorp.id).order_by('-date_created')[0]
        #                     if ovr1.status == 0:
        #                         OverAllNotification.objects.create(n_type="workAccepted", notification_to='a', work_type='s', work_id=session.id, to_id=tutorp.id, title='Alert! - '+str(session.id), notif_message=str(tutorp.name)+' accepted without going through any ref. material')
        #                     else:
        #                         OverAllNotification.objects.create(n_type="workAccepted", notification_to='a', work_type='s', work_id=session.id, to_id=tutorp.id, title=ntitle, notif_message=nmsg)
        #                     ovr1.status = 3
        #                     ovr1.save()
        #                     session.assigned_tutors += 1
        #                     session.save()
        #                     return HttpResponseRedirect('/tutor/work/')
        #         else:
        #             tsub = TSubjects.objects.filter(userprofile=tutorp, subject=session.subject)[0]
        #             for t in st1:
        #                 if t.min_rating <= tsub.rating <= t.max_rating:
        #                     t.tutor = tutorp
        #                     t.save()
        #                     #Notify Admin
        #                     ntitle= str(tutorp.name) + " accepted "+ str(session.subject) +" session - "+str(session.id)
        #                     nmsg = "Start time: " + session.start_time.astimezone(timezone.get_current_timezone()).strftime("%d %b, %I:%M %p")
        #                     OverAllNotification.objects.create(n_type="workAccepted", notification_to='a', work_type='s', work_id=session.id, to_id=tutorp.id, title=ntitle, notif_message=nmsg)
        #
        #                     session.assigned_tutors += 1
        #                     session.save()
        #                     return HttpResponseRedirect('/tutor/work/')

                # return render(request, 'tutor/errorpage1.html')
        # return render(request, 'tutor/errorpage1.html')


def work(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        user = request.user
        # reftime = datetime.utcnow().replace(tzinfo=pytz.UTC)-timedelta(hours=2)
        tutorprofile = user.tutorprofile
        stutor = STutor.objects.filter(tutor__user=user).exclude(session__status__in=['red','orange','complete']).order_by('session__start_time')
        atutor = ATutor.objects.filter(tutor__user=user).exclude(assignment__status__in=['red','orange','complete']).order_by('assignment__deadline')


        stutor_json = STutorSerializer(stutor,many=True).data
        atutor_json = ATutorSerializer(atutor,many=True).data
        context = {'stutor':stutor_json,'atutor':atutor_json}
        return JsonResponse(context)
        # return render(request, 'tutor/work.html', {'stutor': stutor, 'tutorprofile': tutorprofile, 'atutor': atutor})


@login_required
def history(request):
    atut1 = ATutor.objects.filter(assignment__status__in=['complete','tutorreview','red','orange'],tutor__user=request.user, speed_rating__isnull=False).order_by('-assignment__deadline','id')
    stut1 = STutor.objects.filter(session__status__in=['complete','tutorreview','red','orange'],tutor__user=request.user, speed_rating__isnull=False).order_by('-session__start_time','id')
    atut = atut1[:14]
    atut.next_page_number = 2
    stut = stut1[:14]
    stut.next_page_number = 2

    stut_json = STutorSerializer(stut,many=True).data
    atut_json = ATutorSerializer(atut,many=True).data
    context = {'stut': stut_json, 'atut': atut_json,'has_next_assignment':atut1.count() > 14, 'has_next_session':stut1.count() > 14, 'counter':0}
    return JsonResponse(context)

def all_assignments(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        page = request.GET.get("page", 1)
        atut1 = ATutor.objects.filter(assignment__status__in=['complete','tutorreview','red','orange'],tutor__user=request.user, speed_rating__isnull=False).order_by('-assignment__deadline','id')
        paginator = Paginator(atut1, 14)
        atut = paginator.page(page)
        counter = (int(page) - 1) * 14
        # print(page)
        # print(counter)
        # print(atut.has_next())
        # print(atut.next_page_number())

        # atut = []
        # for t in atut2:
        #     if t.speed_rating:
        #         try:
        #             atut.append(t)
        #         except:
        #             break

        return render(request, 'tutor/all_assignments.html', {'atut': atut, 'counter':counter})


def all_sessions(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:

        page = request.GET.get("page", 1)
        atut1 = STutor.objects.filter(session__status__in=['complete','tutorreview','red','orange'],tutor__user=request.user, speed_rating__isnull=False).order_by('-session__start_time','id')
        paginator = Paginator(atut1, 14)
        atut = paginator.page(page)
        counter = (int(page) - 1) * 14
        return render(request, 'tutor/all_sessions.html', {'stut': atut, 'counter':counter})


def assignment_detail(request, atut_id):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        user = request.user
        tutorprofile = user.tutorprofile
        atut = get_object_or_404(ATutor,pk=atut_id)
        assignment = atut.assignment
        aas = AA.objects.filter(tutor_assignment__assignment=assignment, active_status=1)
        qs = QA.objects.filter(assignment=atut.assignment, active_status=1)
        ans = AA.objects.filter(tutor_assignment=atut, active_status=1)
        ref = RA.objects.filter(assignment=atut.assignment, active_status=1)
        manager_phone = admin_mobile_list.get(atut.assignment.manager)

        # c = ATutorChatThread.objects.get_or_create(atut_id=atut_id,defaults={'user_id':atut.assignment.user_id})[0]
        # chat = c.tutorchatmessage_set.all().order_by('timestamp')
        # newchat = True
        # achatlist = atut.atchat_set.all()
        # if len(achatlist) and not len(chat):
        #     chat = achatlist
        #     newchat = False

        return render(request, 'tutor/assignment.html', {'aas': aas, 'manager_phone': manager_phone, 'user': user, 'atutor': atut, 'qs': qs, 'ref': ref, 'ans': ans})

@login_required
def explore(request,session_type, session_id):
    user = request.user
    tutorprofile = user.tutorprofile
    if session_type == 'a':
        task = get_object_or_404(ATask, pk=session_id)
        assignment = task.assignment
        ques = list(QA.objects.filter(assignment=assignment, active_status=1).values_list('id',flat=True))
        refs = list(RA.objects.filter(assignment=assignment, active_status=1).values_list('id',flat=True))

        try:
            tutor_response = task.tutor_responses.get(tutor=tutorprofile)
        except:
            return JsonResponse({'success':False})
    else:
        task = get_object_or_404(Session, pk=session_id)
        assignment = task
        assignment.deadline = assignment.start_time
        ques = []
        refs = list(RS.objects.filter(session=assignment, active_status=1).values_list('id',flat=True))
        tutor_response = task.stutor_responses.get(tutor=tutorprofile)
    if tutor_response.status<2:
        tutor_response.status = 2
        tutor_response.save()
    final_object = {
        'success':True,
        'id':session_id,
        'subject':assignment.subject,
        'deadline':assignment.deadline.astimezone(timezone.get_current_timezone()).strftime("%d %b, %I:%M %p %A"),
        'duration':assignment.duration if session_type == 's' else '',
        'questions':ques,
        'references':refs,
        'note':task.description if session_type == 'a' else '',
        'manager':assignment.manager,
        'phone':admin_mobile_list.get(assignment.manager),
        'interest_status': tutor_response.status
    }
    return JsonResponse(final_object)

@login_required
def respond_to_session(request,session_type,session_id):
    action = request.GET.get('action',False)
    tutor = request.user.tutorprofile
    if action:
        if session_type == 'a':
            task = get_object_or_404(ATask, pk=session_id)
            response = task.tutor_responses.filter(tutor=tutor)
        elif session_type == 's':
            task = get_object_or_404(Session, pk=session_id)
            response = task.stutor_responses.filter(tutor=tutor)
        if action == 'accept':
            response.filter(status__lt=4).update(status=4)
        elif action == 'reject':
            response.filter(status__lt=6).update(status=3)

        return JsonResponse({'success':True})
    return JsonResponse({'success':False})

def approve(request, atid):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        if request.method == 'POST':
            review = request.POST.get('review')
            ATutor.objects.filter(id=atid).update(expert_feedback=review)
            return HttpResponseRedirect('/tutor/assignment/'+str(atid))
        else:
            user = request.user
            correct = request.GET.get('correct')
            ATutor.objects.filter(id=atid).update(approved=correct)
            return HttpResponseRedirect('/tutor/assignment/'+str(atid))


@login_required
def tchatbox_api(request):
    atr_id = request.GET.get('atr_id')
    atr_q = get_object_or_404(ATutorResponse,pk=atr_id)
    atr = {
        'id' : atr_q.id,
        'tutor' : atr_q.tutor.id,
        'atutor' : atr_q.atutor.id if atr_q.atutor else None,
        'status' : atr_q.status,
        'open' : atr_q.task.is_open,
        'assignment' : atr_q.task.assignment.id if atr_q.task else None,
    }
    assignment = atr_q.task.assignment
    c = ATutorChatThread.objects.get_or_create(atr_id=atr_id,defaults={'user':atr_q.tutor.user})[0]
    if c.updated > datetime.utcnow().replace(tzinfo=pytz.UTC) - timedelta(days=10):
        atr['open'] = True
    chats = c.atutorchatmessage_set.all().order_by('timestamp')
    chat = []
    for x in chats:
        cdict = {
            'chat_id': x.id,
            'reply_to_id': x.reply_to.id if x.reply_to else None,
            'reply_to_msg': x.reply_to.message if x.reply_to else None,
            'message' : x.message,
            'seen' : x.seen,
            'sender' : x.sender.id,
            'from_name' : x.sender.username,
            'timestamp' : x.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
        }
        chat.append(cdict)

    achatlist = atr_q.atutor.atchat_set.all() if atr_q.atutor else []
    oldchat = False
    if len(achatlist) and not len(chat):
        oldchat = True

    data = json.dumps({'chat': chat,  'atr': atr, 'oldchat': oldchat, 'assignment': {'pk':assignment.id,'subject':assignment.subject}, 'user':request.user.id})
    return JsonResponse(data, safe=False)


@login_required
def stchatbox_api(request):
    str_id = request.GET.get('str_id')
    str_q = get_object_or_404(STutorResponse,pk=str_id)
    str = {
        'id' : str_q.id,
        'tutor' : str_q.tutor.id,
        'stutor' : str_q.stutor.id if str_q.stutor else None,
        'status' : str_q.status,
        'open' : str_q.session.is_open,
        'session' : str_q.session.id if str_q.session else None,
    }
    session = str_q.session
    c = STutorChatThread.objects.get_or_create(str_id=str_id,defaults={'user':str_q.tutor.user})[0]
    if c.updated > datetime.utcnow().replace(tzinfo=pytz.UTC) - timedelta(days=10):
        str['open'] = True
    chats = c.stutorchatmessage_set.all().order_by('timestamp')
    chat = []
    for x in chats:
        cdict = {
            'chat_id': x.id,
            'reply_to_id': x.reply_to.id if x.reply_to else None,
            'reply_to_msg': x.reply_to.message if x.reply_to else None,
            'message' : x.message,
            'seen' : x.seen,
            'sender' : x.sender.id,
            'from_name' : x.sender.username,
            'timestamp' : x.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
        }
        chat.append(cdict)

    data = json.dumps({'chat': chat,  'str': str, 'session': {'pk':session.id,'subject':session.subject}, 'user':request.user.id})
    return JsonResponse(data, safe=False)


@login_required
def aanswers(request, assignment_id):
    assignment = get_object_or_404(Assignment, pk=assignment_id)
    form = AAForm(request.POST or None, request.FILES or None)
    atut = get_object_or_404(ATutor, assignment=assignment_id, tutor__user=request.user)
    user = request.user
    tutorprofile = user.tutorprofile

    photos_list = AA.objects.filter(tutor_assignment=atut, active_status=1)
    old_list = list(photos_list.values('answer'))
    request.session['old_list'] = old_list

    if request.method == "POST":
        qcomment = request.POST.get('comment')
        if qcomment:
            if 'up_file' in request.session and request.session['up_file'] != '':
                fil = request.session['up_file']
                add_com = AA.objects.filter(answer=fil)[0]
                add_com.comment = qcomment
                add_com.save()
                del request.session['up_file']

            else:
                AA.objects.create(tutor_assignment=atut, comment=qcomment)

            ntitle=str(request.user.tutorprofile.name)+" uploaded solutions for "+assignment.subject+" assignment - "+str(assignment.id)
            nmsg="Deadline: "+assignment.deadline.astimezone(timezone.get_current_timezone()).strftime("%d %b, %I:%M %p")
            OverAllNotification.objects.filter(n_type="solutionsUploaded", work_type='a', work_id=assignment.id, to_id=request.user.tutorprofile.id).delete()
            notify_admin('solutionsUploaded', 'a', assignment, tutorprofile.id, nmsg)
            # OverAllNotification.objects.create(n_type="solutionsUploaded", work_type='a', work_id=assignment.id, notification_to='a', to_id=request.user.tutorprofile.id, title=ntitle, notif_message=nmsg)
            return HttpResponseRedirect('/tutor/assignment/'+str(atut.id)+'/')
    context = {
        'assignment': assignment,
        'atut': atut,
        'form': form,
        'photos_list': photos_list,
        'tutorprofile': tutorprofile,
    }
    return render(request, 'tutor/aanswers.html', context)


@login_required
def aanswers1(request, atut_id):
    atut = ATutor.objects.get(id=atut_id)
    if atut.tutor and (atut.tutor.user == request.user or atut.expert_review):
        assignment = atut.assignment
        if atut.expert_review:
            aas = AA.objects.filter(active_status=1,tutor_assignment__assignment=assignment)
        else:
            aas = AA.objects.filter(tutor_assignment=atut, active_status=1)
        refdate = datetime(year=2019,month=7,day=16,tzinfo=pytz.UTC)
        # for a in aas:
        #     if a.answer:
        #         if '/rest/' in a.answer.url:
        #                 a.answer.urll = 'https://media.snapqa.co/'+str(a.answer)
        #             # else:
        #             #     a.answer.urll = 'https://tutorbin.com'+a.answer
        #         else:
        #             if a.time<refdate:
        #                 a.answer.urll = 'https://media.snapqa.co'+a.answer.url
        #             else:
        #                 a.answer.urll = 'https://tutorbin.com'+a.answer.url
        return render(request, 'tutor/aanswers1.html', {'assignment':assignment , 'atut': atut, 'aas': aas})
    else:
        return HttpResponse("You are on the wrong page.")


@login_required
def aquestion(request, assignment_id):
    assignment = get_object_or_404(Assignment, pk=assignment_id)
    #que = QA.objects.all()
    photos_list = QA.objects.filter(assignment=assignment_id)
    old_listQ = list(photos_list.values('question'))
    request.session['old_listQ'] = old_listQ
    return render(request, 'tutor/aquestion.html', {'assignment': assignment})

@login_required
def aquestion1(request, assignment_id):
    qas = QA.objects.filter(assignment=assignment_id, active_status=1)
    return render(request, 'tutor/aquestion1.html', {'qas':qas})


@login_required
def areference(request, assignment_id):
    assignment = get_object_or_404(Assignment, pk=assignment_id)
    ref = RA.objects.all()
    photos_list = RA.objects.filter(assignment=assignment_id)
    old_listR = list(photos_list.values('reference'))
    request.session['old_listR'] = old_listR
    return render(request, 'tutor/areference.html', {'ref': ref, 'assignment': assignment})

@login_required
def areference1(request, assignment_id):
    ras = RA.objects.filter(assignment=assignment_id, active_status=1)
    return render(request, 'tutor/areference1.html', {'ras': ras})


def session_detail(request, stut_id):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        user = request.user
        tutorprofile = user.tutorprofile
        stut = get_object_or_404(STutor, pk=stut_id)
        manager_phone = admin_mobile_list.get(stut.session.manager)
        return render(request, 'tutor/session.html', {'user': user, 'stut': stut,'manager_phone':manager_phone})


@login_required
def sanswers(request, session_id):
    form = ASForm(request.POST or None, request.FILES or None)
    session = get_object_or_404(Session, pk=session_id)
    if form.is_valid():
        q = form.save(commit=False)
        q.session = session
        q.tutor = request.user
        q.save()
        return render(request, 'tutor/sanswers.html', {'session': session})
    context = {
        'session': session,
        'form': form,
    }
    return render(request, 'tutor/sanswers.html', context)


@login_required
def squestion(request, session_id):
    session = get_object_or_404(Session, pk=session_id)
    que = QS.objects.all()
    return render(request, 'tutor/squestion.html', {'que': que, 'session': session})


@login_required
def sreference(request, session_id):
    session = get_object_or_404(Session, pk=session_id)
    ref = RS.objects.all()
    return render(request, 'tutor/sreference.html', {'ref': ref, 'session': session})

@login_required
def sreference1(request, session_id):
    rss = RS.objects.filter(session=session_id, active_status=1)
    return render(request, 'tutor/areference1.html', {'ras': rss})

def profile(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        user = request.user
        tutorprofile = user.tutorprofile
        branches1 = Branch.objects.all().order_by('branch')
        tsubjects = TSubjects.objects.filter(userprofile=tutorprofile, selected=True, failed=False).order_by('subject')
        branches2 = []
        OverAllNotification.objects.filter(to_id=tutorprofile.id, work_type='rs').update(seen=True)
        for tsub in tsubjects:
            if tsub.branch not in branches2:
                branches2.append(tsub.branch)
        branches = [branch.branch for branch in branches1 if branch.branch in branches2]

        earnedAmts = RedeemMoney.objects.filter(userprofile=tutorprofile, status='earned')
        earnedAmt = 0
        for y in earnedAmts:
            earnedAmt += y.amount
        initials = tutorprofile.name.split(' ') if tutorprofile.name else ['T']
        nick = ''
        for txt in initials:
            nick+=txt[0]

        tsubjects_json = TSubjectsSerializer(tsubjects,many=True).data

        return JsonResponse({'earnedAmt':earnedAmt, 'branches':branches, 'nick':nick,'tsubjects': tsubjects_json})
        # return render(request, 'tutor/profile.html', {'profile': profile, 'user': user, 'tsubjects': tsubjects, 'tutorprofile': tutorprofile, 'earnedAmt':earnedAmt, 'branches':branches, 'nick':nick})


def update_profile(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        profile_form = ProfileForm1(request.POST or None, instance=request.user.tutorprofile)
        if profile_form.is_valid():
            editprofile = profile_form.save(commit=False)
            editprofile.user = request.user
            editprofile.save(update_fields=['name', 'whatsapp', 'university', 'highest_degree'])
            return HttpResponseRedirect('/tutor/profile/')
#             return render(request, 'tutor/profile.html', {'formerror': 'Profile updated successfully.'})
        context = {
            "profile_form": profile_form,
        }
        return render(request, 'tutor/profile.html', context)

@login_required
def smartpind(request):
    tutor = request.user.tutorprofile
    redeemed = RedeemMoney.objects.filter(userprofile=tutor,smartpind=True).order_by('-id')
    return render(request, 'tutor/sp_payment.html', {'redeemed': redeemed, 'tutorprofile': tutor})

@login_required
def pay_sp(request):
    return HttpResponse('Smartpind payments have been disabled for some time. Sorry for invonvenience.')
    tutorprofile = request.user.tutorprofile
    if request.method=='POST' and float(request.POST.get('amount')) <= float(tutorprofile.balance):
        redeemed = round(float(request.POST.get('amount')),2)
        old_balance = tutorprofile.balance
        new_balance = old_balance - redeemed
        RedeemMoney.objects.create(userprofile=tutorprofile,status='transferred',current_balance=new_balance,amount=redeemed,smartpind=True)
        TutorProfile.objects.filter(user=tutorprofile.user).update(balance=new_balance)
    return HttpResponseRedirect('/tutor/smartpind')


# def update_subjects_old(request):
#     if hasattr(request.user,'tutorprofile'):
#         if request.user.tutorprofile.verified == False:
#             return HttpResponseRedirect('/tutor/addprofile/')
#         elif not request.user.tutorprofile.agreed:
#             return HttpResponseRedirect('/tutor/tutoragreement/')
#         elif hasattr(request.user.tutorprofile, 'testassignment') and not (request.user.tutorprofile.testassignment.status in ['n', 'o', 'p']):
#             return HttpResponseRedirect('/tutor/welcome/')
#         else:
#             form = SubjectsForm(request.POST or None)
#             tutorprofile = get_object_or_404(TutorProfile, user=request.user)
#             tsubjects = TSubjects.objects.filter(userprofile=tutorprofile)
#             tsubjects_failed = TSubjects.objects.filter(userprofile=tutorprofile, failed=True)
#             tutor_failed_subjs = [[x.subject, x.branch] for x in tsubjects_failed]
#             branchs = Branch.objects.all().order_by('top')
#             xSub = Xsubject.objects.all()
#             xBranch = Xbranch.objects.all()
#             xSubList = [[x.xsubject.subject, x.xsubject.branch.branch]
#                         for x in xSub]
#             xBranchList = [x.xbranch.branch for x in xBranch]
#             branchs1 = [b.branch for b in branchs]
#             tbranch1 = [b.branch for b in tsubjects]
#             branchset = set(tbranch1) | set(branchs1) - set(xBranchList)
#             branchlist = list(branchset)
#             branchlist.sort()
#             # if tutorprofile.tested:        if we want to limit branches to update
#             #    branchlist1=set(TSubjects.objects.filter(userprofile=tutorprofile).values_list('branch', flat=True))
#             #    branchlist = list(branchlist1)
#             #    branchlist.append('Misc')
#             all_subjects = []
#             for b in branchs:
#                 for s in b.subject_set.all():
#                     su = [s.subject, s.branch.branch]
#                     if su not in tutor_failed_subjs:
#                         all_subjects.append(su)

#             def getKey(item):
#                 return item[0]
#             all_subjects.sort(key=getKey)
#             tutor_subjectlist = []
#             tutor_selected_subject_list = []
#             for ts in tsubjects:
#                 for b in branchs:
#                     for s in b.subject_set.all():
#                         if ts.subject == s.subject and ts.branch == s.branch.branch:
#                             tutor_subjectlist.append(
#                                 [s.subject, s.branch.branch])
#                             if ts.selected == True and ts.failed == False:
#                                 tutor_selected_subject_list.append(
#                                     [s.subject, s.branch.branch])

#             list1 = request.POST.getlist('subjects')
#             if form.is_valid():
#                 if not tutorprofile.tested:
#                     list1 = request.POST.getlist('subjects')
#                     if not len(list1) > 0:
#                         context = {'form': form,'tutor_selected_subject_list': tutor_selected_subject_list,'branchlist': branchs,'all_subjects': all_subjects,'xSubList': xSubList,'xBranchList': xBranchList,'testedus':True if request.user.tutorprofile.tested else False}
#                         return render(request, 'tutor/update_subjects.html', context)

#                     # automating tutor test assign

#                     list2 = []

#                     tsubs = []
#                     for tsub in tsubjects:
#                         tsubs.append(tsub.subject+'-'+tsub.branch)

#                     for l in list1:
#                         if l not in tsubs:
#                             list2.append(l)
#                             TSubjects.objects.get_or_create( userprofile=tutorprofile, branch=l.split('-')[1], subject=l.split('-')[0], selected=True)


#                     tsubjects1 = TSubjects.objects.filter(userprofile=tutorprofile, selected=True, tested=False, failed=False)
#                     tsubs1 = []
#                     for tsub in tsubjects1:
#                         tsubs1.append(tsub.subject+'-'+tsub.branch)

#                     assignTest(tutorprofile, tsubs1)

#                     return HttpResponseRedirect('/tutor/test/')
#                 else:
#                     list1 = request.POST.getlist('subjects')
#                     tsubs = []
#                     for tsub in tsubjects:
#                         tsubs.append(tsub.subject+'-'+tsub.branch)
#                     # print(tsubs)
#                     # print(list1)

#                     list2 = []
#                     list3 = []
#                     list4 = []

#                     for l in list1:
#                         if l not in tsubs:
#                             list2.append(l)
#                             TSubjects.objects.get_or_create( userprofile=tutorprofile, branch=l.split('-')[1], subject=l.split('-')[0])

#                     for t in tsubs:
#                         if t not in list1:
#                             list3.append(t)
#                             TSubjects.objects.filter(userprofile=tutorprofile, branch=t.split('-')[1], subject=t.split('-')[0]).update(selected=False)

#                         if t in list1:
#                             list4.append(t)
#                             TSubjects.objects.filter(userprofile=tutorprofile, branch=t.split('-')[1], subject=t.split('-')[0]).update(selected=True)


#                     tsubjects1 = TSubjects.objects.filter(userprofile=tutorprofile, selected=True, tested=False, failed=False)
#                     tsubs1 = []
#                     for tsub in tsubjects1:
#                         tsubs1.append(tsub.subject+'-'+tsub.branch)

#                     if len(tsubs1) > 0:
#                         assignTest(tutorprofile, tsubs1)

#                         tutorprofile.newtest = True
#                         tutorprofile.save()
#                         if tutorprofile.testassignment.qtest_set.all().count() > 0:
#                             tutorprofile.testassignment.status = 'as'
#                         else:
#                             tutorprofile.testassignment.status = 'su'
#                         tutorprofile.testassignment.save()
#                         return HttpResponseRedirect('/tutor/welcome/')


#             context = {
#                 'form': form,
#                 'tutor_selected_subject_list': tutor_selected_subject_list,
#                 'branchlist': branchs,
#                 'all_subjects': all_subjects,
#                 'xSubList': xSubList,
#                 'xBranchList': xBranchList
#             }
#             if request.user.tutorprofile.tested:
#                 context['testedus'] = False
#             else:
#                 context['testedus'] = True
#             return render(request, 'tutor/update_subjects_old.html', context)
#     else:
#         return HttpResponseRedirect('/tutor/login_user/')

@csrf_exempt
def update_subjects(request):
    if hasattr(request.user,'tutorprofile'):
        if request.user.tutorprofile.verified == False:
            return HttpResponseRedirect('/tutor/addprofile/')
        elif not request.user.tutorprofile.agreed:
            return HttpResponseRedirect('/tutor/tutoragreement/')
        elif hasattr(request.user.tutorprofile, 'testassignment') and not (request.user.tutorprofile.testassignment.status in ['n', 'o', 'p']):
            return HttpResponseRedirect('/tutor/welcome/')
        elif request.user.tutorprofile.tested and request.user.tutorprofile.allow_sub_update is False:
            return HttpResponseRedirect('/tutor/')
        else:
            tutorprofile = request.user.tutorprofile
            if request.method == 'POST':

                list1 = json.loads(request.body)

                TSubjects.objects.filter(userprofile=tutorprofile,selected=True).update(selected=False)
                for x in list1:
                    splitted = x.rsplit('-',1)
                    TSubjects.objects.update_or_create(branch=splitted[1],subject=splitted[0],userprofile_id=tutorprofile.id,defaults={'selected':True})

                tsubjects1 = TSubjects.objects.filter(userprofile=tutorprofile, selected=True, tested=False, failed=False)
                tsubs1 = [tsub.subject+'-'+tsub.branch for tsub in TSubjects.objects.filter(userprofile=tutorprofile, selected=True, tested=False, failed=False)]

                if tutorprofile.tested:

                    if len(tsubs1) > 0:
                        assignTest(tutorprofile, tsubs1)

                        tutorprofile.newtest = True
                        tutorprofile.save()
                        if tutorprofile.testassignment.qtest_set.all().count() > 0:
                            tutorprofile.testassignment.status = 'as'
                        else:
                            tutorprofile.testassignment.status = 'su'
                        tutorprofile.testassignment.save()
                        return HttpResponseRedirect('/tutor/welcome/')

                else:
                    if not len(list1) > 0:
                        return HttpResponseRedirect('/tutor/update_subjects/')

                    assignTest(tutorprofile, tsubs1)

                    return HttpResponseRedirect('/tutor/test/')

                return JsonResponse({'success':True})
            branches = Branch.objects.order_by('-top')
            selected = TSubjects.objects.filter(userprofile=request.user.tutorprofile, selected=True)
            xBranchList = [x.xbranch.branch for x in Xbranch.objects.all()]
            branch_list = []

            for br in branches:
                selected_in_branch = selected.filter(branch=br.branch).values_list('subject',flat=True)
                failed_in_branch = selected.filter(branch=br.branch, failed=True).values_list('subject',flat=True)
                br_subs = Subject.objects.filter(branch=br)
                xSubList = [x.xsubject.subject for x in Xsubject.objects.filter(xsubject__branch=br)]
                finals_subs = [item for item in br.subject_set.all() if item.subject not in xSubList]
                if br.branch in xBranchList:
                    subject_list = [{'name':sub.subject,'id':sub.id,'selected':True if sub.subject in selected_in_branch else False, 'failed': True if sub.subject in failed_in_branch else False} for sub in finals_subs if sub.subject in selected_in_branch]
                else:
                    subject_list = [{'name':sub.subject,'id':sub.id,'selected':True if sub.subject in selected_in_branch else False, 'failed': True if sub.subject in failed_in_branch else False} for sub in finals_subs]

                branchdata = {
                    'name':br.branch,
                    'icon':br.branch_icon.url,
                    'top':br.top,
                    'id':br.id,
                    'subjects':subject_list
                }
                if len(subject_list) > 0:
                    branch_list.append(branchdata)

            context = {
                'branchlist': json.dumps(branch_list),
                'tutor': tutorprofile
            }
            return render(request, 'tutor/update_subjects.html', context)
    else:
        return HttpResponseRedirect('/tutor/login_user/')

@login_required
def request_sub_update(request):
    tp = request.user.tutorprofile
    tp.request_sub_update = True
    tp.allow_sub_update = False
    tp.save()
    return HttpResponseRedirect('/tutor/profile/')

def update_payment(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        tutor = request.user.tutorprofile
        form = PaymentForm(request.POST or None, instance=tutor)
        if form.is_valid():
            q = form.save(commit=False)
            # q.userprofile = profile

            user = request.user
            pan = request.POST.get('pan')
            ac_name = request.POST.get('ac_name')
            bank_ac = request.POST.get('bank_ac')
            ifsc = request.POST.get('ifsc')

            url = 'https://'+settings.RZP_KEY+':'+settings.RZP_CODE+'@api.razorpay.com/v1/contacts'
            payload = {
               "name": tutor.name,
               "email": str(user.email),
               "contact": str(tutor.phone),
               "type":"Tutor",
               "reference_id": str(tutor.id),
            }

            r = requests.post(url, json=payload)
            data = r.json()
            if 'id' in data:
                url1 = 'https://'+settings.RZP_KEY+':'+settings.RZP_CODE+'@api.razorpay.com/v1/fund_accounts'
                payload1 = {
                    "contact_id": data['id'],
                    "account_type": "bank_account",
                    "bank_account": {
                        "name": str(ac_name),
                        "ifsc": str(ifsc),
                        "account_number": str(bank_ac)
                    }
                }
                rr = requests.post(url1, json=payload1)
                resp = rr.json()
                if 'id' in resp:
                    q.razorx_id = resp['id']
                    q.mode = "Bank"
                    q.save(update_fields=['pan', 'ac_name', 'bank_ac', 'ifsc', 'razorx_id'])
                    return HttpResponseRedirect('/tutor/update_payment/')
                elif 'error' in resp:
                    context = {
                        'form': form,
                        'formerror':resp['error']['description'],
                        'tutorprofile': tutor
                    }
                else:
                    context = {
                        'form': form,
                        'formerror':"Something went wrong",
                        'tutorprofile': tutor
                    }
            elif 'error' in data:
                context = {
                    'form': form,
                    'formerror':data['error']['description'],
                    'tutorprofile': tutor
                }
            else:
                context = {
                    'form': form,
                    'formerror':"Something went wrong",
                    'tutorprofile': tutor
                }
            return render(request, 'tutor/update_payment.html', context)

        elif request.method== "POST":
            context = {
                'form': form,
                'formerror':"fill up form correctly",
                'tutorprofile': tutor
            }
            return render(request, 'tutor/update_payment.html', context)
        context = {
            'form': form,
            'tutorprofile': tutor
        }
        return render(request, 'tutor/update_payment.html', context)


def payment(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        user = request.user
        tutor = user.tutorprofile
        form = PaymentForm(request.POST or None, instance=tutor)
        if form.is_valid():
            q = form.save(commit=False)
            # q.userprofile = profile

            user = request.user
            pan = request.POST.get('pan')
            mode = request.POST.get('mode')
            ac_name = request.POST.get('ac_name')
            bank_ac = request.POST.get('bank_ac')
            ifsc = request.POST.get('ifsc')

            tutor.mode = mode
            tutor.save()

            url = 'https://'+settings.RZP_KEY+':'+settings.RZP_CODE+'@api.razorpay.com/v1/contacts'
            payload = {
               "name": tutor.name,
               "email": str(user.email),
               "contact": str(tutor.phone),
               "type":"Tutor",
               "reference_id": str(tutor.id),
            }

            r = requests.post(url, json=payload)
            data = r.json()
            if 'id' in data:
                url1 = 'https://'+settings.RZP_KEY+':'+settings.RZP_CODE+'@api.razorpay.com/v1/fund_accounts'
                payload1 = {
                    "contact_id": data['id'],
                    "account_type": "bank_account",
                    "bank_account": {
                        "name": str(ac_name),
                        "ifsc": str(ifsc),
                        "account_number": str(bank_ac)
                    }
                }
                rr = requests.post(url1, json=payload1)
                resp = rr.json()
                if 'id' in resp:
                    q.razorx_id = resp['id']
                    q.mode = "Bank"
                    q.save(update_fields=['pan', 'ac_name', 'bank_ac', 'ifsc', 'razorx_id'])
                    return HttpResponseRedirect('/tutor/payment/')
                elif 'error' in resp:
                    context = {
                        'form': form,
                        'formerror':resp['error']['description'],
                        'tutorprofile': tutor
                    }
                else:
                    context = {
                        'form': form,
                        'formerror':"Something went wrong",
                        'tutorprofile': tutor
                    }
            elif 'error' in data:
                context = {
                    'form': form,
                    'formerror':data['error']['description'],
                    'tutorprofile': tutor
                }
            else:
                context = {
                    'form': form,
                    'formerror':"Something went wrong",
                    'tutorprofile': tutor
                }
            return render(request, 'tutor/payment.html', context)
            # return HttpResponseRedirect('/tutor')
        else:
            refdate=datetime.utcnow().replace(tzinfo=pytz.UTC) - timedelta(days=10)
            earned_recently = RedeemMoney.objects.filter(userprofile=tutor,status='earned',time__gte=refdate).aggregate(Sum('amount'))['amount__sum']
            redeemable = math.floor((tutor.balance - .3*earned_recently if earned_recently else tutor.balance)*100)/100
            redeemed = RedeemMoney.objects.filter(userprofile=tutor,smartpind=False).order_by('-time')
            tds_paid = RedeemMoney.objects.filter(userprofile=tutor,status='tds').aggregate(Sum('amount'))['amount__sum']
            return render(request, 'tutor/payment.html', {'redeemed': redeemed, 'tutorprofile': tutor,'earned_recently':earned_recently,'total_earned':tutor.total_earned,'redeemable':redeemable,'tds':tds_paid,'on_hold':math.ceil(.3*earned_recently*100)/100 if earned_recently else None})


def redeemmoney(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect('/tutor/login_user/')
    else:
        tutorprofile = get_object_or_404(TutorProfile, user=request.user)
        form = RedeemMoneyForm(request.POST or None)
        if form.is_valid():
            refdate=datetime.utcnow().replace(tzinfo=pytz.UTC) - timedelta(days=10)
            earned_recently = RedeemMoney.objects.filter(userprofile=tutorprofile,status='earned',time__gte=refdate).aggregate(Sum('amount'))['amount__sum']
            redeemable = round(tutorprofile.balance - .3*earned_recently if earned_recently else tutorprofile.balance,2)
            if float(request.POST.get('amount')) <= redeemable:
                m = form.save(commit=False)

                redeemed = round(float(request.POST.get('amount')),2)
                old_balance = tutorprofile.balance
                new_balance = old_balance - redeemed

                m.userprofile = tutorprofile
                m.status = 'Requested'
                m.current_balance = new_balance
                m.save()

                TutorProfile.objects.filter(user=tutorprofile.user).update(balance=new_balance)
                return HttpResponseRedirect('/tutor/payment/')
        context = {
            "form": form
        }
        return HttpResponseRedirect('/tutor/payment/')


@login_required
def atchatbox(request, atutor_id):
    atutor = get_object_or_404(ATutor, pk=atutor_id)
    c = ATChat.objects.filter(atutor=atutor)
    return render(request, 'tutor/achatbox.html', {'chat': c, 'atutor': atutor})


@login_required
def atpost(request, atutor_id):
    if request.method == "POST":
        msg = request.POST.get('msgbox', None)
        atutor = ATutor.objects.get(pk=atutor_id)
        to = atutor.tutor.user
        c = ATChat(to=to, user=request.user, message=msg, atutor=atutor)
        if msg != '':
            c.save()
            #TutMsgNotif.objects.create(chat=c,seen=False)
        data = {}
        data['msg'] = 'msg'
        #data['atutor'] = serializers.serialize('json', [atutor])
        return JsonResponse(data)
    else:
        return HttpResponse('Request must be POST.')


@login_required
def atmessages(request, atutor_id):
    atutor = get_object_or_404(ATutor, pk=atutor_id)
    c = ATChat.objects.filter(atutor=atutor)
    return render(request, 'tutor/amessages.html', {'chat': c, 'atutor': atutor})


@login_required
def stchatbox(request, session_id):
    session = get_object_or_404(Session, pk=session_id)
    c = STChat.objects.all()
    return render(request, 'tutor/stchatbox.html', {'home': 'active', 'chat': c, 'session': session})


@login_required
def stpost(request, session_id):
    if request.method == "POST":
        msg = request.POST.get('msgbox', None)
        session = Session.objects.get(pk=session_id)
        c = STChat(user=request.user, message=msg, session=session)
        if msg != '':
            c.save()
        data = {}
        data['msg'] = 'msg'
        data['session'] = serializers.serialize('json', [session])
        data['user'] = 'c.user.username'
        return JsonResponse(data)
    else:
        return HttpResponse('Request must be POST.')


@login_required
def stmessages(request, session_id):
    session = get_object_or_404(Session, pk=session_id)
    c = STChat.objects.all()
    return render(request, 'tutor/smessages.html', {'chat': c, 'session': session})

@csrf_exempt
def atchatfileupload(request, thread):
    if request.method == 'POST' and request.user.is_authenticated:
        file = request.FILES.get('file', None)
        atr = ATutorResponse.objects.get(id=thread)
        thread = atr.atutorchatthread

        filename = file.name.lower()
        filename = re.sub("[^0-9a-zA-Z.]+", "", filename)
        thumb_path = file.name + ".png"

        reply_to = ATutorChatMessage.objects.get(id=request.GET.get('replyto')) if request.GET.get('replyto') else False
        message = ATutorChatMessage.objects.create(thread=thread, sender=request.user, type=1)
        chatfile = ATutorChatFile.objects.create(thread=thread, file=file, message=message)

        data = {}
        data['url'] = chatfile.file.url
        data['filename'] = filename
        r = requests.request(method='post', url=settings.INCOGNITO_SERVER + '/api/thumbnail/', data=json.dumps(data), stream=True)

        with open(thumb_path, 'wb') as f:
            r.raw.decode_content = True
            shutil.copyfileobj(r.raw, f)


        chatfile.thumbnail = File(open(thumb_path, 'rb'))
        chatfile.save()

        message.message = chatfile.thumbnail.url
        if reply_to:
            message.reply_to = reply_to
        message.save()

        if request.user.is_staff:
            thread.latest_from_admin = True
        else:
            thread.latest_from_admin = False

        thread.latest_message = file.name + ' uploaded.'
        thread.save()

        os.remove(thumb_path)
        # os.remove(filename)

        message_object = {
            'type':'chat_message',
            'chat_id':message.id,
            'ass':thread.atr.id,
            'with': 'tutor',
            'message': message.message,
            'msgtype':'file',
            'user':request.user.id,
            'student':thread.user.id,
            'usertime':message.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
            'admintime':message.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
            'reply_to_id':message.reply_to.id if message.reply_to else False,
            'reply_to_msg':message.reply_to.message if message.reply_to else False,
            'key':settings.SOCKET_KEY,
            'sentbyadm':False,
            'manager':thread.atr.task.assignment.manager.lower().replace(" ", ""),
            'username':request.user.username
        }

        if request.user.is_staff:
            message_object['sentbyadm']=True
            message_object['admintime']=message.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p")

        notif_object = {
            'type': 'notif',
            'with': 'tutor',
            'assignment_id':thread.atr.id,
            'name': thread.user.username,
            'ntype':'chat_notif',
            'time':thread.updated.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
            'msg':thread.latest_message,
            'assg_title':thread.atr.task.assignment.title,
            'seen': not(thread.latest_from_admin),
            'key':settings.SOCKET_KEY,
            'tutor':thread.user.id,
            'manager':thread.atr.task.assignment.manager.lower().replace(" ", "")
        }

        r = requests.post(settings.SOCKET_URL+"/chatfile_tutor/", json=[ message_object, notif_object ])
        # r = requests.post(settings.SOCKET_URL+"/chatfile_client_notif/", data=notif_object)

        return JsonResponse({'success': True})
    else:
        return JsonResponse({'success': False})


@csrf_exempt
def atutorchatfiledownload(request, chat_id):
    # print(request.method, request.user.is_authenticated)
    if request.method == 'POST' and request.user.is_authenticated:
        msg = ATutorChatMessage.objects.get(id=chat_id)
        # print(msg.id, chat_id, msg.type)
        if msg.type == 1:
            return JsonResponse({ 'success': True, 'url': msg.atutorchatfile.file.url })
        else:
            return JsonResponse({'success': False})
    else:
        return JsonResponse({'success': False})

@csrf_exempt
def stchatfileupload(request, thread):
    if request.method == 'POST' and request.user.is_authenticated:
        file = request.FILES.get('file', None)
        str = STutorResponse.objects.get(id=thread)
        thread = str.stutorchatthread

        filename = file.name.lower()
        filename = re.sub("[^0-9a-zA-Z.]+", "", filename)
        thumb_path = file.name + ".png"

        reply_to = STutorChatMessage.objects.get(id=request.GET.get('replyto')) if request.GET.get('replyto') else False
        message = STutorChatMessage.objects.create(thread=thread, sender=request.user, type=1)
        chatfile = STutorChatFile.objects.create(thread=thread, file=file, message=message)

        data = {}
        data['url'] = chatfile.file.url
        data['filename'] = filename
        r = requests.request(method='post', url=settings.INCOGNITO_SERVER + '/api/thumbnail/', data=json.dumps(data), stream=True)

        with open(thumb_path, 'wb') as f:
            r.raw.decode_content = True
            shutil.copyfileobj(r.raw, f)


        chatfile.thumbnail = File(open(thumb_path, 'rb'))
        chatfile.save()

        message.message = chatfile.thumbnail.url
        if reply_to:
            message.reply_to = reply_to
        message.save()

        if request.user.is_staff:
            thread.latest_from_admin = True
        else:
            thread.latest_from_admin = False

        thread.latest_message = file.name + ' uploaded.'
        thread.save()

        os.remove(thumb_path)
        # os.remove(filename)

        message_object = {
            'type':'chat_message',
            'chat_id':message.id,
            'ass':thread.str.id,
            'with': 'stutor',
            'message': message.message,
            'msgtype':'file',
            'user':request.user.id,
            'student':thread.user.id,
            'usertime':message.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
            'admintime':message.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
            'reply_to_id':message.reply_to.id if message.reply_to else False,
            'reply_to_msg':message.reply_to.message if message.reply_to else False,
            'key':settings.SOCKET_KEY,
            'sentbyadm':False,
            'manager':thread.str.session.manager.lower().replace(" ", ""),
            'username':request.user.username
        }

        if request.user.is_staff:
            message_object['sentbyadm']=True
            message_object['admintime']=message.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p")

        notif_object = {
            'type': 'notif',
            'with': 'stutor',
            'assignment_id':thread.str.id,
            'name': thread.user.username,
            'ntype':'chat_notif',
            'time':thread.updated.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
            'msg':thread.latest_message,
            'assg_title':thread.str.session.subject,
            'seen': not(thread.latest_from_admin),
            'key':settings.SOCKET_KEY,
            'tutor':thread.user.id,
            'manager':thread.str.session.manager.lower().replace(" ", "")
        }

        r = requests.post(settings.SOCKET_URL+"/chatfile_tutor/", json=[ message_object, notif_object ])
        # r = requests.post(settings.SOCKET_URL+"/chatfile_client_notif/", data=notif_object)

        return JsonResponse({'success': True})
    else:
        return JsonResponse({'success': False})


@csrf_exempt
def stutorchatfiledownload(request, chat_id):
    # print(request.method, request.user.is_authenticated)
    if request.method == 'POST' and request.user.is_authenticated:
        msg = STutorChatMessage.objects.get(id=chat_id)
        # print(msg.id, chat_id, msg.type)
        if msg.type == 1:
            return JsonResponse({ 'success': True, 'url': msg.stutorchatfile.file.url })
        else:
            return JsonResponse({'success': False})
    else:
        return JsonResponse({'success': False})


@login_required
def tchatbox_api(request):
    type = request.GET.get('type','tutor')
    # print(type)
    if type == 'tutor':
        atr_id = request.GET.get('id',False)
        if atr_id:
            atr_q = get_object_or_404(ATutorResponse,pk=atr_id)
        else:
            atutor_id = request.GET.get('atutor_id',False)
            atutor = get_object_or_404(ATutor,pk=atutor_id)
            atr_q = atutor.atutorresponse
            atr_id = atr_q.id
        tutor = atr_q.tutor
        # atr_q = ATutorResponse.objects.filter(pk=atr_id)
        # for a in atr_q:
        atr = {
            'id':atr_q.id,
            'tutor':atr_q.tutor.id,
            'name':atr_q.tutor.name,
            'atutor':atr_q.atutor_id if atr_q.atutor else None,
            'status':atr_q.status,
            'assignment':atr_q.task.assignment_id if atr_q.task else None,
            'task':atr_q.task.id if atr_q.task else None,
        }
        c = ATutorChatThread.objects.get_or_create(atr_id=atr_id,defaults={'user':tutor.user})[0]
        chats = c.atutorchatmessage_set.all().order_by('timestamp')
        chat = []
        for x in chats:
            cdict = {
                'chat_id': x.id,
                'reply_to_id': x.reply_to.id if x.reply_to else None,
                'reply_to_msg': x.reply_to.message if x.reply_to else None,
                'message' : x.message,
                'msgtype' : x.type,
                'filetype' : x.atutorchatfile.type if x.type == 1 else None,
                'seen' : x.seen,
                'from' : x.sender.id,
                'from_name' : x.sender.username,
                'time' : x.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
            }
            chat.append(cdict)

        data = json.dumps({'chat': chat, 'atr': atr,'user':tutor.user_id, 'seen':c.latest_seen if c.latest_from_admin == False else True})
        return JsonResponse(data, safe=False)
    elif type == 'stutor':
        str_id = request.GET.get('id')
        if str_id:
            str_q = get_object_or_404(STutorResponse,pk=str_id)
        else:
            session_id = request.GET.get('session_id',False)
            tutor_id = request.GET.get('tid',False)
            str_q = get_object_or_404(STutorResponse,session_id=session_id,tutor_id=tutor_id)
            str_id = str_q.id
        str = {
            'id' : str_q.id,
            'tutor' : str_q.tutor_id,
            'name' : str_q.tutor.name,
            'atutor' : str_q.stutor_id if str_q.stutor else None,
            'status' : str_q.session.status,
            'session' : str_q.session_id if str_q.session else None,
        }
        tutor = str_q.tutor
        # print(str)
        c = STutorChatThread.objects.get_or_create(str_id=str_id,defaults={'user':str_q.tutor.user})[0]
        # c = STutorChatThread.objects.filter(pk=ct.id)
        chats = c.stutorchatmessage_set.all().order_by('timestamp')
        chat = []
        for x in chats:
            cdict = {
                'chat_id': x.id,
                'reply_to_id': x.reply_to.id if x.reply_to else None,
                'reply_to_msg': x.reply_to.message if x.reply_to else None,
                'message' : x.message,
                'msgtype' : x.type,
                'filetype' : x.stutorchatfile.type if x.type == 1 else None,
                'seen' : x.seen,
                'from' : x.sender_id,
                'from_name' : x.sender.username,
                'time' : x.timestamp.astimezone(pytz.timezone('Asia/Kolkata')).strftime("%d %b, %I:%M %p"),
            }
            chat.append(cdict)

        data = json.dumps({'chat': chat, 'str': str,'user':tutor.user_id, 'seen':c.latest_seen if c.latest_from_admin == False else True})
        return JsonResponse(data, safe=False)
    else:
        return JsonResponse({ 'success': False }, safe=False)


@login_required
def seetutmsg(request, atut_id):
    atut = ATutor.objects.get(id = atut_id)
    if request.user.is_staff:
        ATChat.objects.filter(Q(to=F('user')),atutor=atut_id, seen=False).update(seen=True)
    elif request.user == atut.tutor.user:
        ATChat.objects.filter(~Q(to=F('user')),atutor=atut_id, seen=False).update(seen=True)
    return JsonResponse('seen', safe=False)

@login_required
def seestutmsg(request, stut_id):
    if request.user.is_authenticated:
        stut = STutor.objects.get(id = stut_id)
        if request.user.is_staff:
            STChat.objects.filter(Q(to=F('user')),stutor=stut_id, seen=False).update(seen=True)
        elif request.user == stut.tutor.user:
            STChat.objects.filter(~Q(to=F('user')),stutor=stut_id, seen=False).update(seen=True)
        return JsonResponse('seen', safe=False)
    else:
        return HttpResponseRedirect('/tutor/login_user/')

@login_required
def checknot(request):
    if hasattr(request.user,'tutorprofile'):
        y = OverAllNotification.objects.filter(to_id=request.user.tutorprofile.id, notification_to = 't').order_by('-date_created')[:20]
        notif = []
        for x in y:
            notif.append({'wt':x.work_type,'wid':x.work_id, 'atitle':x.title, 'msg':x.notif_message, 'time':x.date_created.astimezone(timezone.get_current_timezone()).strftime("%d %b, %I:%M %p"), 'ntype':x.n_type, 'seen':x.seen})
        return JsonResponse(notif, safe=False)
    else:
        return HttpResponseRedirect('/tutor/login_user/')

@login_required
def marknseen(request):
    OverAllNotification.objects.filter(to_id=request.user.tutorprofile.id, notification_to='t', seen=False).update(seen=True)
    return JsonResponse('seen', safe=False)

@login_required
def checkmsgs(request):
    if request.user.is_authenticated:
        tzz = timezone.get_current_timezone()
        refdate = datetime.utcnow().replace(tzinfo=pytz.UTC)-timedelta(days=15)
        atc = ATutorChatThread.objects.filter(user=request.user, updated__gte=refdate).order_by('-updated')
        stc = STutorChatThread.objects.filter(user=request.user, updated__gte=refdate).order_by('-updated')
        repeatlista, repeatlistb, newmsgs = [[] for i in range(3)]
        newmsgs = []
        for y in atc:
            if (y.latest_message):
                newmsgs.append({
                    'msg':y.latest_message,
                    'time':y.updated.astimezone(tzz).strftime("%d %b, %I:%M %p"),
                    'atr_id':y.atr.id,
                    'with':'tutor',
                    'atutor':y.atr.atutor.id if y.atr.atutor else None,
                    'subject': str(y.atr.task.assignment.id) +' - '+ y.atr.task.assignment.subject,
                    'seen': True if y.latest_from_admin is False else y.latest_seen,
                })
        for y in stc:
            if (y.latest_message):
                newmsgs.append({
                    'msg':y.latest_message,
                    'time':y.updated.astimezone(tzz).strftime("%d %b, %I:%M %p"),
                    'atr_id':y.str.id,
                    'with':'stutor',
                    'atutor':y.str.stutor.id if y.str.stutor else None,
                    'subject': str(y.str.session.id) +' - '+ y.str.session.subject,
                    'seen': True if y.latest_from_admin is False else y.latest_seen,
                })
        newmsgs = sorted(newmsgs, key=lambda k: k['time'], reverse=True)
        return JsonResponse(newmsgs, safe=False)
    else:
      return JsonResponse('nothing', safe=False)


@login_required
def marksessseen(request, sesstype, sess_id):
    tutor = request.user.tutorprofile
    if sesstype == 'a':
        sess = ATask.objects.get(pk=sess_id)
        ATutorResponse.objects.filter(task_id=sess_id,tutor=tutor,status=1).update(status=2,updated=datetime.utcnow().replace(tzinfo=pytz.UTC))
    else:
        sess = Session.objects.get(pk=sess_id)
        STutorResponse.objects.filter(session_id=sess_id,tutor=tutor,status=1).update(status=2,updated=datetime.utcnow().replace(tzinfo=pytz.UTC))
        # OverAllNotification.objects.filter(work_type=sesstype, work_id=sess.id, n_type='newWorkAvailable', to_id=tutor.id, status=0).update(status=1)
    return JsonResponse('Success', safe=False)


@login_required
def marksessrejected(request, sesstype, sess_id):
    tutor = request.user.tutorprofile
    if sesstype == 'a':
        tutor_response = ATutorResponse.objects.get(task_id=sess_id,tutor=tutor)
        if tutor_response.status in [1,2,4]:
            if tutor_response.status == 4:
                assignment = tutor_response.task.assignment
                assignment.interestedlen -= 1
                assignment.save()
                if tutor.interest_count>0:
                    tutor.interest_count-=1
                    tutor.save()
            tutor_response.status = 3
            tutor_response.save()

    else:
        # sess = Session.objects.get(pk=sess_id)
        # sessname=" session "
        tutor_response = STutorResponse.objects.get(session_id=sess_id,tutor=tutor)
        if tutor_response.status in [1,2,4]:
            if tutor_response.status == 4:
                # session = tutor_response.session
                # assignment.interestedlen -= 1
                # assignment.save()
                if tutor.interest_count>0:
                    tutor.interest_count-=1
                    tutor.save()
            tutor_response.status = 3
            tutor_response.save()

        # ovr2 = OverAllNotification.objects.filter(n_type='newWorkAvailable', work_type=sesstype, work_id=sess.id, to_id=tutor.id).order_by('-date_created')
        # if len(ovr2):
        #     ovr1 = ovr2[0]
        #     if sesstype=='a' and ovr1.status == 3:
        #         sess.interestedlen -= 1
        #         sess.save()
        #     ovr1.status = 2
        #     ovr1.save()

    return HttpResponseRedirect('/tutor/dashboard/')

@login_required
def instructions(request):
    return render(request,'tutor/instructions.html')


@user_passes_test(lambda u: u.groups.filter(name='Expert').exists())
def expert(request):
    if request.method=="POST":

        assignment_id=request.POST.get('assignment_id')
        user_id=request.POST.get('user_id')
        assignment=Assignment.objects.get(pk=assignment_id)
        tutorprofile=TutorProfile.objects.get(user__id=user_id)
        feedback=request.POST.get('feedback','')
        review=request.POST.get('reviewassg',"0")

        obj1 = assignment.expertreview.filter(tutorprofile=tutorprofile).first()
        obj2 = assignment.expertreview.filter(tutorprofile=None).first()
        if obj1 and not obj2:
            # print('loop1')
            obj1.feedback=feedback
            obj1.review=review
            obj1.save()
        elif obj2:
            # print('loop2')
            obj2.tutorprofile=tutorprofile
            obj2.feedback=feedback
            obj2.review=review
            obj2.save()
        else:
            ExpertTutorReview.objects.create(assignment=assignment,tutorprofile=tutorprofile,feedback=feedback,review=review)

    sub=list(set(TSubjects.objects.filter(userprofile__user = request.user).values_list('subject',flat=True)))
    bran=list(set(TSubjects.objects.filter(userprofile__user = request.user).values_list('branch',flat=True)))
    aforward_assignments = []
    tutor = request.user.tutorprofile
    aforward_assignments1 = Assignment.objects.filter(status='forward').order_by('deadline')
    # for a in aforward_assignments1:
    #     arev = a.expertreview.first()
    #     if not arev:
    #         if a.subject == a.branch:
    #             if not a.branch in bran:
    #                 a.rev = 'dontshow'
    #         elif not a.subject in sub:
    #             a.rev = 'dontshow'
    #         if not hasattr(a,'rev') or a.rev != 'dontshow':
    #             aforward_assignments.append(a)

    for a in aforward_assignments1:
        arev = a.expertreview.first()
        if arev:
            if arev.tutorprofile:
                if arev.tutorprofile==tutor:
                    a.rev = arev
                else:
                    a.rev='dontshow'
            else:
                 if arev.showto.all():
                     if tutor in arev.showto.all():
                         a.rev = arev
                     else:
                         a.rev='dontshow'
                 else:
                     a.rev='dontshow'
                 # else:
                 #     check1 = False
                 #     if a.subject == a.branch:
                 #         if a.branch in bran:
                 #             check1 = True
                 #     elif a.subject in sub:
                 #         check1 = True
                 #     if check1:
                 #         a.rev = arev
                 #     else:
                 #         a.rev = 'dontshow'
            if not hasattr(a,'rev') or a.rev != 'dontshow':
                aforward_assignments.append(a)

    return render(request, 'tutor/experttut.html', {'aforward_assignments': aforward_assignments,'bran':bran,'sub':sub})

@user_passes_test(lambda u: u.groups.filter(name='Expert').exists())
def expreview(request):
    if request.method=="POST":

        assignment_id=request.POST.get('assignment_id')
        user_id=request.POST.get('user_id')
        assignment=Assignment.objects.get(pk=assignment_id)
        tutorprofile=TutorProfile.objects.get(user__id=user_id)
        feedback=request.POST.get('feedback','')
        review=request.POST.get('reviewassg',"0")

        obj1 = assignment.expertreview.filter(tutorprofile=tutorprofile).first()
        obj2 = assignment.expertreview.filter(tutorprofile=None).first()
        if obj1 and not obj2:
            # print('loop1')
            obj1.feedback=feedback
            obj1.review=review
            obj1.save()
        elif obj2:
            # print('loop2')
            obj2.tutorprofile=tutorprofile
            obj2.feedback=feedback
            obj2.review=review
            obj2.save()
        else:
            ExpertTutorReview.objects.create(assignment=assignment,tutorprofile=tutorprofile,feedback=feedback,review=review)

    sub=list(set(TSubjects.objects.filter(userprofile__user = request.user).values_list('subject',flat=True)))
    bran=list(set(TSubjects.objects.filter(userprofile__user = request.user).values_list('branch',flat=True)))
    # bran=list(set(bran))
    # sub=list(set(sub))
    atutorreview_assignments = []
    tutor = request.user.tutorprofile
    atutorreview_assignments1 = Assignment.objects.filter(status='tutorreview').order_by('deadline')
    # for a in atutorreview_assignments1:
    #     arev = a.expertreview.first()
    #     if not arev:
    #         if a.subject == a.branch:
    #             if not a.branch in bran:
    #                 a.rev = 'dontshow'
    #         elif not a.subject in sub:
    #             a.rev = 'dontshow'
    #         if not hasattr(a,'rev') or a.rev != 'dontshow':
    #             atutorreview_assignments.append(a)

    for a in atutorreview_assignments1:
        arev = a.expertreview.first()
        if arev:
            if arev.tutorprofile:
                if arev.tutorprofile==tutor:
                    a.rev = arev
                else:
                    a.rev='dontshow'
            else:
                 if arev.showto.all():
                     if tutor in arev.showto.all():
                         a.rev = arev
                     else:
                         a.rev='dontshow'
                 else:
                     a.rev='dontshow'
                 # else:
                 #     check1 = False
                 #     if a.subject == a.branch:
                 #         if a.branch in bran:
                 #             check1 = True
                 #     elif a.subject in sub:
                 #         check1 = True
                 #     if check1:
                 #         a.rev = arev
                 #     else:
                 #         a.rev = 'dontshow'
            if not hasattr(a,'rev') or a.rev != 'dontshow':
                atutorreview_assignments.append(a)

    return render(request, 'tutor/experttut1.html', {'atutorreview_assignments': atutorreview_assignments,'bran':bran,'sub':sub})

@user_passes_test(lambda user: user.groups.filter(name='Expert').exists())
def addanswers(request, atut_id):
    atut = ATutor.objects.get(pk=atut_id)
    assignment = atut.assignment
    #user = atut.tutor.user
    tutorprofile = atut.tutor

    if request.method == "POST":
        qcomment = request.POST.get('comment')
        files = request.FILES.getlist('qfiles')
        for file in files:
          AA.objects.create(tutor_assignment=atut, answer=file)
        if qcomment:
            ans = AA.objects.filter(comment=None).order_by('-time')[1]
            if len(ans):
              ans.comment = qcomment
              ans.save()
            else:
              AA.objects.create(tutor_assignment=atut, comment=qcomment)
        context={'atut':atut,'responsep':'Answers Added Successfully'}
        return render(request, 'portal/aanswers.html', context)

    context = {
        'atut': atut,
    }
    #print("bbbbbbb")
    return render(request, 'portal/aanswers.html', context)

@user_passes_test(lambda user: user.groups.filter(name='Expert').exists())
def expanswers(request, atut_id):
    atut = ATutor.objects.get(id=atut_id)
    assignment = atut.assignment
    ans = AA.objects.filter(tutor_assignment=atut, active_status=1)
    refdate = datetime(year=2019,month=7,day=16,tzinfo=pytz.UTC)
    for a in ans:
        if a.answer:
            if '/rest/' in a.answer.url:
                a.answer.urll = 'https://media.snapqa.co/'+str(a.answer)
            else:
                # if a.time<refdate:
                a.answer.urll = a.answer.url
                # else:
                #     a.answer.urll = 'https://tutorbin.com'+a.answer.url
    return render(request, 'tutor/aanswers1.html', {'assignment':assignment , 'atut': atut, 'aas': ans})

def notifyme(request):
    if request.method=="POST":
        mail = request.POST.get('email')
        filepath = os.path.join(os.path.join(settings.BASE_DIR,'tutor'),'mailsubscribers.txt')
        with open(filepath, 'a+') as f:
            myfile = File(f)
            myfile.write(mail+', ')
    return render(request,'tutor/register.html',{'submitted':True})


def assignTest(tutor, subjects):

    subj_names = map(lambda x: x.split('-')[0], subjects)
    subj_all_objects = Subject.objects.filter(subject__in=subj_names)
    subj_list = [x.subject for x in subj_all_objects]
    qpools = QPool.objects.filter(subject__subject__in=subj_list).exists()
    testA = TestAssignment.objects.get_or_create(tutor=tutor)[0]

    if qpools:
        testA.status = 'assigned'
        # testA.test_count += 1
        testA.save()

        QTest.objects.filter(test=testA).delete()

        unordered = []
        for subj in subjects:
            b = Branch.objects.get(branch=subj.split("-")[1])
            s = Subject.objects.get(subject=subj.split("-")[0], branch__branch=subj.split("-")[1])
            if b.top:
                unordered.append(0 + s.priority*.01)
            else:
                unordered.append(b.priority + s.priority*.01)

        unordered, subjects = zip(*sorted(zip(unordered, subjects)))

        group_a = []
        group_b_1 = []
        group_b_2 = []
        for subj in subjects:
            b = Branch.objects.get(branch=subj.split("-")[1])
            s = Subject.objects.get(subject=subj.split("-")[0], branch__branch=subj.split("-")[1])
            if b.top:
                group_a.append(subj)
            else:
                if len(group_b_1) < 5:
                    group_b_1.append(subj)
                else:
                    group_b_2.append(subj)

        random.shuffle(group_b_2)
        group_b = group_b_1 + group_b_2

        if len(subjects) <= 4:
            for subj in subjects:
                subject = Subject.objects.get(subject=subj.split("-")[0], branch__branch=subj.split("-")[1])
                assignQue(testA, subject)
                assignQue(testA, subject)
        elif len(subjects) <= 8:
            xnum = 8 - len(subjects)
            for subj in subjects:
                subject = Subject.objects.get(subject=subj.split("-")[0], branch__branch=subj.split("-")[1])
                assignQue(testA, subject)
            for i in range(0, xnum):
                subject = Subject.objects.get(subject=subjects[i].split("-")[0], branch__branch=subjects[i].split("-")[1])
                assignQue(testA, subject)
        elif len(subjects) > 8:
                if len(group_a) < 3:
                    no_qs = 0
                    for sub in group_a:
                        subject = Subject.objects.get(subject=sub.split("-")[0], branch__branch=sub.split("-")[1])
                        assignQue(testA, subject)
                        assignQue(testA, subject)
                        no_qs += 2
                    i = 0
                    while no_qs < 8:
                        if len(group_b) > i:
                            subject = Subject.objects.get(subject=group_b[i].split("-")[0], branch__branch=group_b[i].split("-")[1])
                            assignQue(testA, subject)
                            i += 1
                        no_qs += 1
                else:
                    no_qs = 0
                    for i in range(0, 3):
                        if len(group_b) > i:
                            subject = Subject.objects.get(subject=group_b[i].split("-")[0], branch__branch=group_b[i].split("-")[1])
                            assignQue(testA, subject)
                            no_qs += 1
                    i = 0
                    while no_qs < 8:
                        j = i % len(group_a)
                        subject = Subject.objects.get(subject=group_a[j].split("-")[0], branch__branch=group_a[j].split("-")[1])
                        assignQue(testA, subject)
                        i += 1
                        no_qs += 1

        mailcontext = {'username': tutor.name}
        body = loader.render_to_string('testtutor/testassignedmail.txt', mailcontext).strip()
        htmlmsg = loader.render_to_string('testtutor/testassignedmail.html', mailcontext)
        send_mail('Test Assigned | Tutorbin', body, 'Team TutorBin<admin@tutorbin.com>',[tutor.user.email],fail_silently=False, html=htmlmsg)
    else:
        test=tutor.testassignment
        test.status='submitted'
        test.start_time = datetime.utcnow().replace(tzinfo=pytz.UTC)
        test.save()

def assignQue(testA, subject):
    used_ques = testA.used_ques.all().values_list('id', flat=True)
    questions = QPool.objects.filter(subject__subject=subject.subject).exclude(id__in=used_ques)
    questions_all = QPool.objects.filter(subject__subject=subject.subject)

    if questions.count() > 0:
        rand = random.randint(0, questions.count() - 1)
        QTest.objects.create(test=testA, question=questions[rand])
        testA.used_ques.add(questions[rand])
    elif questions_all.count() > 0:
        rand = random.randint(0, questions_all.count() - 1)
        QTest.objects.create(test=testA, question=questions_all[rand])
        testA.used_ques.add(questions_all[rand])
    else:
        pass


def assigntestToRequested():
    testAs = TestAssignment.objects.filter(status='requested')

    for testA in testAs:
        tutor = testA.tutor
        subjects = TSubjects.objects.filter(userprofile=tutor)

        assignTest(tutor, subjects)

@login_required
def submit_answers(request, atutor_id):
    atutor = get_object_or_404(ATutor,pk=atutor_id)
    if atutor.tutor.user == request.user:
        if not atutor.submitted:
            atutor.submitted = True
            atutor.save()
        assignment = atutor.assignment
        if not assignment.atutor_set.filter(submitted=False).count() and assignment.status in ['open','closed','final','askpay','notfinal']:
            assignment.status = 'forward'
            assignment.save()
        return JsonResponse({'success':True})

@login_required
def viewfiles(request, file_type, assg_id):
    models = {'q':QA,'r':RA,'a':AA,'rs':RS}
    modelstrings = {'q':'qa','r':'ra','a':'aa','rs':'rs'}
    templates = {'q':'tutor/showfiles.html','r':'tutor/showfiles.html','a':'tutor/showfiles.html','rs':'tutor/showfiles.html'}
    if file_type=='a':
        assignment = get_object_or_404(ATutor, pk=assg_id)
    elif file_type=='rs':
        assignment = get_object_or_404(Session, pk=assg_id)
    else:
        assignment = get_object_or_404(Assignment, pk=assg_id)
    #que = QA.objects.all()
    # if assignment.user and assignment.user == request.user:
    activefile = 1
    if file_type=='a':
        qList = models[file_type].objects.filter(tutor_assignment=assignment,active_status__gt=0).order_by('time')
    elif file_type=='rs':
        qList = models[file_type].objects.filter(session=assignment,active_status=1).order_by('time')
    else:
        qList = models[file_type].objects.filter(assignment=assignment,active_status=1).order_by('time')
    for q in qList:
        if file_type == 'r' or file_type == 'rs':
            q.question = q.reference
        elif file_type == 'a':
            q.question = q.answer
    return render(request, templates[file_type], {'qList': qList, 'activefile':activefile,'type':file_type,'baseurl':settings.BASE_URL, 'model':str(modelstrings[file_type])})




@csrf_exempt
def change_tutor_number(request):
    if not request.user.is_authenticated:
        return JsonResponse({"success":False,"message":"Redirect"})
    else:
        if request.method == "POST":
            user_id = request.POST.get('user_id')
            number = request.POST.get('number')
            if TutorProfile.objects.filter(phone=number,verified=True).exists():
                return JsonResponse({'success':False,'message':'Phone number registered'})
            else:
                TutorProfile.objects.filter(user=user_id).update(phone = number)
                return JsonResponse({"success":True,"message":"hello from server"})

def error_404_view(request, exception):
    data = {"name": "ThePythonDjango.com"}
    return render(request,'tutor/custom_404.html', data)
