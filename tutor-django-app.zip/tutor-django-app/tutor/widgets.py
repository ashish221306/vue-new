from pyfcm import FCMNotification
from .models import TutorProfile
from django.utils import timezone
from portal.models import OverAllNotification
from django.conf import settings
import requests
admin_mobile_list = {
    "Anup": "+91-8464006561",
    "Anup 2": "+91-9311619787",
    "Vishal": "+91-9992398737",
    "Ankit": "+91-9007741002",
    "AME": "+91-7044059876",
    "Manish": "+91-8168527154",
    "Anup 3": "+91-9161257820",
    "Zaheer": "+91-9790917883",
    "Gehlu Center": "+91-6297536474",
    "Irfan": "+91-7988924370",
    "Website":"+91-9311520919",
    "Testing":"+91-7082686818",
    "IS":"+91-9311520919"
}

push_service = FCMNotification(api_key="AAAAMFyLUfM:APA91bFpTmemEmUAgX28uE2UJG0c6pUl66cDqrI5v4h74Xmu14HA06zHiN-sWWxakUkE8AwQV9Yu3qH4d7J2GKLAG7eeE3giwVzDxccEF97ir0O81M5BlrGqv60J6odZxj4ZmR4jMBcM")
push_service1 = FCMNotification(api_key="AAAAhyj-CNU:APA91bEYEvAC8_HL5iNrwylf4MsJBrXwq8NnMslF-hzOdE4LlDanl1nhXVAYECh3K95cDBmaxf2TXwbLMAepzxWZ2KsQnJA1mLIoO_5Shrj2Wkn7N_QLrIGxoaoyRVTdUJenWkKK-Xrz")

def notify_single_tutor(n_type,sess_type,atut,tp_id,n_msg):
    ########## For Assignment
    user_id = TutorProfile.objects.values_list('user_id', flat=True).get(pk=tp_id)
    if sess_type == 'a':
        n_title= atut.assignment.subject+" assignment"
        message_title = n_title
        work_id = atut.id
        if n_type == 'removed':
            n_message = "You have been removed from "+atut.assignment.subject+" assignment. Deadline was: "+atut.assignment.deadline.astimezone(timezone.get_default_timezone()).strftime("%d %b, %I:%M %p")
            data_message = {
                "dataType": "RemovedfromAssignment",
                "atutor_id": atut.id
            }
            data_message1 = {
                "notificationType": "Removed_From_Assignment",
                "atutor_id": atut.id
            }
        elif n_type == 'workAssigned':
            n_message = "You have been assigned a "+atut.assignment.subject+" assignment. Deadline: "+atut.assignment.deadline.astimezone(timezone.get_default_timezone()).strftime("%d %b, %I:%M %p")
            data_message = {
                "dataType": "AssignedToAssignment",
                "assignment_id": atut.assignment.id
            }
            data_message1 = {
                "notificationType": "Assigned_To_Assignment",
                "assignment_id": atut.assignment.id
            }
        elif n_type == 'amountPaid':
            if n_msg:
                n_message = n_msg
            else:
                n_message=''
            data_message = {
                "dataType": "AssignmentReview",
                "assignment_id": atut.id
            }
            data_message1 = {
                "notificationType": "Assignment_Review",
                "assignment_id": atut.id
            }
        elif n_type == 'rating':
            if n_msg:
                n_message = n_msg
            else:
                n_message=''
            data_message = {
                "dataType": "AssignmentReview",
                "assignment_id": atut.id
            }
            data_message1 = {
                "notificationType": "Assignment_Review",
                "assignment_id": atut.id
            }
        elif n_type == 'tEdit':
            #n_title= atut.assignment.subject+' Assignment'
            if n_msg:
                n_message = n_msg
            else:
                n_message=''
            #message_title = n_title
            #message_body = n_message

            if 'deadline' in n_message:
                data_type = 'DeadlineChanged'
                data_type1 = 'Deadline_Changed'
            elif 'added' in n_message:
                data_type = 'MaterialAdded'
                data_type1 = 'Material_Added'
            else:
                data_type = 'MaterialChanged'
                data_type1 = 'Material_Changed'
            data_message = {
                "dataType": data_type,
                "assignment_id": atut.assignment.id
            }
            data_message1 = {
                "notificationType": data_type1,
                "AtutorId":atut.id,
                "Type": "Assignment"
            }
        elif n_type == 'editA':
            if n_msg:
                n_message = n_msg
            else:
                n_message=''
            data_message = {
                "dataType": "requestApprovedOrRejected",
                "assignment_id": atut.assignment.id
            }
            data_message1 = {
                "notificationType": "Request_Approved_Or_Rejected",
                "ATutorId": atut.id,
                "Type":"Assignment"
            }
        message_body = n_message

    ########### For Sessions
    elif sess_type=='s':
        n_title= False
        work_id = atut.id
        if n_type == 'removed':
            n_message = "You have been removed from "+atut.session.subject+" session. Start time was: "+atut.session.start_time.astimezone(timezone.get_default_timezone()).strftime("%d %b, %I:%M %p")
            data_message = {
                "dataType": "RemovedfromSession",
                "stutor_id": atut.id
            }
            data_message1 = {
                "notificationType": "Removed_From_Session",
                "stutorid": atut.id
            }
        elif n_type == 'workAssigned':
            n_message = "You have been assigned a "+atut.session.subject+" session. Start time: "+atut.session.start_time.astimezone(timezone.get_default_timezone()).strftime("%d %b, %I:%M %p")
            data_message = {
                "dataType": "AssignedToSession",
                "session_id": atut.session.id
            }
            data_message1 = {
                "notificationType": "Assigned_To_Session",
                "session_id": atut.session.id
            }
        elif n_type == 'newWorkAvailable':
            n_message = atut.subject+" session available. Start time: "+atut.start_time.astimezone(timezone.get_default_timezone()).strftime("%d %b, %I:%M %p")
            n_title = "New session available"
            data_message1 = {
                "notificationType": "New_Session_Available",
                "stutor_id": atut.id
            }
        elif n_type == 'amountPaid':
            if n_msg:
                n_message = n_msg
            else:
                n_message=''
            data_message = {
                "dataType": "SessionReview",
                "session_id": atut.id
            }
            data_message1 = {
                "notificationType": "Session_Review",
                "session_id": atut.id
            }
        elif n_type == 'rating':
            if n_msg:
                n_message = n_msg
            else:
                n_message=''
            data_message = {
                "dataType": "SessionReview",
                "session_id": atut.id
            }
            data_message1 = {
                "notificationType": "Session_Review",
                "session_id": atut.id
            }
        elif n_type == 'workCancelled':
            n_message = atut.session.subject+" session is cancelled that was to start at "+atut.session.start_time.astimezone(timezone.get_default_timezone()).strftime("%d %b, %I:%M %p")
            data_message = {
                "dataType": "SessionCancelled",
                "session_id": atut.session.id
            }
            data_message1 = {
                "notificationType": "Session_Cancelled",
                "session_id": atut.session.id
            }
        if not n_title:
            n_title = atut.session.subject+" session"
    else:
        if n_type == 'amountPaid':
            if n_msg:
                n_message = n_msg
            else:
                n_message=''
            work_id = None
            n_title='Redeem Request Processed'
            data_message = {
                "dataType": "MoneyTransferred",
                "redeem_id": atut.id
            }
            data_message1 = {
                "notificationType": "Money_Transferred",
                "redeem_id": atut.id
            }
        elif n_type == 'reqsub_a':
            n_title = 'Update Subject Request Approved'
            if n_msg:
                n_message = 'Your request for subject updation has been approved.'
            else:
                n_message=''
            work_id = None
            data_message1 = {
                "notificationType": "New_Session_Available",
                "stutor_id": None
            }
        elif n_type == 'reqsub_r':
            n_title = 'Update Subject Request Rejected'
            if n_msg:
                n_message = 'Your request for subject updation has been rejected.'
            else:
                n_message=''
            work_id = None
            data_message1 = {
                "notificationType": "New_Session_Available",
                "stutor_id": None
            }
    message_title = n_title
    message_body = n_message

    y = OverAllNotification.objects.create(n_type=n_type, work_type=sess_type, work_id=work_id, notification_to='t', to_id=tp_id, title=n_title, notif_message=n_message)

    tzz = timezone.get_current_timezone()
    data = {'type': 'notif', 'room': user_id,'wid':y.work_id, 'ntype':y.n_type, 'wt':y.work_type, 'timeactual':y.date_created,'time':y.date_created.astimezone(tzz).strftime("%d %b, %I:%M %p"), 'msg':y.notif_message, 'atitle':y.title, 'seen': y.seen, 'key':settings.SOCKET_KEY}

    rr = requests.post(settings.SOCKET_URL+"/notify_tutor/", data=data)

    tp = TutorProfile.objects.get(pk=tp_id)
    if tp.firebase_token:
        registration_id = tp.firebase_token
        # push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body, data_message=data_message)
        push_service1.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body, data_message=data_message1)
