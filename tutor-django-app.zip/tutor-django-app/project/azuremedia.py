from storages.backends.azure_storage import AzureStorage
from django.conf import settings

class AzureMediaStorage(AzureStorage):
    location = settings.AZ_MEDIA_LOCATION
    file_overwrite = False
    account_key = settings.AZ_MEDIA_KEY
    max_memory_size = 52428800
    account_name = settings.AZ_MEDIA_ACCOUNT
    azure_container = 'media'
    object_parameters = {
        'cache_control': 'max-age=432000',
    }
