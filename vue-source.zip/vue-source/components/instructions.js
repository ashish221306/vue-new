const instruction = {
  name: "instruction",

  template: `
    
 <div>
 <iframe src="../../instructions.pdf" frameborder="0"   type="application/pdf" width="100%" class="mt-4" style="height:calc(100% - 70px);"></iframe>
 </div>
    
    `,
};
