const profile = {

    data() {
        return {
            email: 'bcd@gmail.com',
            tutorprofile: [],
            copyhtml:'',
            formerror:'',
            data:[],
        }
    },
   
    methods: {
        
        copyToClipboard() {
           
                this.tutorprofile.reflink=`https://tutorbin.com/tutor/register/?referral=${ this.tutorprofile.referral_code}`
                const el = document.createElement('textarea');
                el.value = this.tutorprofile.reflink;
                document.body.appendChild(el);
                el.select();
                document.execCommand('copy');
                document.body.removeChild(el);
                this.copyhtml='<i class="fas fa-copy mr-2"></i>Copied'
                document.querySelector('#clicktocopy').classList.add('text-red','text-bold')
                
                
                setTimeout(() => {
                  this.copyhtml=`<i class="far fa-copy mr-2"></i>Copy Referral Link`
                  document.querySelector('#clicktocopy').classList.remove('text-red','text-bold')
                }, 500);
                

        }
        ,
    },
   
    created() {
        this.copyhtml=`<i class="far fa-copy mr-2"></i>Copy Referral Link`
        this.tutorprofile = this.$root.userData.tutorprofile;
        axios.get(`/tutor/api/profile`).then((response) => {
             this.data = response.data
        }).catch((err) => {
            console.log(err)
        })
    },
    template: `


    <div class="main-container">
    <div  class="parent responsive-pt">
        <div class="child">
            <div class="profile-info-row">
                    <section class="profile-card">
                        <div class="profile__info">
                            <h3 >{{ tutorprofile.name}}</h3>
                            <small class="text-white"><a data-toggle="modal" data-target="#edit-profile"><i class="fas fa-user-edit mr-1"></i> Edit Profile </a></small>
                        </div>
                        <div class="profile__image">
                            <!--<div class="profile__initials">
                                {{nick}}
                            </div>-->
                            <img src="/static/tutor/images/Web.png" alt="" class="w-100 shadow-sm rounded-circle">
                        </div>
                        <div class="profile__stats">
                            <div class="profile__stat">
                                <div class="profile__icon text-yellow"><i class="fas fa-star"></i></div>
                                <div class="profile__value">{{parseFloat(tutorprofile.rating).toFixed(2)}}
                                    <div class="profile__key">Rating</div>
                                </div>
                            </div>
                            <div class="profile__stat">
                                <div class="profile__icon text-red"><i class="fas fa-layer-group"></i></div>
                                <div class="profile__value">{{ tutorprofile.total_sessions}}
                                    <div class="profile__key">Project</div>
                                </div>
                            </div>
                            <div class="profile__stat">
                                <div class="profile__icon text-green"><i class="fas fa-credit-card"></i></div>
                                <div class="profile__value">{{tutorprofile.total_earned}}
                                    <div class="profile__key">Earned</div>
                                </div>
                            </div>
                        </div>
                        <div class="quick-details">
                            <div class=" mt-3">
                                <table class="w-100 fs-small">
                                    <tbody>
                                    <tr>
                                        <td class="">
                                            <i class="fas fa-user mr-2 fa-lg"></i> Full Name
                                        </td>
                                        <td>
                                            {{ tutorprofile.name}}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td >
                                            <i class="fab fa-whatsapp mr-2 fa-lg"></i> Whatsapp
                                        </td>
                                        <td>
                                            {{ tutorprofile.whatsapp}}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <i class="far fa-envelope mr-2 fa-lg"></i> Email
                                        </td>
                                        <td>
                                            {{ email}}
                                        </td>
                                    </tr>
                                    <tr class="">
                                        <td>
                                            <i class="fas fa-university mr-2 fa-lg"></i> University
                                        </td>
                                        <td>
                                            {{ tutorprofile.university}}
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                                <button id="clicktocopy" data-url="https://tutorbin.com/tutor/register/?referral={{ tutorprofile.referral_code}}" class="btn bg-white shadow-sm my-4 fs-small" @click="copyToClipboard()" v-html="copyhtml"></button>
                            </div>
                        </div>
                    </section>
                <p v-if="formerror" class="lead text-green font-weight-bold"><i class="far fa-check-circle mr-2"></i> {{formerror}}</p>

            </div>
        </div>
        <div class="child">
            <div class="bg-white b-r-lg px-4 py-1 shadow-sm">
                <!--      first section-->
               
                <div v-if="data.branches">
                    <div v-for="branch in data.branches">
                        <h4 class="my-2">
                            {{branch}}
                        </h4>
                        <div class="badge-group">
                            
                           
                             <template v-for="sub in data.tsubjects">
                             <template v-if="sub.branch == branch">
                                <span class="badge badge-pill" :class="sub.tested==false ? 'bg-secondary text-white':'bg-primary text-white' "> {{sub.subject}}</span>
                              </template>
                            </template>
                          
                            
                        </div>
                    </div>
                </div>
              
                <p v-else class="text-muted text-center mt-5 font-weight-600 fs-small">No subjects selected.Please select subjects to start getting assignments</p>
              
                <div class="w-100 d-flex justify-content-center my-3">
                  
                    <button v-if="tutorprofile.tested!='' ||  tutorprofile.allow_sub_update" class="profile__button responsive-pd-x py-2" @click="window.location.href ='tutor/update_subjects'">Change subject <i class="fas fa-pencil-alt ml-1"></i></button>
               
                    <p v-else-if=" tutorprofile.request_sub_update" class="mb-0"><i class="fas fa-check-circle"></i> You have requested to update subjects, once the request is approved you will be allowed to add more subjects and take test for the new subjects. It may take 1-2 days for the request approval</p>
                   
                    <button v-else class="btn btn-primary profile__button responsive-pd-x py-2" id="requestForUpdateSubjects" type="button"   data-toggle="modal" data-target="#notify-modal">Change subject <i class="fas fa-pencil-alt ml-1"></i></button>
                  

                </div>
            </div>
        </div>
    </div>
</div>

<!--edit profile need to update form field-->
<!-- Modal -->
<div   class="modal fade" id="edit-profile" tabindex="-1" aria-labelledby="edit-profileModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-secondary" id="exampleModalLabel">Update Profile</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="tutor/update_profile" method="post" >
                {{csrf_token ? csrf_token : ''}}
            <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="name">Full name</label>
                            <input type="text" class="form-control" name="name" id="name" :value="tutorprofile.name" placeholder="Name" disabled>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="contact">Contact number</label>
                            <input type="text" class="form-control" name="contact" id="contact" :value="tutorprofile.phone" placeholder="Phone" disabled>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="whatsapp">Whatsapp number</label>
                            <input type="text" class="form-control" name="whatsapp"  oninvalid="this.setCustomValidity('Please Enter valid whatsapp number')"
                                   oninput="setCustomValidity('')" maxlength="10" required pattern="^[0-9]{10}$" id="whatsapp"  :value="tutorprofile.whatsapp" placeholder="Whatsapp">
                        </div>
                        <div class="form-group col-md-8">
                            <label for="university">University</label>
                            <input type="text" class="form-control" name="university" id="university"  :value="tutorprofile.university" placeholder="University/College" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="department">Department</label>
                        <input type="text" class="form-control" name="department" id="department"  :value="tutorprofile.department" placeholder="Department" disabled>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="specialisation">Specialisation</label>
                            <input id="specialisation" name="specialisation" class="form-control"  :value="tutorprofile.specialisation" placeholder="Specialisation" disabled/>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="degree">Highest Degree</label>
                            <input type="text" class="form-control" name="degree" id="degree" :value="tutorprofile.highest_degree" placeholder="Highest Degree" disabled>
                        </div>
                    </div>
            </div>
            <div class="modal-footer" >
                <button type="submit" class="btn btn-primary shadow-sm">Update</button>
            </div>
            </form>
        </div>
    </div>
</div>

<div   class="modal fade " id="notify-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Notification</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="modal-body">
               <p> You have requested to update subjects, once the request is approved you will be allowed to add more subjects and take test for the new subjects. It may take 1-2 days for the request approval</p>
                <a type="button" class="btn btn-primary float-right" href="tutor/request_sub_update">Confirm</a>
            </div>
        </div>
    </div>
</div>`
}