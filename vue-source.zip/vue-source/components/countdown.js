
const countdown = {
    name: 'countdown',
    props: {
        date: {
            type: String,
        },
       
        setID:{
            type:String
        }
        
    },

    mounted() {
        
 
      
            this.initializeClock(this.setID,this.date)
            calltwinmax(setID)
       
     
    
    
     },

    template: `

    
 
    
    <div class="deadline right-0 " :id="setID"> 
    <div class="arrow-left"></div>
    <h4 class="text-muted">Deadline in</h4>
 
    <div class="countdown py-3" :class="setID">
        <div class="bloc-time days d-time" :data-init-value="0">
            <span class="count-title">Days</span>
 
            <div class="figure days days-1">
                <span class="top">0</span>
                <span class="top-back">
                 <span>0</span>
                 </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                 <span></span>
                </span>
            </div>
 
            <div class="figure hours days-2">
                <span class="top">0</span>
                <span class="top-back">
                     <span>0</span>
                      </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                     <span>0</span>
                    </span>
            </div>
        </div>
        <div class="bloc-time hours h-time" :data-init-value="0">
            <span class="count-title">Hours</span>
 
            <div class="figure hours hours-1">
                <span class="top">0</span>
                <span class="top-back">
                 <span>0</span>
                 </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                 <span>0</span>
                </span>
            </div>
 
            <div class="figure hours hours-2">
                <span class="top">0</span>
                <span class="top-back">
                     <span>0</span>
                      </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                     <span>0</span>
                    </span>
            </div>
        </div>
 
        <div class="bloc-time min m-time" :data-init-value="0">
            <span class="count-title">Minutes</span>
 
            <div class="figure min min-1">
                <span class="top">0</span>
                <span class="top-back">
                    <span>0</span>
                </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                    <span>0</span>
                </span>
            </div>
 
            <div class="figure min min-2">
                <span class="top">0</span>
                <span class="top-back">
                     <span>0</span>
                </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                    <span>0</span>
                </span>
            </div>
        </div>
 
        <div class="bloc-time sec s-time" :data-init-value="0">
            <span class="count-title">Seconds</span>
 
            <div class="figure sec sec-1">
                <span class="top">0</span>
                <span class="top-back">
                  <span>0</span>
                </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                   <span>0</span>
                </span>
            </div>
 
            <div class="figure sec sec-2">
                <span class="top">0</span>
                <span class="top-back">
                  <span>0</span>
                </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                   <span>0</span>
                </span>
            </div>
        </div>
    </div>
 </div>
 
    
    
    
    `
}
//countdown

function getTimeRemaining(endtime) {

    var t = Date.parse(endtime) - Date.parse(new Date());
    var seconds = Math.floor((t / 1000) % 60);
    var minutes = Math.floor((t / 1000 / 60) % 60);
    var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
    //var hours = Math.floor(t / (1000 * 60 * 60));
    var days = Math.floor(t / (1000 * 60 * 60 * 24));
    return {
        'total': t,
        'days': days,
        'hours': hours,
        'minutes': minutes,
        'seconds': seconds
    };
}
initializeClock('assignment','2021/12/20')
function initializeClock(id,endtime) {
 
  console.log('called')
    function updateClock() {
        var t = getTimeRemaining(endtime);
        var sec=document.querySelector('.sec')
        var days=document.querySelector('.days')
        if (t.days>4){
      
        
        if(sec.style.display=='block'){
            sec.style.display='none'
        }
       
          
           if(days.style.display=='block'){
               days.style.display='none'
           }
           
        }else{
            t.hours+=t.days*24
            t.days=0
            
            if(days.style.display=='block'){
                days.style.display=='none'
            }
            if(sec.style.display=='none'){
                sec.style.display='block'
            }

        }
        var el=document.getElementById(id);
        el.querySelector('.d-time').setAttribute('data-init-value',t.days);
        el.querySelector('.h-time').setAttribute('data-init-value',t.hours);
        el.querySelector('.m-time').setAttribute('data-init-value',t.minutes);
        el.querySelector('.s-time').setAttribute('data-init-value',t.seconds);
    }
    updateClock();
}
//countdown end

function calltwinmax(classname){
var Countdown = {
    // Backbone-like structure
    el: document.querySelector(classname),
     
    // Params
    countdown_interval: null,
    total_seconds     : 0,

    // Initialize the countdown
    init: function() {

        // DOM
        this.timedom = {
            days  : el.querySelectorAll('.bloc-time.days .figure'),
            hours  : el.querySelectorAll('.bloc-time.hours .figure'),
            minutes: el.querySelectorAll('.bloc-time.min .figure'),
            seconds: el.querySelectorAll('.bloc-time.sec .figure')
        };

        // Init countdown values
        this.values = {
            days  : this.timedom.days[0].parentElement.getAttribute('data-init-value'),
            hours  : this.timedom.hours[0].parentElement.getAttribute('data-init-value'),
            minutes: this.timedom.minutes[0].parentElement.getAttribute('data-init-value'),
            seconds: this.timedom.seconds[0].parentElement.getAttribute('data-init-value'),
        };
        // Initialize total seconds
        this.total_seconds = this.values.hours * 60 * 60 + (this.values.minutes * 60) + this.values.seconds;

        // Animate countdown to the end
        this.count();
    },

    count: function() {

        var that    = this,
            days_1 = this.timedom.days[0],
            days_2 = this.timedom.days[1],
            hour_1 = this.timedom.hours[0],
            hour_2 = this.timedom.hours[1],
            min_1  = this.timedom.minutes[0],
            min_2  = this.timedom.minutes[1],
            sec_1  = this.timedom.seconds[0],
            sec_2  = this.timedom.seconds[1];

        this.countdown_interval = setInterval(function() {

            if(that.total_seconds > 0) {

                --that.values.seconds;

                if(that.values.minutes >= 0 && that.values.seconds < 0) {

                    that.values.seconds = 59;
                    --that.values.minutes;
                }

                if(that.values.hours >= 0 && that.values.minutes < 0) {

                    that.values.minutes = 59;
                    if (that.values.hours > 0)
                    {
                        --that.values.hours;
                    }
                }
                if(that.values.hours < 0 && that.values.days > 0 && that.values.minutes < 0 ) {
                    --that.values.days;
                 //    console.log("days reduced");
                }

                // Update DOM values
                that.checkHour(that.values.days, days_1, days_2);
                // Hours
                that.checkHour(that.values.hours, hour_1, hour_2);
                // Minutes
                that.checkHour(that.values.minutes, min_1, min_2);

                // Seconds
                that.checkHour(that.values.seconds, sec_1, sec_2);

                --that.total_seconds;
            }
            else {
                clearInterval(that.countdown_interval);
            }
        }, 1000);
    },

    animateFigure: function(el, value) {
            top         = el.querySelector('.top'),
            bottom      = el.querySelector('.bottom'),
            back_top    = el.querySelector('.top-back'),
            back_bottom = el.querySelector('.bottom-back');

        // Before we begin, change the back value
        back_top.querySelectorAll('span').innerHTML=value; 

        // Also change the back bottom value
        back_bottom.querySelectorAll('span').innerHTML=value;

        // Then animate
        TweenMax.to(top, 0.8, {
            rotationX           : '-180deg',
            transformPerspective: 300,
            ease                : Quart.easeOut,
            onComplete          : function() {

                top.html(value);

                bottom.html(value);

                TweenMax.set(top, { rotationX: 0 });
            }
        });

        TweenMax.to(back_top, 0.8, {
            rotationX           : 0,
            transformPerspective: 300,
            ease                : Quart.easeOut,
            clearProps          : 'all'
        });
    },

    checkHour: function(value, el_1, el_2) {

        var val_1       = value.toString().charAt(0),
            val_2       = value.toString().charAt(1),
            fig_1_value = el_1.querySelectorAll('.top').innerHTML,
            fig_2_value = el_2.querySelectorAll('.top').innerHTML;

        if(value >= 10) {

            // Animate only if the figure has changed
            if(fig_1_value !== val_1) this.animateFigure(el_1, val_1);
            if(fig_2_value !== val_2) this.animateFigure(el_2, val_2);
        }
        else {

            // If we are under 10, replace first figure with 0
            if(fig_1_value !== '0') this.animateFigure(el_1, 0);
            if(fig_2_value !== val_1) this.animateFigure(el_2, val_1);
        }
    }
};
Countdown.init()
}
// Let's go !


