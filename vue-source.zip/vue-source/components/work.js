const work = {
    name:'work',

    data() {
        return {
            workdata: [],

        }
    },
    methods: {
        
    },

 created() {
    axios.get(`/tutor/api/work/`).then((res) => {
            this.workdata =  res.data;
            console.log('workdata', res.data)
            console.log(this.workdata)

        }).catch((err) => {
            console.log('not find' + err)
        })


    },

    template: `


  
    <div id="availabledetails" class="responsive-pd-x" :class="workdata.atutor ? '' :'w-100'" >
    
    <mobileview :listdata="workdata"></mobileview>
    <!--    homework session-->
    <div class="responsive-pd bg-white rounded mb-4 web-view">
        <div class="table-title">
            <div class="d-flex">
                <i class="fas fa-book mr-2  text-green my-auto"></i><h4 class="my-auto">Homework assignment</h4>
            </div>
            <div class="position-relative search">
                <input type="text" id="assignmentInput" class="form-control badge-pill" placeholder="Search" >
                <i class="fas fa-search search-icon fa-sm"></i>
            </div>
        </div>
        <div>
              <countdown setclass="clock" :date="workdata.atutor" ></countdown>
              <table-data listtype="asslist" :listdata="workdata.atutor"></table-data>
        </div>
    </div>
       <!--live session-->
    <div class="responsive-pd bg-white rounded web-view">
        <div class="table-title">
            <div class="d-flex">
                <i class="fas fa-play-circle  mr-2 text-red my-auto"></i><h4 class="my-auto"> Live session</h4>
            </div>
            <div class="position-relative search">
                <input type="text" id="sessionInput" class="form-control badge-pill" placeholder="Search">
                <i class="fas fa-search search-icon fa-sm"></i>
            </div>
        </div>
        <div class="">
        <countdown setclass="clock1" :date="workdata.stutor"></countdown>
          <table-data listtype='sessionlist' :listdata="workdata.stutor"></table-data>
        </div>
    </div>
</div>

    `
}