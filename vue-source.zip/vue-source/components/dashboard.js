const dashboard = {
    name: 'dashboard',

    data() {
        return {
            data: [],
            minassgatut: [],
            windowwidth:''
        }
    },

    methods: {
        onerr(event) {
            if (event.target.src != `${this.$root.staticUrl}/media/branchicons/Misc.svg`) {
                event.target.src = `${this.$root.staticUrl}/media/branchicons/Misc.svg`;
            }
        },
        momentfilter(date, dtype) {
            return moment(date).format(dtype);
        }
        ,

        fileimg_click(data_id, type, assign_id) {
            this.data.data_id = data_id;
            this.data.embedsrc = "/tutor/viewfiles/" + type + "/" + assign_id + "/";
            this.data.embeddata = `<embed src=${this.data.embedsrc} data-id=${this.data.data_id}>`
            document.getElementById('fileviwer').classList.add('d-flex')
        }
        ,

        getInfo(tutID, type, assID, time) {

            axios
                .get(`/tutor/explore/${type}/${tutID}/`)
                .then((response) => {
                    console.log(response)
                    this.data = response.data;
                    this.data.tutID = tutID;
                    this.data.time = time;
                    this.data.type = type;
                    this.data.assID = assID

                    if (this.data.success == false) {
                        alert(
                            "This has been assigned to someone else and is no longer available"
                        );
                    } else {

                        toggleModal();

                    }
                })
                .catch((err) => {
                    console.log(err);
                });
        },


        modalAction(action_type, actionUpdate) {
            axios.get("/tutor/respond-to-session/" + this.data.type + "/" + this.data.tutID + "/?action=" + action_type)
                .then((res) => {
                    if (this.$root.userData.asslist.find(item => item.id == this.data.tutID)) {
                        this.$root.userData.asslist.find(item => item.id == this.data.tutID).action = actionUpdate;
                    } else {
                        this.$root.userData.bsslist.find(item => item.id == this.data.tutID).action = actionUpdate
                    }

                    toggleModal();
                })
                .catch((err) => {
                    console.log(err);
                });
        },


   
   
    },
     
     watch(){
       this.windowwidth=window.matchMedia('(max-width:600px)').matches
       console.log(this.windowwidth)
      }
     ,


    created() {
        this.minassgatut = this.$root.userData.minassgatut;
        
    },
    template: `


    <div class="modal-cover">
    <div v-if="data.type" class="assign-details p-4 shadow b-r-pill bg-white">
        <a class="modal-close" onclick="toggleModal()">&times;</a>
        <div class="header">
          <div class="my-auto">
              <h4 class="text-uppercase">{{data.subject}}</h4>
              <small>{{data.type=='a'? ('Assignment ID: '+ data.assID) : ('Session ID : '+data.assID)}}</small><br>
              <small v-if="data.type!='a' ">Duration : {{data.duration}} min</small>
          </div>
         
            <div class="d-flex gap-12 calendar-container">
                <div  class="calendar shadow-sm">
                    <p  class="px-2 mb-0 monthName" >{{data.type=='a'?'Dealine':'Starts in'}}</p>


                    <p  class="px-2 dayNumber time">{{this.$root.momentfilter(data.time,'HH:MM')}}</p>
                    <p  class="px-2 year mb-1" id="clock">{{this.$root.momentfilter(data.time,'A')}}</p>

                </div>
                <div class="calendar shadow-sm">
                    <p  class="px-2 mb-0 monthName">{{this.$root.momentfilter(data.time,'MMM')}}</p>
                    <p  class="px-2 mb-0 dayName">{{this.$root.momentfilter(data.time,'dddd')}}</p>
                    <p  class="px-2 dayNumber" >{{this.$root.momentfilter(data.time,'D')}}</p>
                </div>
            </div>
        </div>
        <div class="body mt-2">
            <div class="row">
                <div v-if="data.type=='a' " class="col-md-6">
                    <p  class=" p-1 bg-light shadow-sm fs-small" ><i class="fas fa-question-circle mr-1 text-muted"></i>Question</p>
                    <div id="question">
                       <template v-if="data.questions.length">
                           <template v-for="q in data.questions">
                            <div  @click="fileimg_click(q,'q',data.assID)"  class="file-img" ><img :src="this.$root.staticUrl +'/tutor/images/icons8-idea-tutor.svg'" alt=""></div>
                           </template>
                       </template>
                       
                        <p v-else class="w-100 text-center fs-small">No files attached</p>
                    </div>  
                    
                </div>
                <div :class="data.type=='a' ? 'col-md-6 mt-2 mt-md-0 mt-lg-0' : 'col-12 '" >
                    <p class="p-1 bg-light shadow-sm fs-small"><i class="fas fa-layer-group mr-1 text-muted"></i> Reference</p>
                   <div id="ref">
                       <template v-if="data.references.length">
                         <template v-for="r in data.references">
                            <div  @click="fileimg_click(r,'rs',data.assID)"  class="file-img" ><img :src="this.$root.staticUrl+'/tutor/images/icons8-idea-tutor.svg'" alt=""></div>
                         </template>
                       </template>
                       
                        <p v-else class="w-100 text-center fs-small">No files attached</p>
                     
                   </div>
                </div>
            </div>
            <div class="mt-2 text-muted">
                <p v-if="data.note" class="fs-small mb-2">
                   <span class="font-weight-600">NOTE:</span> <span>{{data.note}}</span>
                </p>
            </div>
            <div class="text-muted">
                <p class=" mb-0 fs-small">
                    If you want to ask anything regarding this <span id="type">assignment</span>, close the popup and click on the chat button.
                </p>
                <table class="fs-small mt-1">
                   
                    <tr>
                        <td class="d-flex">
                            <i class="fas fa-phone fa-sm mr-2 my-auto"></i>Phone <span class="float-right">:</span>
                        </td>
                        <td>
                            <a :href="'tel:'+data.phone" class="ml-2" id="phone">{{data.phone}}</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="footer mt-4">
               
                <button class="btn btn-outline-danger shadow-sm mr-1"   :disabled="data.interest_status == 3  ? true : false "  @click="modalAction('reject','r')">{{data.interest_status ==3 ? 'Already Rejected &times;' :'Reject &times;' }}</button>
                <button class="btn btn-outline-success shadow-sm ml-1"  :disabled="data.interest_status > 3  ? true : false "  @click="modalAction('accept','a')">{{data.interest_status > 3 ? 'Already Interested &#10003;' : 'Interested &#10003;'  }}</button>
            
        </div>
 
    </div>

    
 </div>
 
  <div class="file-viewer-modal" v-html="data.embeddata" id="fileviwer">
  </div>
  
  <!--availeble details-->
  <div id="availabledetails" class="responsive-pd-x">
  <mobileview v-if="windowwidth" :listdata="this.$root.userData"></mobileview>
    
    <div class=" mb-4 web-view">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">Assignments</a>
            </li>
            <li class="nav-item">
                <a class="nav-link d-badge " :data-badge="this.$root.userData.bsslist.length" data-toggle="tab" href="#tabs-2" role="tab">Sessions</a>
            </li>
        </ul><!-- Tab panes -->
    </div>
  
    <div class="tab-content web-view">
        <div class="tab-pane active" id="tabs-1" role="tabpanel">
            <!--    homework session-->
            <div class="responsive-pd bg-white rounded">
                <div class="table-title">
                    <div class="d-flex">
                        <i class="fas fa-book mr-2  text-green my-auto"></i><h4 class="my-auto">Homework assignment</h4>
                    </div>
                    <div class="position-relative search">
                        <input type="text"  id="assignmentInput"  class="form-control badge-pill" placeholder="Search">
                        <i class="fas fa-search search-icon fa-sm"></i>
                    </div>
                </div>
    
    
                <div class="">
                   <!--table component-->
                   <table-data    listtype='asslist' :listdata="this.$root.userData.asslist"></table-data>
                </div>
            </div>
            <button type="button" class="d-none" data-toggle="modal" data-target="#displayMessage" id="popmsg"></button>
        </div>
        <div class="tab-pane" id="tabs-2" role="tabpanel">
            <!--    live session-->
            <div class="responsive-pd bg-white rounded">
                <div class="table-title">
                    <div class="d-flex">
                        <i class="fas fa-play-circle  mr-2 text-red my-auto"></i><h4 class="my-auto"> Live session</h4>
                    </div>
                    <div class="position-relative search">
                        <input type="text" id="sessionInput" class="form-control badge-pill" placeholder="Search" >
                        <i class="fas fa-search search-icon fa-sm"></i>
                    </div>
                </div>
                <div class="">
                   <table-data listtype="bsslist" :listdata="this.$root.userData.bsslist"></table-data>
                </div>
            </div>
        </div>
    </div>
  
  
  
  </div>
  <!-- Modal -->
  <div class="modal fade" id="displayMessage" tabindex="-1" role="dialog" aria-labelledby="modalTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Message</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                This assignment is already assigned to another tutor
            </div>
        </div>
    </div>
  </div>


  <div id="extradetails"  class="r-menu">
  <nextassign v-if="this.$root.userData.assgdeadline" type="assign" :listdata="this.$root.userData.minassgatut"></nextassign>
  <nextassign v-if="this.$root.userData.minstarttime" type="session" :listdata="this.$root.userData.minsessionstut"></nextassign>

  <recent-notifications></recent-notifications>
  </div>

  

    `
}



//this.$root.$refs.chatvue.changeselected