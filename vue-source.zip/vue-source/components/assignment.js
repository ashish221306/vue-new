const assignment={
    data(){
        return{

        }
    },


    template:`
    
    
    
    
    
    
    `
}