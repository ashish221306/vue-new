const nextassign={
    name:'nextassign',
    props:{
        listdata:{
            type:Object
        },
        type:{
            type:String
        }
    },
    template:`
    
    <div class="details-card-group" :class="type=='assign'? 'mb-lg-3' : '' ">
        <div class="d-flex mb-2">
            <i  class="fas  mx-1 text-green my-auto" :class="type=='assign' ? 'fa-book text-green' :'fa-play-circle text-red' "></i>   <h5 class=" p-1 my-auto">{{type=='assign' ? 'Next assignments' : ' Next sessions '}}</h5>
        </div>
        <div class="details-card-deck bg-white border-top-left-r-lg shadow-sm">
            <div class="details-card ">
            
               <template v-if="type=='assign'">
               <img :src="this.$root.staticUrl+'/media/branchicons'+ listdata.assignment.branch + '.svg' " alt="subject-logo" @error="this.$root.onerr">
               <div class="d-card-body">
                   <p class="text-capitalize">{{listdata.assignment.subject}}</p>
                   <small class="text-muted"><i class="fas fa-clock mr-1"></i>{{ this.$root.momentfilter(listdata.assignment.deadline,'LL')}} {{ this.$root.momentfilter(listdata.assignment.deadline,'LT')}}</small>
               </div>
               </template>
               <template v-else>
               <img :src="this.$root.staticUrl+'/media/branchicons/'+listdata.branch+'.svg'" alt="subject-logo" @error=" this.$root.onerr">
            <div class="d-card-body">
                <p class="text-capitalize">{{listdata.subject}}</p>
                <small class="text-muted"><i class="fas fa-clock mr-1"></i>{{ this.$root.momentfilter(listdata.start_time,"LL")}} to  {{ this.$root.momentfilter(listdata.end_time,'LL') }}</small>
            </div>
               </template>
                <a :href="'/tutor/'+  type=='assign' ? 'assignment/' :'session/' +listdata.id" target="_blank" class="arrow-right"> <i class="fa fa-arrow-right my-auto flex-fill text-end" aria-hidden="true"></i></a>
            </div>
            <div class="shadow">
            <countdown :date="'2021/04/07'" type="nextcountdown"></countdown>
                
            </div>
        </div>
    </div>
    
    `
}