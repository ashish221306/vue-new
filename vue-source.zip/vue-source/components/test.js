const test={
    name:'test',
    created(){
   
    },
    
    template:`
    
   
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="utf-8" />
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />
       
        <!-- End Facebook Pixel Code -->
    
        <meta name="description" content="Welcome to Tutorbin" />
    
        <title>Welcome | TutorBin Tutor</title>
        <style>
          :root{--blue:#007bff;--indigo:#6610f2;--purple:#6f42c1;--pink:#e83e8c;--red:#dc3545;--orange:#fd7e14;--yellow:#ffc107;--green:#28a745;--teal:#20c997;--cyan:#17a2b8;--white:#fff;--gray:#6c757d;--gray-dark:#343a40;--primary:#007bff;--secondary:#6c757d;--success:#28a745;--info:#17a2b8;--warning:#ffc107;--danger:#dc3545;--light:#f8f9fa;--dark:#343a40;--breakpoint-xs:0;--breakpoint-sm:576px;--breakpoint-md:768px;--breakpoint-lg:992px;--breakpoint-xl:1200px;--font-family-sans-serif:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";--font-family-monospace:SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace}*,::after,::before{box-sizing:border-box}html{font-family:sans-serif;line-height:1.15;-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:transparent}section{display:block}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";font-size:1rem;font-weight:400;line-height:1.5;color:#212529;text-align:left;background-color:#fff}[tabindex="-1"]:focus:not(:focus-visible){outline:0!important}h3{margin-top:0;margin-bottom:.5rem}p{margin-top:0;margin-bottom:1rem}img{vertical-align:middle;border-style:none}button{border-radius:0}button:focus{outline:1px dotted;outline:5px auto -webkit-focus-ring-color}button{margin:0;font-family:inherit;font-size:inherit;line-height:inherit}button{overflow:visible}button{text-transform:none}button{-webkit-appearance:button}[type=button]:not(:disabled),[type=reset]:not(:disabled),[type=submit]:not(:disabled),button:not(:disabled){cursor:pointer}button::-moz-focus-inner{padding:0;border-style:none}::-webkit-file-upload-button{font:inherit;-webkit-appearance:button}h3{margin-bottom:.5rem;font-weight:500;line-height:1.2}h3{font-size:1.75rem}.custom-control-input.is-valid:focus:not(:checked)~.custom-control-label::before,.was-validated .custom-control-input:valid:focus:not(:checked)~.custom-control-label::before{border-color:#28a745}.custom-control-input.is-invalid:focus:not(:checked)~.custom-control-label::before,.was-validated .custom-control-input:invalid:focus:not(:checked)~.custom-control-label::before{border-color:#dc3545}.btn{display:inline-block;font-weight:400;color:#212529;text-align:center;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:transparent;border:1px solid transparent;padding:.375rem .75rem;font-size:1rem;line-height:1.5;border-radius:.25rem;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out}@media (prefers-reduced-motion:reduce){.btn{transition:none}}.btn:hover{color:#212529;text-decoration:none}.btn:focus{outline:0;box-shadow:0 0 0 .2rem rgba(0,123,255,.25)}.btn:disabled{opacity:.65}.btn:not(:disabled):not(.disabled){cursor:pointer}.btn-primary:not(:disabled):not(.disabled).active,.btn-primary:not(:disabled):not(.disabled):active{color:#fff;background-color:#0062cc;border-color:#005cbf}.btn-primary:not(:disabled):not(.disabled).active:focus,.btn-primary:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(38,143,255,.5)}.btn-secondary:not(:disabled):not(.disabled).active,.btn-secondary:not(:disabled):not(.disabled):active{color:#fff;background-color:#545b62;border-color:#4e555b}.btn-secondary:not(:disabled):not(.disabled).active:focus,.btn-secondary:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(130,138,145,.5)}.btn-success:not(:disabled):not(.disabled).active,.btn-success:not(:disabled):not(.disabled):active{color:#fff;background-color:#1e7e34;border-color:#1c7430}.btn-success:not(:disabled):not(.disabled).active:focus,.btn-success:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(72,180,97,.5)}.btn-info:not(:disabled):not(.disabled).active,.btn-info:not(:disabled):not(.disabled):active{color:#fff;background-color:#117a8b;border-color:#10707f}.btn-info:not(:disabled):not(.disabled).active:focus,.btn-info:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(58,176,195,.5)}.btn-warning:not(:disabled):not(.disabled).active,.btn-warning:not(:disabled):not(.disabled):active{color:#212529;background-color:#d39e00;border-color:#c69500}.btn-warning:not(:disabled):not(.disabled).active:focus,.btn-warning:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(222,170,12,.5)}.btn-danger:not(:disabled):not(.disabled).active,.btn-danger:not(:disabled):not(.disabled):active{color:#fff;background-color:#bd2130;border-color:#b21f2d}.btn-danger:not(:disabled):not(.disabled).active:focus,.btn-danger:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(225,83,97,.5)}.btn-light:not(:disabled):not(.disabled).active,.btn-light:not(:disabled):not(.disabled):active{color:#212529;background-color:#dae0e5;border-color:#d3d9df}.btn-light:not(:disabled):not(.disabled).active:focus,.btn-light:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(216,217,219,.5)}.btn-dark:not(:disabled):not(.disabled).active,.btn-dark:not(:disabled):not(.disabled):active{color:#fff;background-color:#1d2124;border-color:#171a1d}.btn-dark:not(:disabled):not(.disabled).active:focus,.btn-dark:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(82,88,93,.5)}.btn-outline-primary:not(:disabled):not(.disabled).active,.btn-outline-primary:not(:disabled):not(.disabled):active{color:#fff;background-color:#007bff;border-color:#007bff}.btn-outline-primary:not(:disabled):not(.disabled).active:focus,.btn-outline-primary:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(0,123,255,.5)}.btn-outline-secondary:not(:disabled):not(.disabled).active,.btn-outline-secondary:not(:disabled):not(.disabled):active{color:#fff;background-color:#6c757d;border-color:#6c757d}.btn-outline-secondary:not(:disabled):not(.disabled).active:focus,.btn-outline-secondary:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(108,117,125,.5)}.btn-outline-success:not(:disabled):not(.disabled).active,.btn-outline-success:not(:disabled):not(.disabled):active{color:#fff;background-color:#28a745;border-color:#28a745}.btn-outline-success:not(:disabled):not(.disabled).active:focus,.btn-outline-success:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(40,167,69,.5)}.btn-outline-info:not(:disabled):not(.disabled).active,.btn-outline-info:not(:disabled):not(.disabled):active{color:#fff;background-color:#17a2b8;border-color:#17a2b8}.btn-outline-info:not(:disabled):not(.disabled).active:focus,.btn-outline-info:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(23,162,184,.5)}.btn-outline-warning:not(:disabled):not(.disabled).active,.btn-outline-warning:not(:disabled):not(.disabled):active{color:#212529;background-color:#ffc107;border-color:#ffc107}.btn-outline-warning:not(:disabled):not(.disabled).active:focus,.btn-outline-warning:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(255,193,7,.5)}.btn-outline-danger:not(:disabled):not(.disabled).active,.btn-outline-danger:not(:disabled):not(.disabled):active{color:#fff;background-color:#dc3545;border-color:#dc3545}.btn-outline-danger:not(:disabled):not(.disabled).active:focus,.btn-outline-danger:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(220,53,69,.5)}.btn-outline-light:not(:disabled):not(.disabled).active,.btn-outline-light:not(:disabled):not(.disabled):active{color:#212529;background-color:#f8f9fa;border-color:#f8f9fa}.btn-outline-light:not(:disabled):not(.disabled).active:focus,.btn-outline-light:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(248,249,250,.5)}.btn-outline-dark:not(:disabled):not(.disabled).active,.btn-outline-dark:not(:disabled):not(.disabled):active{color:#fff;background-color:#343a40;border-color:#343a40}.btn-outline-dark:not(:disabled):not(.disabled).active:focus,.btn-outline-dark:not(:disabled):not(.disabled):active:focus{box-shadow:0 0 0 .2rem rgba(52,58,64,.5)}.btn-block{display:block;width:100%}.custom-control-input:focus:not(:checked)~.custom-control-label::before{border-color:#80bdff}.custom-control-input:not(:disabled):active~.custom-control-label::before{color:#fff;background-color:#b3d7ff;border-color:#b3d7ff}.close:not(:disabled):not(.disabled):focus,.close:not(:disabled):not(.disabled):hover{opacity:.75}.border-0{border:0!important}.position-relative{position:relative!important}.position-absolute{position:absolute!important}@supports ((position:-webkit-sticky) or (position:sticky)){}.shadow-sm{box-shadow:0 .125rem .25rem rgba(0,0,0,.075)!important}.shadow{box-shadow:0 .5rem 1rem rgba(0,0,0,.15)!important}.mr-2{margin-right:.5rem!important}.mb-4{margin-bottom:1.5rem!important}.m-auto{margin:auto!important}.ml-auto{margin-left:auto!important}.text-center{text-align:center!important}.text-muted{color:#6c757d!important}@media print{*,::after,::before{text-shadow:none!important;box-shadow:none!important}img{page-break-inside:avoid}h3,p{orphans:3;widows:3}h3{page-break-after:avoid}@page{size:a3}body{min-width:992px!important}}
    
          .fab,.fas{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;display:inline-block;font-style:normal;font-variant:normal;text-rendering:auto;line-height:1}.fa-lg{font-size:1.33333em;line-height:.75em;vertical-align:-.0667em}.fa-arrow-left:before{content:"\f060"}.fa-home:before{content:"\f015"}.fa-paper-plane:before{content:"\f1d8"}.fa-pen:before{content:"\f304"}.fa-power-off:before{content:"\f011"}.fa-whatsapp:before{content:"\f232"}@font-face{font-family:"Font Awesome 5 Brands";font-style:normal;font-weight:normal;src:url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/fonts/fontawesome-webfont.eot);src:url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/fonts/fontawesome-webfont.eot) format("embedded-opentype"),url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/fonts/fontawesome-webfont.woff2) format("woff2"),url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/fonts/fontawesome-webfont.woff) format("woff"),url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/fonts/fontawesome-webfont.ttf) format("truetype"),url(https://static.tutorbin.com/static/webfonts/fa-brands-400.svg#fontawesome) format("svg")}@font-face{font-family:"Font Awesome 5 Free";font-style:normal;font-weight:400;src:url(https://static.tutorbin.com/static/webfonts/fa-regular-400.eot);src:url(https://static.tutorbin.com/static/webfonts/fa-regular-400.eot?#iefix) format("embedded-opentype"),url(https://static.tutorbin.com/static/webfonts/fa-regular-400.woff2) format("woff2"),url(https://static.tutorbin.com/static/webfonts/fa-regular-400.woff) format("woff"),url(https://static.tutorbin.com/static/webfonts/fa-regular-400.ttf) format("truetype"),url(https://static.tutorbin.com/static/webfonts/fa-regular-400.svg#fontawesome) format("svg")}@font-face{font-family:"Font Awesome 5 Free";  font-display: swap;font-style:normal;font-weight:900;src:url(https://static.tutorbin.com/static/webfonts/fa-solid-900.eot);src:url(https://static.tutorbin.com/static/webfonts/fa-solid-900.eot?#iefix) format("embedded-opentype"),url(https://static.tutorbin.com/static/webfonts/fa-solid-900.woff2) format("woff2"),url(https://static.tutorbin.com/static/webfonts/fa-solid-900.woff) format("woff"),url(https://static.tutorbin.com/static/webfonts/fa-solid-900.ttf) format("truetype"),url(https://static.tutorbin.com/static/webfonts/fa-solid-900.svg#fontawesome) format("svg")}.fas{font-family:"Font Awesome 5 Free"}.fas{font-weight:900}
    
          html, body {
            font-family: "Roboto", sans-serif;
          }
    
          .login-form {
            font-size: 14px;
            background: #fff;
            border-radius: 7px;
            padding: clamp(1em, 2vw, 2em);
          }
    
          .btn-gra {
            color: white;
            background: linear-gradient(to right, #00c6ff, #0072ff);
            transition: 0.3s ease-in-out;
          }
          .btn-gra:hover {
            transform: scale(0.98);
            color: white;
            box-shadow: 1px 9px 20px rgb(0 0 0 / 8%), 0 6px 6px rgb(0 0 0 / 7%);
          }
    
          .desc {
            font-size: 14px;
            letter-spacing: 1px;
          }
    
          .welcome {
            flex-direction: column;
          }
    
          .login-container {
            min-height: 100vh;
            width: 100%;
            display: flex;
            align-items: center;
    
          }
          .login-container .profile-circle {
            border-radius: 50%;
            margin-bottom: 2em;
            object-fit: cover;
            width: 140px;
            position: relative;
          }
          .login-container .cta {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2em;
            background-color: #f0f4fd;
          }
          .cta a{
            width: 100%;
            text-decoration: none;
          }
          .login-container .cta button {
            font-size: 1em !important;
          }
          .login-container .buttons {
            margin-top: 1em;
            margin-right: clamp(0px,1vw,1em);
          }
          .login-container .buttons button {
            font-size: 14px;
            background-color: #f7f9fd;
            border: none !important;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075) !important;
            margin: 4px;
          }
    
          .form-signin {
            width: 100%;
            min-width: min-content;
            max-width: 420px;
            padding: 0 15px;
            margin: auto;
          }
          .form-signin .btn-block {
            display: block;
            width: 50%;
            margin: 0 auto;
            font-size: 14px;
            font-weight: 600;
          }
    
          .form-label-group input:not(:-moz-placeholder-shown) {
            padding-top: 1.25rem;
            padding-bottom: 0.25rem;
          }
    
          .form-label-group input:not(:-ms-input-placeholder) {
            padding-top: 1.25rem;
            padding-bottom: 0.25rem;
          }
    
          .form-label-group input:not(:-moz-placeholder-shown) ~ label {
            padding-top: 0.25rem;
            padding-bottom: 0.25rem;
            font-size: 10px;
            color: #3e4e5fcc;
          }
    
          .form-label-group input:not(:-ms-input-placeholder) ~ label {
            padding-top: 0.25rem;
            padding-bottom: 0.25rem;
            font-size: 10px;
            color: #3e4e5fcc;
          }
    
          /* Fallback for Edge
          -------------------------------------------------- */
          @supports (-ms-ime-align: auto) {
          }
    
          ::-webkit-scrollbar-thumb {
            border-radius: 54px;
            background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0.44, #2687ff), color-stop(0.72, #2687ff), color-stop(0.86, #2687ff));
          }
    
          ::-webkit-scrollbar-track {
            -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
            background-color: #F5F5F5;
            border-radius: 39px;
          }
    
          ::-webkit-scrollbar {
            width: 4px;
            background-color: #F5F5F5;
          }
    
          .text-custom-secondary {
            color: #2687ff;
          }
    
          .svg-pattern {
            background-color: #ffffff;
            background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23838383' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
          }
    
          tag {
            display: block;
            padding: 8px 14px;
            position: absolute;
            right: -14px;
            top: 20px;
            background-color: darkblue;
            color: dodgerblue;
            border-top-right-radius: 7px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
            transition: opacity 0.2s ease-in;
          }
          tag:hover {
            opacity: 0.8;
          }
          tag::after {
            display: block;
            content: "";
            height: 14px;
            width: 14px;
            position: absolute;
            background-color: dodgerblue;
            right: 0;
            bottom: -14px;
            border-bottom-right-radius: 14px;
          }
    
          .whatsapp {
            background-color: #3bbf26 !important;
            color: #ffffff !important;
          }
          .whatsapp::after {
            background-color: #3bbf2691 !important;
          }
    
          .mail {
            background-color: #007bff !important;
            color: #ffffff !important;
            top: 77px !important;
          }
          .whatsapp-svg{
            width:15px;
          }
          .top-btn{
            transition: all .2s ease;
          }
          .top-btn:hover{
            opacity: 0.8;
          }
          @media screen and (max-width: 550px) {
            .login-form {
              box-shadow: none !important;
              background: transparent;
            }
            tag{
              right: 0;
            }
            .login-container {
              min-height: 90vh;
              background: white !important;
            }
          }
        </style>
      </head>
    
      <body>
        <div class="login-container text-muted welcome">
          <div class="buttons ml-auto">
          
            <a v-if="tutorprofile.tested"   href="tutor/dashboard/"><button class="btn text-muted top-btn"><i class="fas fa-home mr-2 text-custom-secondary"></i>Dashboard</button></a>
         
            <a v-if="!subm && !ta && !re"  href="/tutor/update_subjects/"><button class="btn text-muted top-btn"><i class="fas fa-pen mr-2 text-custom-secondary"></i>Update Subject</button></a>
        
            <a v-else href="tutor/logout_user"><button class="btn text-muted"><i class="fas fa-power-off mr-2 text-custom-secondary"></i>Logout</button></a>
          </div>
    
          <div class="login-form m-auto  shadow-sm position-relative">
            <a target="_blank"  href="https://wa.me/917082686818">
              <tag class="whatsapp"><img src="static/tutor/images/whatsapp-brands.svg" alt="whatsapp" class="whatsapp-svg"></tag>
            </a>
            <a href="mailto:tutors@tutorbin.com"> <tag class="mail"><i class="fas fa-paper-plane"></i></tag></a>
            <div class="go-back position-absolute">
              <a href="tutor/dashboard"><i class="fas fa-arrow-left"></i></a>
            </div>
           
    <!--        test going for review-->
            <section v-if="subm" class="form-signin">
              <div class="text-center mb-4">
    
                <img src="{%static 'tutor/images/Web.png'%}" alt="profile image" class="profile-circle shadow-sm">
                <pattern class="svg-pattern">
    
                </pattern>
                <h3>Hello, {{tutorprofile.name}}</h3>
                <p class="desc"> Hope you did well with your test. It's being reviewed by our
                  experts. Once the review is complete, you will get the result by an
                  email. It may take 2-3 days.</p>
              </div>
            </section>
           
    <!--        Start test-->
            <section v-else-if="ta" class="form-signin">
              <div class="text-center mb-4">
                <img src="{%static 'tutor/images/Web.png'%}" alt="profile image" class="profile-circle shadow-sm">
                <pattern class="svg-pattern">
    
                </pattern>
                <h3>Hello, {{tutorprofile.name}}</h3>
                <p class="desc">click on Start Test button when ready. Once you click it, you will have to solve and submit solutions within next 12 hours. Good Luck</p>
              </div>
              <div class="cta">
                <a href="{%url 'tutor:accepttest'%}"><button class="btn btn-gra btn-block border-0">Start Test</button></a>
              </div>
            </section>
         
    <!--        failed-->
            <section v-else-if="tre" class="form-signin">
              <div class="text-center mb-4">
                <img src="{%static 'tutor/images/Web.png'%}" alt="profile image" class="profile-circle shadow-sm">
                <pattern class="svg-pattern">
    
                </pattern>
                <h3>Hello, {{tutorprofile.name}}</h3>
                <p class="desc">You failed the test. If you want to
                  appear for the test again, click on <b>Request Retest</b> button
                  when you are ready.</p>
              </div>
              <div class="cta">
                <a   href="{%url 'tutor:requesttest'%}"> <button class="btn btn-gra btn-block border-0">Request Retest</button></a>
              </div>
            </section>
            
    <!--        assign test question later-->
            <section v-else-if="tar" class="form-signin">
              <div class="text-center mb-4">
                <img src="{%static 'tutor/images/Web.png'%}" alt="profile image" class="profile-circle shadow-sm">
                <pattern class="svg-pattern">
    
                </pattern>
                <h3>Hello, {{tutorprofile.name}}</h3>
                <p class="desc">We will assign you test questions in a few days. You will be
                  notified on mail when the questions are assigned. Then visit the
                  site again to start the test. For any query, contact on the number
                  below</p>
              </div>
            </section>
          
    <!--        start test-->
            <section v-else-if="as" class="form-signin">
              <div class="text-center mb-4">
                <img src="{%static 'tutor/images/Web.png'%}" alt="profile image" class="profile-circle shadow-sm">
                <pattern class="svg-pattern">
    
                </pattern>
                <h3>Hello, {{tutorprofile.name}}</h3>
                <p class="desc"> click on <b>Start Test</b> button when
                  ready. Once you click it, you will have to solve and submit
                  solutions within <b>next 12 hours</b>. Good Luck.</p>
              </div>
              <div class="cta">
                <a    href="tutor/accepttest/"> <button class="btn btn-gra btn-block border-0">Start Test</button></a>
              </div>
            </section>
          
    <!--        request for retest-->
            <section v-else-if="re" class="form-signin">
              <div class="text-center mb-4">
                <img src="{%static 'tutor/images/Web.png'%}" alt="profile image" class="profile-circle shadow-sm">
                <pattern class="svg-pattern">
    
                </pattern>
                <h3>Hello, {{tutorprofile.name}}</h3>
                <p class="desc"> you failed the test. If you want to
                  appear for the test again, click on <b>Request Retest</b> button
                  when you are ready.</p>
              </div>
              <div class="cta">
                <a  href="{%url 'tutor:requesttest'%}"> <button class="btn btn-gra btn-block border-0">Request Retest</button></a>
              </div>
            </section>
         
    <!--        test submit and going for review-->
            <section v-else-if="su" class="form-signin">
              <div class="text-center mb-4">
                <img src="{%static 'tutor/images/Web.png'%}" alt="profile image" class="profile-circle shadow-sm">
                <pattern class="svg-pattern">
    
                </pattern>
                <h3>Hello, {{tutorprofile.name}}</h3>
                <p class="desc">Hope you did well with your test. It's being reviewed by our
                  experts. Once the review is complete, you will get the result by an
                  email. It may take 2-3 days.</p>
              </div>
            </section>
          
            <section v-else class="form-signin">
              <div class="text-center mb-4">
                <img src="{%static 'tutor/images/Web.png'%}" alt="profile image" class="profile-circle shadow-sm">
                <pattern class="svg-pattern">
    
                </pattern>
                <h3>Hello, {{tutorprofile.name}}</h3>
                <p class="desc">Last step before you can start encashing on your knowledge. Apply
                  for the test and we will assign you some questions related to your
                  selected subjects to check your expertise in the subjects. Click on
                  the button below to apply for the test.</p>
              </div>
              <div class="cta">
                <a  href="tutor/requesttest"> <button class="btn btn-gra btn-block border-0">Apply</button></a>
              </div>
            </section>
           
    <!--        review code before push-->
          <!--{% if tutorprofile.tested %}
            <section class="form-signin">
              <div class="cta">
                <a  href="{%url 'tutor:dashboard'%}"> <button class="btn btn-gra btn-block border-0">Go to Dashboard</button></a>
              </div>
            </section>
            {%endif%}-->
          </div>
        </div>
      </body>
    </html>
    
    
    `
}