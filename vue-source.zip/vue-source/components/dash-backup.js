const countdown = {
    name: 'countdown',

    mounted() {
        window.setInterval(() => {
            this.now = Math.trunc((new Date()).getTime() / 1000);
        }, 1000);
    },
    props: {
        date: {
            type: String
        },
        type:{
            type:String
        }
    },
    data() {
        return {
           
            now: Math.trunc((new Date()).getTime() / 1000)
        }
    },

    filter: {
        two_digits: function (value) {

            if (value < 0) {
                return '00';
            }
            if (value.toString().length <= 1) {
                return `0${value}`;
            }
            return value;


        }

    },


    computed: {
        dateInMilliseconds() {
            return Math.trunc(Date.parse(this.date) / 1000)
        },
        seconds() {
            return (this.dateInMilliseconds - this.now) % 60;
        },
        minutes() {
            return Math.trunc((this.dateInMilliseconds - this.now) / 60) % 60;
        },
        hours() {
            return Math.trunc((this.dateInMilliseconds - this.now) / 60 / 60) % 24;
        },
        days() {
            return Math.trunc((this.dateInMilliseconds - this.now) / 60 / 60 / 24);
        }
    }
    ,
    methods: {
        two_digits(value) {

            if (value < 0) {
                return '00';
            }
            if (value.toString().length <= 1) {
                return `0${value}`;
            }
            return value;


        },

       
    }

 ,





    
    template: `
    <ul v-if="this.$route.name=='dashboard' && type=='nextcountdown' " class="p-0 text-center">
                <li><span class="days">{{ two_digits(days) }}</span>days</li>
                <li><span class="hours">{{two_digits(hours)}}</span>Hours</li>
                <li><span class="minutes">{{two_digits(minutes) }}</span>Minutes</li>
                <li><span class="seconds">{{two_digits(seconds)}}</span>Seconds</li>
    </ul>
    
    <template v-if="this.$route.name=='work' " >
    
    <div class="deadline right-0 " id="assignment"> 
    <div class="arrow-left"></div>
    <h4 class="text-muted">Deadline in</h4>
 
    <div class="countdown py-3">
        <div class="bloc-time days d-time">
            <span class="count-title">Days</span>
 
            <div class="figure days days-1">
                <span class="top">0</span>
                <span class="top-back">
                 <span>0</span>
                 </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                 <span>0</span>
                </span>
            </div>
 
            <div class="figure hours days-2">
                <span class="top">0</span>
                <span class="top-back">
                     <span>0</span>
                      </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                     <span>0</span>
                    </span>
            </div>
        </div>
        <div class="bloc-time hours h-time" data-init-value="0">
            <span class="count-title">Hours</span>
 
            <div class="figure hours hours-1">
                <span class="top">0</span>
                <span class="top-back">
                 <span>0</span>
                 </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                 <span>0</span>
                </span>
            </div>
 
            <div class="figure hours hours-2">
                <span class="top">0</span>
                <span class="top-back">
                     <span>0</span>
                      </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                     <span>0</span>
                    </span>
            </div>
        </div>
 
        <div class="bloc-time min m-time" data-init-value="0">
            <span class="count-title">Minutes</span>
 
            <div class="figure min min-1">
                <span class="top">0</span>
                <span class="top-back">
                    <span>0</span>
                </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                    <span>0</span>
                </span>
            </div>
 
            <div class="figure min min-2">
                <span class="top">0</span>
                <span class="top-back">
                     <span>0</span>
                </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                    <span>0</span>
                </span>
            </div>
        </div>
 
        <div class="bloc-time sec s-time" data-init-value="0">
            <span class="count-title">Seconds</span>
 
            <div class="figure sec sec-1">
                <span class="top">0</span>
                <span class="top-back">
                  <span>0</span>
                </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                   <span>0</span>
                </span>
            </div>
 
            <div class="figure sec sec-2">
                <span class="top">0</span>
                <span class="top-back">
                  <span>0</span>
                </span>
                <span class="bottom">0</span>
                <span class="bottom-back">
                   <span>0</span>
                </span>
            </div>
        </div>
    </div>
 </div>
    </template>
    
    
    
    `
}