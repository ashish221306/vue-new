
const app1=Vue.createApp({
  delimiters: ['[[', ']]'],
  data(){
    return{
      message:'Vue3',
      userData:[],
      staticUrl:'/static'
    }
  }
,
methods:{
  momentfilter(date, dtype) {
    return moment(date).format(dtype);
},
onerr(event) {
  if (event.target.src != "/static/media/branchicons/Misc.svg") {
      event.target.src = "/static/media/branchicons/Misc.svg";
  }
},

},
created(){
  this.userData = tutordata;
  console.log('userdata')
  console.log(this.userData);
  
 
}
});


const routes=[
{path:'/',name:'dashboard',component:dashboard},
{path:'/your-work',name:'work',component:work},
{path:'/history',name:'history',component:history},
{path:'/profile',name:'profile',component:profile},
{path:'/payment',name:'payment',component:payment},
{path:'/instruction',name:'instruction',component:instruction},
{path:'/test',name:'test',component:test},
{path:'/assignment/id',name:'assignment-details',component:assignment},

]

const router=VueRouter.createRouter({
  mode:'history',
  history:VueRouter.createWebHashHistory(),
  routes,
  linkActiveClass: "active",
  linkExactActiveClass:'active'
})




app1.component('recent-notifications',recent_notifications)
app1.component('table-data',table_data)
app1.component('dashboard',dashboard)
app1.component('mobileview',mobileview)
app1.component('payment',payment)
app1.component('profile',profile)
app1.component('countdown',countdown)
app1.component('history',history)
app1.component('chat-component',chat_component)
app1.component('welcome',test)
app1.component('assignment',assignment)
app1.component('nextassign',nextassign)
app1.use(router);


const vm=app1.mount('#vueapprender')